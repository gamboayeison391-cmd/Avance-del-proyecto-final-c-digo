/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import dao.ReporteDAO;
import java.util.Date;
import java.util.List;
import modelo.Compra;
import modelo.Producto;
import modelo.Venta;

/**
 *
 * @author USUARIO
 */
public class ControladorReporte {

    private ReporteDAO reporteDAO;

    public ControladorReporte() {
        reporteDAO = new ReporteDAO();
    }

    // REPORTES
    public List<Venta> reporteVentas(Date fechaInicio, Date fechaFin) {
        return reporteDAO.reporteVentas(fechaInicio, fechaFin);
    }

    public List<Compra> reporteCompras(Date fechaInicio, Date fechaFin) {
        return reporteDAO.reporteCompras(fechaInicio, fechaFin);
    }

    public List<Producto> reporteInventario() {
        return reporteDAO.reporteInventario();
    }

    // TOTALES
    public double totalVentas(Date fechaInicio, Date fechaFin) {
        return reporteDAO.totalVentas(fechaInicio, fechaFin);
    }

    public double gananciaVentas(Date fechaInicio, Date fechaFin) {
        return reporteDAO.gananciaVentas(fechaInicio, fechaFin);
    }
    
    public double totalCompras(Date fechaInicio, Date fechaFin) {
        return reporteDAO.totalCompras(fechaInicio, fechaFin);
    }
}
