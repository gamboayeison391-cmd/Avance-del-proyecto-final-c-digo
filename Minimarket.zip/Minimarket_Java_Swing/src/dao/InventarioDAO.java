package dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import modelo.Inventario;
import modelo.Producto;

public class InventarioDAO {

    private static final Almacen<Inventario> ALMACEN = new Almacen<>(0);

    public boolean registrar(Inventario inv, int idProducto) {
        Producto pro = new ProductoDAO().buscarPorId(idProducto);
        if (pro == null) {
            return false;
        }
        inv.setIdInventario(ALMACEN.siguienteId());
        asociarProducto(inv, pro);
        if (inv.getFechaActualizacion() == null) {
            inv.setFechaActualizacion(new Date());
        }
        ALMACEN.agregar(inv);
        return true;
    }

    public boolean actualizar(Inventario inv, int idProducto) {
        Producto pro = new ProductoDAO().buscarPorId(idProducto);
        if (pro == null) {
            return false;
        }
        asociarProducto(inv, pro);
        return ALMACEN.reemplazar(i -> i.getIdInventario() == inv.getIdInventario(), inv);
    }

    private void asociarProducto(Inventario inv, Producto pro) {
        ArrayList<Producto> productos = new ArrayList<>();
        productos.add(pro);
        inv.setProductos(productos);
    }

    public boolean eliminar(int idInventario) {
        return ALMACEN.quitar(i -> i.getIdInventario() == idInventario);
    }

    public Inventario buscarPorId(int idInventario) {
        return ALMACEN.buscar(i -> i.getIdInventario() == idInventario).orElse(null);
    }

    public Inventario buscarPorProducto(int idProducto) {
        return ALMACEN.buscar(i -> tieneProducto(i, idProducto)).orElse(null);
    }

    public List<Inventario> listar() {
        return ALMACEN.todos();
    }

    public boolean existeProductoEnInventario(int idProducto) {
        return ALMACEN.existe(i -> tieneProducto(i, idProducto));
    }

    public boolean actualizarFecha(int idInventario) {
        Inventario inv = buscarPorId(idInventario);
        if (inv == null) {
            return false;
        }
        inv.setFechaActualizacion(new Date());
        return true;
    }

    private boolean tieneProducto(Inventario inv, int idProducto) {
        return inv.getProductos() != null && !inv.getProductos().isEmpty()
                && inv.getProductos().get(0).getIdProducto() == idProducto;
    }
}
