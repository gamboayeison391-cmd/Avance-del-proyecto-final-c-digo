/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
*
* @author mtorrel
*/
public class ConexionBD {

    private static final String URL =
            "jdbc:mysql://localhost:3306/MinimarketDB"
            + "?useSSL=false"
            + "&serverTimezone=America/Lima"
            + "&allowPublicKeyRetrieval=true";

    private static final String USUARIO = "root";
    private static final String PASSWORD = "";

    public static Connection conectar() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection cn = DriverManager.getConnection(URL, USUARIO, PASSWORD);
            System.out.println("Conectado");
            return cn;
        } catch (ClassNotFoundException e) {
            System.out.println("No se encontró el driver MySQL");
            return null;
        } catch (SQLException e) {
            System.out.println("Error de conexión MySQL: " + e.getMessage());
            return null;
        }
    }

    public static void cerrar(Connection cn) {
        try {
            if (cn != null && !cn.isClosed()) {
                cn.close();
            }
        } catch (SQLException e) {
            System.out.println("Error al cerrar conexión: " + e.getMessage());
        }
    }
}

