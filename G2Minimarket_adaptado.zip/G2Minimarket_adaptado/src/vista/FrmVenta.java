/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import util.Validaciones;

import controlador.ControladorVenta;
import controlador.ControladorCliente;
import controlador.ControladorEmpleado;
import controlador.ControladorProducto;
import modelo.*;

import java.util.Date;
import java.util.List;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import util.FormularioUtil;
import util.Iconos;
import util.Mensajes;

/**
 *
 * @author UCF20429
 */
public class FrmVenta extends JInternalFrame{
    private ControladorVenta controlador = new ControladorVenta();
    private ControladorCliente controladorCliente = new ControladorCliente();
    private ControladorEmpleado controladorEmpleado = new ControladorEmpleado();
    private ControladorProducto controladorProducto = new ControladorProducto();

    private List<Cliente> listaClientes;
    private List<Empleado> listaEmpleados;
    private List<Producto> listaProductos;

    private Venta ventaActual = new Venta();

    private JLabel lblTitulo, lblIdVenta, lblCliente, lblEmpleado, lblFecha, lblHora;
    private JLabel lblProducto, lblCantidad, lblPrecioUnitario, lblSubtotal;
    private JLabel lblSubTotalGeneral, lblIgv, lblTotal;

    private JTextField txtIdVenta, txtFecha, txtHora, txtCantidad;
    private JTextField txtPrecioUnitario, txtSubtotal;
    private JTextField txtSubTotalGeneral, txtIgv, txtTotal;

    private JComboBox<String> cboCliente, cboEmpleado, cboProducto;

    private JButton btnAgregarDetalle, btnQuitarDetalle, btnRegistrarVenta;
    private JButton btnBuscar, btnListar, btnLimpiar;

    private JTable tablaDetalleVenta;
    private DefaultTableModel modeloTabla;
    private JScrollPane scrollTabla;
    
    private JTable tablaVentas;
    private DefaultTableModel modeloVentas;
    private JScrollPane scrollVentas;

    public FrmVenta() {
       iniciarComponentes();
       cargarClientes();
       cargarEmpleados();
       cargarProductos();
       listar();

       txtFecha.setText(new java.text.SimpleDateFormat("dd/MM/yyyy").format(new Date()));

       txtHora.setText(java.time.LocalTime.now().withNano(0).toString());
    }

    private void iniciarComponentes() {

        setTitle("Gestión de Ventas");
        setSize(1200, 700);
        setClosable(true);
        setIconifiable(false);
        setMaximizable(false);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        lblTitulo = new JLabel("GESTIÓN DE VENTAS");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitulo.setBounds(350, 20, 500, 35);

        lblIdVenta = new JLabel("ID Venta:");
        lblIdVenta.setBounds(100, 80, 100, 25);
        txtIdVenta = new JTextField();
        txtIdVenta.setBounds(220, 80, 170, 25);
        FormularioUtil.soloLectura(txtIdVenta);

        lblCliente = new JLabel("Cliente:");
        lblCliente.setBounds(430, 80, 70, 25);
        cboCliente = new JComboBox<>();
        cboCliente.addItem("Seleccione");
        cboCliente.setBounds(550, 80, 220, 25);

        lblEmpleado = new JLabel("Empleado:");
        lblEmpleado.setBounds(800, 80, 80, 25);
        cboEmpleado = new JComboBox<>();
        cboEmpleado.addItem("Seleccione");
        cboEmpleado.setBounds(900, 80, 170, 25);

        lblFecha = new JLabel("Fecha:");
        lblFecha.setBounds(100, 120, 100, 25);
        txtFecha = new JTextField();
        txtFecha.setBounds(220, 120, 170, 25);
        FormularioUtil.soloLectura(txtFecha);

        lblHora = new JLabel("Hora:");
        lblHora.setBounds(430, 120, 70, 25);
        txtHora = new JTextField();
        txtHora = new JTextField();
        txtHora.setBounds(550, 120, 170, 25);
        FormularioUtil.soloLectura(txtHora);

        lblProducto = new JLabel("Producto:");
        lblProducto.setBounds(100, 165, 100, 25);
        cboProducto = new JComboBox<>();
        cboProducto.addItem("Seleccione");
        cboProducto.setBounds(220, 165, 230, 25);

        lblCantidad = new JLabel("Cantidad:");
        lblCantidad.setBounds(480, 165, 80, 25);
        txtCantidad = new JTextField();
        txtCantidad.setBounds(570, 165, 110, 25);

        lblPrecioUnitario = new JLabel("Precio Unitario:");
        lblPrecioUnitario.setBounds(710, 165, 110, 25);
        txtPrecioUnitario = new JTextField();
        txtPrecioUnitario.setBounds(830, 165, 170, 25);
        //txtPrecioUnitario.setEditable(false);
        txtPrecioUnitario.setBackground(Color.WHITE);

        lblSubtotal = new JLabel("Subtotal:");
        lblSubtotal.setBounds(100, 210, 100, 25);
        txtSubtotal = new JTextField();
        txtSubtotal.setBounds(220, 210, 170, 25);
        txtSubtotal.setEditable(false);

        btnAgregarDetalle = new JButton("Agregar Detalle");
        btnAgregarDetalle.setBounds(210, 250, 145, 25);

        btnQuitarDetalle = new JButton("Quitar Detalle");
        btnQuitarDetalle.setBounds(370, 250, 145, 25);

        btnRegistrarVenta = new JButton("Registrar Venta");
        btnRegistrarVenta.setBounds(530, 250, 155, 25);

        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(700, 250, 100, 25);

        btnListar = new JButton("Listar");
        btnListar.setBounds(815, 250, 100, 25);

        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(930, 250, 120, 25);

        //iconos botones
        btnRegistrarVenta.setIcon(Iconos.cargar("/imagenes/registrar.png", 20, 20));
        btnAgregarDetalle.setIcon(Iconos.cargar("/imagenes/actualizar.png", 20, 20));
        btnQuitarDetalle.setIcon(Iconos.cargar("/imagenes/eliminar.png", 20, 20));
        btnBuscar.setIcon(Iconos.cargar("/imagenes/buscar.png", 20, 20));
        btnListar.setIcon(Iconos.cargar("/imagenes/listar.png", 20, 20));
        btnLimpiar.setIcon(Iconos.cargar("/imagenes/limpiar.png", 20, 20));
        //Tabla de detalle venta
        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("Producto");
        modeloTabla.addColumn("Cantidad");
        modeloTabla.addColumn("Precio Unitario");
        modeloTabla.addColumn("Subtotal");

        tablaDetalleVenta = new JTable(modeloTabla);
        JLabel lblDetalle = new JLabel("DETALLE DE LA VENTA");
        lblDetalle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblDetalle.setBounds(100, 285, 220, 25);
        panel.add(lblDetalle);
        scrollTabla = new JScrollPane(tablaDetalleVenta);
        scrollTabla.setBounds(100, 315, 980, 170);
        
        //Tabla de ventas registradas
        modeloVentas = new DefaultTableModel();
        modeloVentas.addColumn("ID");
        modeloVentas.addColumn("Fecha");
        modeloVentas.addColumn("Cliente");
        modeloVentas.addColumn("Empleado");
        modeloVentas.addColumn("Total");

        tablaVentas = new JTable(modeloVentas);
        JLabel lblVentas = new JLabel("VENTAS REGISTRADAS");
        lblVentas.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblVentas.setBounds(100, 495, 220, 25);
        panel.add(lblVentas);
        scrollVentas = new JScrollPane(tablaVentas);
        scrollVentas.setBounds(100, 525, 610, 90);
        panel.add(scrollVentas);
        

        lblSubTotalGeneral = new JLabel("SUBTOTAL:");
        lblSubTotalGeneral.setFont(new Font("Arial", Font.BOLD, 15));
        lblSubTotalGeneral.setBounds(740, 525, 110, 25);

        txtSubTotalGeneral = new JTextField();
        txtSubTotalGeneral.setFont(new Font("Arial", Font.BOLD, 15));
        txtSubTotalGeneral.setBounds(850, 525, 180, 25);
        txtSubTotalGeneral.setEditable(false);

        lblIgv = new JLabel("IGV:");
        lblIgv.setFont(new Font("Arial", Font.BOLD, 15));
        lblIgv.setBounds(740, 560, 110, 25);

        txtIgv = new JTextField();
        txtIgv.setFont(new Font("Arial", Font.BOLD, 15));
        txtIgv.setBounds(850, 560, 180, 25);
        txtIgv.setEditable(false);

        lblTotal = new JLabel("TOTAL:");
        lblTotal.setFont(new Font("Arial", Font.BOLD, 15));
        lblTotal.setBounds(740, 595, 110, 25);

        txtTotal = new JTextField();
        txtTotal.setFont(new Font("Arial", Font.BOLD, 15));
        txtTotal.setBounds(850, 595, 180, 25);
        txtTotal.setEditable(false);

        btnAgregarDetalle.addActionListener(e -> agregarDetalle());
        btnQuitarDetalle.addActionListener(e -> quitarDetalle());
        btnRegistrarVenta.addActionListener(e -> registrarVenta());
        btnBuscar.addActionListener(e -> buscar());
        btnListar.addActionListener(e -> listar());
        btnLimpiar.addActionListener(e -> limpiar());
        cboProducto.addActionListener(e -> cargarPrecioProducto());

        panel.add(lblTitulo);
        panel.add(lblIdVenta);
        panel.add(txtIdVenta);
        panel.add(lblCliente);
        panel.add(cboCliente);
        panel.add(lblEmpleado);
        panel.add(cboEmpleado);
        panel.add(lblFecha);
        panel.add(txtFecha);
        panel.add(lblHora);
        panel.add(txtHora);
        panel.add(lblProducto);
        panel.add(cboProducto);
        panel.add(lblCantidad);
        panel.add(txtCantidad);
        panel.add(lblPrecioUnitario);
        panel.add(txtPrecioUnitario);
        panel.add(lblSubtotal);
        panel.add(txtSubtotal);

        panel.add(btnAgregarDetalle);
        panel.add(btnQuitarDetalle);
        panel.add(btnRegistrarVenta);
        panel.add(btnBuscar);
        panel.add(btnListar);
        panel.add(btnLimpiar);

        panel.add(scrollTabla);

        panel.add(lblSubTotalGeneral);
        panel.add(txtSubTotalGeneral);
        panel.add(lblIgv);
        panel.add(txtIgv);
        panel.add(lblTotal);
        panel.add(txtTotal);

        add(panel);
    }

    //Metodos
    private void cargarClientes() {
        cboCliente.removeAllItems();
        listaClientes = controladorCliente.listarClientes();

        for (Cliente c : listaClientes) {
            cboCliente.addItem(c.getNombre() + " " + c.getApPaterno());
        }
    }

    private void cargarEmpleados() {
        cboEmpleado.removeAllItems();
        listaEmpleados = controladorEmpleado.listarEmpleados();

        for (Empleado e : listaEmpleados) {
            cboEmpleado.addItem(e.getNombre() + " " + e.getApPaterno());
        }
    }

    private void cargarProductos() {
        cboProducto.removeAllItems();
        listaProductos = controladorProducto.listarProductos();

        for (Producto p : listaProductos) {
            cboProducto.addItem(p.getNombre());
        }
    }

    private Cliente obtenerClienteSeleccionado() {
        int i = cboCliente.getSelectedIndex();

        if (i >= 0 && listaClientes != null && i < listaClientes.size()) {
            return listaClientes.get(i);
        }

        return null;
    }

    private Empleado obtenerEmpleadoSeleccionado() {
        int i = cboEmpleado.getSelectedIndex();

        if (i >= 0 && listaEmpleados != null && i < listaEmpleados.size()) {
            return listaEmpleados.get(i);
        }

        return null;
    }

    private Producto obtenerProductoSeleccionado() {
        int i = cboProducto.getSelectedIndex();

        if (i >= 0 && listaProductos != null && i < listaProductos.size()) {
            return listaProductos.get(i);
        }

        return null;
    }
    
    private void agregarDetalle() {

        try {

            if (!validarDetalle()) {
                return;
            }

            Producto producto = obtenerProductoSeleccionado();

            if (producto == null) {
                Mensajes.advertencia(this,
                    "Seleccione un producto.");
                return;
            }

            int cantidad = Integer.parseInt(txtCantidad.getText().trim());
            double precio = Double.parseDouble(txtPrecioUnitario.getText().trim());

            // Verificar si el producto ya fue agregado
            for (DetalleVenta d : ventaActual.getDetallesVenta()) {

                if (d.getProducto().getIdProducto() == producto.getIdProducto()) {

                    int nuevaCantidad = d.getCantidad() + cantidad;

                    if (nuevaCantidad > producto.getStock()) {

                        Mensajes.advertencia(this,
                            "No hay stock suficiente.\n"
                          + "Stock disponible: " + producto.getStock());

                        return;
                    }

                    d.setCantidad(nuevaCantidad);
                    d.setPrecioUnitario(precio);

                    actualizarTablaDetalle();
                    calcularTotales();
    
                    txtCantidad.setText("");
                    txtPrecioUnitario.setText("");
                    txtSubtotal.setText("");

                    Mensajes.exito(this,
                        "Cantidad del producto actualizada.");

                    return;
                }
            }

            DetalleVenta detalle = new DetalleVenta();
            detalle.setProducto(producto);
            detalle.setCantidad(cantidad);
            detalle.setPrecioUnitario(precio);

            ventaActual.agregarDetalle(detalle);

                modeloTabla.addRow(new Object[]{
                    producto.getNombre(),
                    detalle.getCantidad(),
                    detalle.getPrecioUnitario(),
                    detalle.getSubtotal()
                });

                txtSubtotal.setText(String.format("%.2f", detalle.getSubtotal()));

                calcularTotales();

                txtCantidad.setText("");
                txtPrecioUnitario.setText("");

                Mensajes.exito(this,"Producto agregado correctamente.");

            } catch (Exception e) {
            Mensajes.error(this,"No fue posible agregar el producto.");
        }
    }
    
    //
    private void actualizarTablaDetalle() {
        modeloTabla.setRowCount(0);

        for (DetalleVenta detalle : ventaActual.getDetallesVenta()) {
            modeloTabla.addRow(new Object[]{
                detalle.getProducto().getNombre(),
                detalle.getCantidad(),
                detalle.getPrecioUnitario(),
                detalle.getSubtotal()

            });
        }
    }

    private void quitarDetalle() {
        int fila = tablaDetalleVenta.getSelectedRow();

        if (fila == -1) {
            Mensajes.advertencia(this, "Seleccione un producto del detalle.");
            return;
        }

        if (!Mensajes.confirmar(this, "¿Desea quitar este producto de la venta?")) {
            return;
        }

        ventaActual.getDetallesVenta().remove(fila);
        actualizarTablaDetalle();
        calcularTotales();

        Mensajes.exito(this, "Producto quitado del detalle.");
    }

    private void calcularTotales() {
        ventaActual.calcularTotales();
    
        txtSubTotalGeneral.setText(String.format("%.2f", ventaActual.getSubtotal()));
        txtIgv.setText(String.format("%.2f", ventaActual.getIgv()));
        txtTotal.setText(String.format("%.2f", ventaActual.getTotal()));
    }

    private void registrarVenta() {
        try {
            if (!validarVenta()) {
                return;
            }

            Cliente cliente = obtenerClienteSeleccionado();
            Empleado empleado = obtenerEmpleadoSeleccionado();

            ventaActual.setCliente(cliente);
            ventaActual.setEmpleado(empleado);
            ventaActual.setFecha(new Date());
            ventaActual.setHora(java.time.LocalTime.now().withNano(0).toString());
            ventaActual.calcularTotales();

            if (controlador.registrarVenta(ventaActual)) {
                Mensajes.exito(this, "Venta registrada correctamente.");
                limpiar();
                cargarProductos();
                listar();
            } else {
                Mensajes.error(this, "No se pudo registrar la venta.");
            }

        } catch (Exception e) {
            Mensajes.error(this, "Ocurrió un error al registrar la venta.");
        }
    }

    private void buscar() {
        try {
            if (Validaciones.estaVacio(txtIdVenta.getText())) {
                Mensajes.advertencia(this, "Ingrese el ID de la venta.");
                txtIdVenta.requestFocus();
                return;
            }

            if (!Validaciones.enteroValido(txtIdVenta.getText().trim())) {
                Mensajes.advertencia(this, "El ID de la venta debe ser numérico.");
                txtIdVenta.requestFocus();
                return;
            }

            int idVenta = Integer.parseInt(txtIdVenta.getText().trim());

            Venta venta = controlador.buscarVenta(idVenta);

            if (venta != null) {

                txtFecha.setText(
                    new java.text.SimpleDateFormat("dd/MM/yyyy")
                    .format(venta.getFecha())
            );

            txtHora.setText(venta.getHora());

            txtSubTotalGeneral.setText(String.format("%.2f", venta.getSubtotal()));
            txtIgv.setText(String.format("%.2f", venta.getIgv()));
            txtTotal.setText(String.format("%.2f", venta.getTotal()));

            if (venta.getCliente() != null) {
                cboCliente.setSelectedItem(
                    venta.getCliente().getNombre() + " " + venta.getCliente().getApPaterno()
                );
            }

            if (venta.getEmpleado() != null) {
                cboEmpleado.setSelectedItem(
                    venta.getEmpleado().getNombre() + " " + venta.getEmpleado().getApPaterno()
                );
            }

            modeloTabla.setRowCount(0);

            for (DetalleVenta d : venta.getDetallesVenta()) {
                modeloTabla.addRow(new Object[]{
                    d.getProducto().getNombre(),
                    d.getCantidad(),
                    String.format("%.2f", d.getPrecioUnitario()),
                        String.format("%.2f", d.getSubtotal())
                    });
                }

                txtIdVenta.setEditable(false);
                btnRegistrarVenta.setEnabled(false);

                Mensajes.exito(this, "Venta encontrada correctamente.");

            } else {
                Mensajes.error(this, "No existe una venta con el ID ingresado.");
            }

        } catch (Exception e) {
            Mensajes.error(this, "No se pudo buscar la venta.");
        }
    }

    private void listar() {

        modeloVentas.setRowCount(0);
        List<Venta> lista = controlador.listarVentas();

        for (Venta venta : lista) {

            modeloVentas.addRow(new Object[]{
    
                venta.getIdVenta(),
                new java.text.SimpleDateFormat("dd/MM/yyyy")
                    .format(venta.getFecha()),
    
                venta.getCliente().getNombre()
                + " " + venta.getCliente().getApPaterno(),

                venta.getEmpleado().getNombre()
                + " " + venta.getEmpleado().getApPaterno(),
                String.format("%.2f", venta.getTotal())

            });
        }
    }

    private void limpiar() {
        txtIdVenta.setText("");
        txtCantidad.setText("");
        txtPrecioUnitario.setText("");
        txtSubtotal.setText("");
        txtSubTotalGeneral.setText("");
        txtIgv.setText("");
        txtTotal.setText("");

        txtFecha.setText(new java.text.SimpleDateFormat("dd/MM/yyyy").format(new Date()));
        txtHora.setText(java.time.LocalTime.now().withNano(0).toString());
    
        if (cboCliente.getItemCount() > 0) cboCliente.setSelectedIndex(0);
        if (cboEmpleado.getItemCount() > 0) cboEmpleado.setSelectedIndex(0);
        if (cboProducto.getItemCount() > 0) cboProducto.setSelectedIndex(0);

        ventaActual = new Venta();

        modeloTabla.setRowCount(0);

        txtIdVenta.setEditable(true);
        btnRegistrarVenta.setEnabled(true);

        txtIdVenta.requestFocus();
    }

    //validaciones
    private boolean validarDetalle() {
        if (cboProducto.getSelectedIndex() == -1) {
            Mensajes.advertencia(this, "Seleccione un producto");
            cboProducto.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtCantidad.getText())) {
            Mensajes.advertencia(this, "Ingrese la cantidad");
            txtCantidad.requestFocus();
            return false;
        }

        if (!Validaciones.enteroValido(txtCantidad.getText().trim())) {
            Mensajes.advertencia(this, "La cantidad debe ser numérica");
            txtCantidad.requestFocus();
            return false;
        }

        if (Integer.parseInt(txtCantidad.getText().trim()) <= 0) {
            Mensajes.advertencia(this, "La cantidad debe ser mayor que cero");
            txtCantidad.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtPrecioUnitario.getText())) {
            Mensajes.advertencia(this, "Ingrese el precio unitario");
            txtPrecioUnitario.requestFocus();
            return false;
        }

        if (!Validaciones.decimalValido(txtPrecioUnitario.getText().trim())) {
            Mensajes.advertencia(this, "El precio debe ser numérico");
            txtPrecioUnitario.requestFocus();
            return false;
        }

        if (Double.parseDouble(txtPrecioUnitario.getText().trim()) <= 0) {
            Mensajes.advertencia(this, "El precio debe ser mayor que cero");
            txtPrecioUnitario.requestFocus();
            return false;
        }

        Producto producto = obtenerProductoSeleccionado();

        if (producto != null &&
            Integer.parseInt(txtCantidad.getText().trim()) > producto.getStock()) {

            Mensajes.advertencia(this,
           "Stock insuficiente.\nStock disponible: " + producto.getStock());

            txtCantidad.requestFocus();
            return false;
        }
        return true;
    }

    private void cargarPrecioProducto() {
        Producto producto = obtenerProductoSeleccionado();

        if (producto != null) {
            txtPrecioUnitario.setText(String.valueOf(producto.getPrecioVenta()));
        } else {
            txtPrecioUnitario.setText("");
        }
    }
    
    private boolean validarVenta() {

        if (cboCliente.getSelectedIndex() == -1) {
            Mensajes.advertencia(this, "Seleccione un cliente");
            cboCliente.requestFocus();
            return false;
        }

        if (cboEmpleado.getSelectedIndex() == -1) {
            Mensajes.advertencia(this, "Seleccione un empleado");
            cboEmpleado.requestFocus();
            return false;
        }

        if (ventaActual.getDetallesVenta().isEmpty()) {
            Mensajes.advertencia(this,
            "Debe agregar al menos un producto a la venta");
            return false;
        }
        return true;
    }
}
