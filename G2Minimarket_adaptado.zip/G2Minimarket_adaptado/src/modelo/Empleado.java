/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author UCF20429
 */
public class Empleado extends Persona {

    private String codigoEmpleado;
    private Date fechaIngreso;
    private String cargo;
    private double sueldo;

    // Relación reflexiva
    private Empleado jefe;
    private ArrayList<Empleado> subordinados;

    // Constructor vacío
    public Empleado() {
        subordinados = new ArrayList<>();
    }

    // Constructor con parámetros
    public Empleado(String codigoEmpleado,
                    Date fechaIngreso,
                    String cargo,
                    double sueldo,
                    Empleado jefe,
                    ArrayList<Empleado> subordinados,
                    int idPersona,
                    String tipoDocumento,
                    String nroDocumento,
                    String nombre,
                    String apPaterno,
                    String apMaterno,
                    Date fechaNacimiento,
                    String sexo,
                    String telefono,
                    String correo,
                    String direccion,
                    boolean estado) {

        super(idPersona, tipoDocumento, nroDocumento,
                nombre, apPaterno, apMaterno,
                fechaNacimiento, sexo,
                telefono, correo,
                direccion, estado);

        this.codigoEmpleado = codigoEmpleado;
        this.fechaIngreso = fechaIngreso;
        this.cargo = cargo;
        this.sueldo = sueldo;
        this.jefe = jefe;
        this.subordinados = subordinados;
    }

    // Getters y Setters
    public String getCodigoEmpleado() {
        return codigoEmpleado;
    }

    public void setCodigoEmpleado(String codigoEmpleado) {
        this.codigoEmpleado = codigoEmpleado;
    }

    public Date getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(Date fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public Empleado getJefe() {
        return jefe;
    }

    public void setJefe(Empleado jefe) {
        this.jefe = jefe;
    }

    public ArrayList<Empleado> getSubordinados() {
        return subordinados;
    }

    public void setSubordinados(ArrayList<Empleado> subordinados) {
        this.subordinados = subordinados;
    }
}
