/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import util.Validaciones;

import controlador.ControladorCompra;
import controlador.ControladorProveedor;
import controlador.ControladorEmpleado;
import controlador.ControladorProducto;
import modelo.*;

import java.util.Date;
import java.util.List;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import util.Iconos;
import util.Mensajes;

/**
 *
 * @author UCF20429
 */
public class FrmCompra extends JInternalFrame{
    private ControladorCompra controlador = new ControladorCompra();
    private ControladorProveedor controladorProveedor = new ControladorProveedor();
    private ControladorEmpleado controladorEmpleado = new ControladorEmpleado();
    private ControladorProducto controladorProducto = new ControladorProducto();

    private List<Proveedor> listaProveedores;
    private List<Empleado> listaEmpleados;
    private List<Producto> listaProductos;

    private Compra compraActual = new Compra();

    private JLabel lblTitulo, lblIdCompra, lblProveedor, lblEmpleado, lblFecha;
    private JLabel lblProducto, lblCantidad, lblPrecioCompra, lblSubtotal, lblTotal;

    private JTextField txtIdCompra, txtFecha, txtCantidad, txtPrecioCompra;
    private JTextField txtSubtotal, txtTotal;

    private JComboBox<String> cboProveedor, cboEmpleado, cboProducto;

    private JButton btnAgregarDetalle, btnQuitarDetalle, btnRegistrarCompra;
    private JButton btnBuscar, btnListar, btnLimpiar;

    private JTable tablaDetalleCompra;
    private DefaultTableModel modeloTabla;
    private JScrollPane scrollTabla;
    
    private JLabel lblDetalleCompra, lblComprasRegistradas;
    
    private JTable tablaCompras;
    private DefaultTableModel modeloCompras;
    private JScrollPane scrollCompras;

    public FrmCompra() {
        iniciarComponentes();
        cargarProveedores();
        cargarEmpleados();
        cargarProductos();
        listar();
    }

    private void iniciarComponentes() {
        setTitle("Gestión de Compras");
        setSize(1050, 650);
        setClosable(true);
        setIconifiable(false);
        setMaximizable(false);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        lblTitulo = new JLabel("GESTIÓN DE COMPRAS");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitulo.setBounds(430, 20, 350, 35);

        lblIdCompra = new JLabel("ID Compra:");
        lblIdCompra.setBounds(80, 80, 120, 25);
        txtIdCompra = new JTextField();
        txtIdCompra.setBounds(190, 80, 160, 25);
        //txtIdCompra.setEditable(false);

        lblProveedor = new JLabel("Proveedor:");
        lblProveedor.setBounds(400, 80, 100, 25);
        cboProveedor = new JComboBox<>();
        cboProveedor.addItem("Seleccione");
        cboProveedor.setBounds(500, 80, 250, 25);

        lblEmpleado = new JLabel("Empleado:");
        lblEmpleado.setBounds(790, 80, 100, 25);
        cboEmpleado = new JComboBox<>();
        cboEmpleado.addItem("Seleccione");
        cboEmpleado.setBounds(880, 80, 180, 25);

        lblFecha = new JLabel("Fecha:");
        lblFecha.setBounds(80, 125, 120, 25);
        txtFecha = new JTextField();
        txtFecha.setBounds(190, 125, 160, 25);
        txtFecha.setToolTipText("Formato: dd/MM/yyyy");

        lblProducto = new JLabel("Producto:");
        lblProducto.setBounds(400, 125, 100, 25);
        cboProducto = new JComboBox<>();
        cboProducto.addItem("Seleccione");
        cboProducto.setBounds(500, 125, 250, 25);

        lblCantidad = new JLabel("Cantidad:");
        lblCantidad.setBounds(80, 170, 120, 25);
        txtCantidad = new JTextField();
        txtCantidad.setBounds(190, 170, 160, 25);

        lblPrecioCompra = new JLabel("Precio Compra:");
        lblPrecioCompra.setBounds(400, 170, 120, 25);
        txtPrecioCompra = new JTextField();
        txtPrecioCompra.setBounds(520, 170, 150, 25);

        lblSubtotal = new JLabel("Subtotal:");
        lblSubtotal.setBounds(720, 170, 100, 25);
        txtSubtotal = new JTextField();
        txtSubtotal.setBounds(820, 170, 160, 25);
        txtSubtotal.setEditable(false);

        btnAgregarDetalle = new JButton("Agregar Detalle");
        btnAgregarDetalle.setBounds(160, 225, 150, 32);

        btnQuitarDetalle = new JButton("Quitar Detalle");
        btnQuitarDetalle.setBounds(330, 225, 140, 32);

        btnRegistrarCompra = new JButton("Registrar Compra");
        btnRegistrarCompra.setBounds(490, 225, 160, 32);

        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(670, 225, 100, 32);

        btnListar = new JButton("Listar");
        btnListar.setBounds(790, 225, 90, 32);

        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(900, 225, 100, 32);
        
        //Iconos de botones
        btnRegistrarCompra.setIcon(Iconos.cargar("/imagenes/registrar.png", 20, 20));
        btnAgregarDetalle.setIcon(Iconos.cargar("/imagenes/actualizar.png", 20, 20));
        btnQuitarDetalle.setIcon(Iconos.cargar("/imagenes/eliminar.png", 20, 20));
        btnBuscar.setIcon(Iconos.cargar("/imagenes/buscar.png", 20, 20));
        btnListar.setIcon(Iconos.cargar("/imagenes/listar.png", 20, 20));
        btnLimpiar.setIcon(Iconos.cargar("/imagenes/limpiar.png", 20, 20));

        //Titulos de tablas
        lblDetalleCompra = new JLabel("DETALLE DE COMPRA");
        lblDetalleCompra.setFont(new Font("Arial", Font.BOLD, 14));
        lblDetalleCompra.setBounds(80, 275, 250, 25);
    
        lblComprasRegistradas = new JLabel("COMPRAS REGISTRADAS");
        lblComprasRegistradas.setFont(new Font("Arial", Font.BOLD, 14));
        lblComprasRegistradas.setBounds(80, 515, 250, 25);
        
        // Tabla de detalle
        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("Producto");
        modeloTabla.addColumn("Cantidad");
        modeloTabla.addColumn("Precio Compra");
        modeloTabla.addColumn("Subtotal");
        
        tablaDetalleCompra = new JTable(modeloTabla);
        scrollTabla = new JScrollPane(tablaDetalleCompra);
        scrollTabla.setBounds(80, 305, 980, 190);
        
        // Tabla de compras registradas
        modeloCompras = new DefaultTableModel();
        modeloCompras.addColumn("ID");
        modeloCompras.addColumn("Fecha");
        modeloCompras.addColumn("Proveedor");
        modeloCompras.addColumn("Empleado");
        modeloCompras.addColumn("Total");

        tablaCompras = new JTable(modeloCompras);
        scrollCompras = new JScrollPane(tablaCompras);
        scrollCompras.setBounds(80, 545, 650, 90);
        panel.add(scrollCompras);

        lblTotal = new JLabel("TOTAL:");
        lblTotal.setFont(new Font("Arial", Font.BOLD, 16));
        lblTotal.setBounds(780, 560, 100, 30);

        txtTotal = new JTextField();
        txtTotal.setFont(new Font("Arial", Font.BOLD, 16));
        txtTotal.setBounds(880, 560, 170, 30);
        txtTotal.setEditable(false);

        btnAgregarDetalle.addActionListener(e -> agregarDetalle());
        btnQuitarDetalle.addActionListener(e -> quitarDetalle());
        btnRegistrarCompra.addActionListener(e -> registrarCompra());
        btnBuscar.addActionListener(e -> buscar());
        btnListar.addActionListener(e -> listar());
        btnLimpiar.addActionListener(e -> limpiar());

        panel.add(lblTitulo);
        panel.add(lblIdCompra);
        panel.add(txtIdCompra);
        panel.add(lblProveedor);
        panel.add(cboProveedor);
        panel.add(lblEmpleado);
        panel.add(cboEmpleado);
        panel.add(lblFecha);
        panel.add(txtFecha);
        panel.add(lblProducto);
        panel.add(cboProducto);
        panel.add(lblCantidad);
        panel.add(txtCantidad);
        panel.add(lblPrecioCompra);
        panel.add(txtPrecioCompra);
        panel.add(lblSubtotal);
        panel.add(txtSubtotal);

        panel.add(btnAgregarDetalle);
        panel.add(btnQuitarDetalle);
        panel.add(btnRegistrarCompra);
        panel.add(btnBuscar);
        panel.add(btnListar);
        panel.add(btnLimpiar);

        panel.add(scrollTabla);
        panel.add(lblDetalleCompra);
        panel.add(lblComprasRegistradas);
        panel.add(lblTotal);
        panel.add(txtTotal);

        add(panel);
    }
    
    //Metodos
    private void cargarProveedores() {
        cboProveedor.removeAllItems();
        listaProveedores = controladorProveedor.listarProveedores();

        for (Proveedor p : listaProveedores) {
            cboProveedor.addItem(p.getRazonSocial());
        }
    }

    private void cargarEmpleados() {
        cboEmpleado.removeAllItems();
        listaEmpleados = controladorEmpleado.listarEmpleados();

        for (Empleado e : listaEmpleados) {
            cboEmpleado.addItem(e.getNombre() + " " + e.getApPaterno());
        }
    }

    private void cargarProductos() {
        cboProducto.removeAllItems();
        listaProductos = controladorProducto.listarProductos();

        for (Producto p : listaProductos) {
            cboProducto.addItem(p.getNombre());
        }
    }

    private Proveedor obtenerProveedorSeleccionado() {
        int i = cboProveedor.getSelectedIndex();
        if (i >= 0 && listaProveedores != null && i < listaProveedores.size()) {
            return listaProveedores.get(i);
        }
        return null;
    }

    private Empleado obtenerEmpleadoSeleccionado() {
        int i = cboEmpleado.getSelectedIndex();
        if (i >= 0 && listaEmpleados != null && i < listaEmpleados.size()) {
            return listaEmpleados.get(i);
        }
        return null;
    }

    private Producto obtenerProductoSeleccionado() {
        int i = cboProducto.getSelectedIndex();
        if (i >= 0 && listaProductos != null && i < listaProductos.size()) {
            return listaProductos.get(i);
        }
        return null;
    }

    private void agregarDetalle() {
        try {
            if (!validarDetalle()) {
                return;
            }

            Producto producto = obtenerProductoSeleccionado();

            if (producto == null) {
                Mensajes.advertencia(this, "Seleccione un producto.");
                return;
            }

            int cantidad = Integer.parseInt(txtCantidad.getText().trim());
            double precio = Double.parseDouble(txtPrecioCompra.getText().trim());

            for (DetalleCompra d : compraActual.getDetallesCompra()) {
                if (d.getProducto().getIdProducto() == producto.getIdProducto()) {
                d.setCantidad(d.getCantidad() + cantidad);
                d.setPrecioCompra(precio);

                actualizarTablaDetalle();
                calcularTotal();

                txtCantidad.setText("");
                txtPrecioCompra.setText("");
                txtSubtotal.setText("");

                    Mensajes.exito(this, "Cantidad actualizada en el detalle.");
                    return;
                }
            }

            DetalleCompra detalle = new DetalleCompra();
            detalle.setProducto(producto);
            detalle.setCantidad(cantidad);
            detalle.setPrecioCompra(precio);

            compraActual.agregarDetalle(detalle);

            modeloTabla.addRow(new Object[]{
                producto.getNombre(),
                cantidad,
                precio,
                detalle.getSubtotal()
            });

            calcularTotal();

            txtCantidad.setText("");
            txtPrecioCompra.setText("");
            txtSubtotal.setText("");

            Mensajes.exito(this, "Producto agregado al detalle de compra.");

        } catch (Exception e) {
            Mensajes.error(this, "Ingrese cantidad y precio válidos.");
        }
    }
    
    private void actualizarTablaDetalle() {
        modeloTabla.setRowCount(0);

        for (DetalleCompra d : compraActual.getDetallesCompra()) {
            modeloTabla.addRow(new Object[]{
                d.getProducto().getNombre(),
                d.getCantidad(),
                d.getPrecioCompra(),
                d.getSubtotal()
            });
        }
    }

    private void quitarDetalle() {
        int fila = tablaDetalleCompra.getSelectedRow();
        if (fila == -1) {
            Mensajes.advertencia(this, "Seleccione un detalle para quitar.");
            return;
        }

        if (!Mensajes.confirmar(this, "¿Desea quitar este producto del detalle?")) {
            return;
        }

        compraActual.getDetallesCompra().remove(fila);
        actualizarTablaDetalle();
        calcularTotal();

        Mensajes.exito(this, "Producto quitado del detalle.");
    }

    private void calcularTotal() {
        compraActual.calcularTotal();
        txtTotal.setText(String.format("%.2f", compraActual.getTotal()));
    }

    private void registrarCompra() {
        try {
            if (!validarCompra()) {
                return;
            }

            Proveedor proveedor = obtenerProveedorSeleccionado();
            Empleado empleado = obtenerEmpleadoSeleccionado();
    
            if (proveedor == null) {
                Mensajes.advertencia(this, "Seleccione un proveedor.");
                return;
            }

            if (empleado == null) {
                Mensajes.advertencia(this, "Seleccione un empleado.");
                return;
            }

            if (compraActual.getDetallesCompra().isEmpty()) {
                Mensajes.advertencia(this, "Agregue al menos un producto a la compra.");
                return;
            }

            compraActual.setProveedor(proveedor);
            compraActual.setEmpleado(empleado);
            compraActual.setFecha(new Date());
            compraActual.calcularTotal();

            if (controlador.registrarCompra(compraActual)) {
                Mensajes.exito(this, "Compra registrada correctamente.");
                limpiar();
                cargarProductos();
                listar();
            } else {
                Mensajes.error(this, "No se pudo registrar la compra.");
            }

        } catch (Exception e) {
            Mensajes.error(this, "Ocurrió un error al registrar la compra.");
        }
    }

    private void buscar() {
        try {
            if (txtIdCompra.getText().trim().isEmpty()) {
                Mensajes.advertencia(this, "Ingrese el ID de la compra para buscar.");
                txtIdCompra.requestFocus();
                return;
            }

            int idCompra = Integer.parseInt(txtIdCompra.getText().trim());

            Compra compra = controlador.buscarCompra(idCompra);

            if (compra != null) {
                txtFecha.setText(String.valueOf(compra.getFecha()));
                txtTotal.setText(String.valueOf(compra.getTotal()));

                if (compra.getProveedor() != null) {
                    cboProveedor.setSelectedItem(compra.getProveedor().getRazonSocial());
                }

                if (compra.getEmpleado() != null) {
                    cboEmpleado.setSelectedItem(
                        compra.getEmpleado().getNombre() + " " + compra.getEmpleado().getApPaterno()
                    );
                }

                modeloTabla.setRowCount(0);

                for (DetalleCompra d : compra.getDetallesCompra()) {
                    modeloTabla.addRow(new Object[]{
                        d.getProducto().getNombre(),
                        d.getCantidad(),
                        d.getPrecioCompra(),
                        d.getSubtotal()
                    });
                }

                btnRegistrarCompra.setEnabled(false);
                btnAgregarDetalle.setEnabled(false);
                btnQuitarDetalle.setEnabled(false);
                txtIdCompra.setEditable(false);

            } else {
                Mensajes.advertencia(this, "Compra no encontrada.");
            }

        } catch (Exception e) {
            Mensajes.advertencia(this, "Ingrese un ID válido.");
        }
    }

    private void listar() {
        modeloCompras.setRowCount(0);

        List<Compra> lista = controlador.listarCompras();

        for (Compra c : lista) {
            modeloCompras.addRow(new Object[]{
                c.getIdCompra(),
                c.getFecha(),
                c.getProveedor() != null ? c.getProveedor().getRazonSocial() : "",
                c.getEmpleado() != null ? c.getEmpleado().getNombre() : "",
                c.getTotal()
            });
        }
    }    

    private boolean validarDetalle() {
        if (cboProducto.getSelectedIndex() == -1) {
            Mensajes.advertencia(this, "Seleccione un producto.");
            cboProducto.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtCantidad.getText())) {
            Mensajes.advertencia(this, "Ingrese la cantidad.");
            txtCantidad.requestFocus();
            return false;
        }    

        if (!Validaciones.enteroValido(txtCantidad.getText().trim())) {
            Mensajes.advertencia(this, "La cantidad debe ser un número entero.");
            txtCantidad.requestFocus();
            return false;
        }

        if (Integer.parseInt(txtCantidad.getText().trim()) <= 0) {
            Mensajes.advertencia(this, "La cantidad debe ser mayor que cero.");
            txtCantidad.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtPrecioCompra.getText())) {
            Mensajes.advertencia(this, "Ingrese el precio de compra.");
            txtPrecioCompra.requestFocus();
            return false;
        }

        if (!Validaciones.decimalValido(txtPrecioCompra.getText().trim())) {
            Mensajes.advertencia(this, "El precio de compra debe ser numérico.");
            txtPrecioCompra.requestFocus();
            return false;
        }

        if (Double.parseDouble(txtPrecioCompra.getText().trim()) <= 0) {
            Mensajes.advertencia(this, "El precio de compra debe ser mayor que cero.");
            txtPrecioCompra.requestFocus();
            return false;
        }

        return true;
    }

    private boolean validarCompra() {
        if (cboProveedor.getSelectedIndex() == -1) {
            Mensajes.advertencia(this, "Seleccione un proveedor.");
            cboProveedor.requestFocus();
            return false;
        }

        if (cboEmpleado.getSelectedIndex() == -1) {
            Mensajes.advertencia(this, "Seleccione un empleado.");
            cboEmpleado.requestFocus();
            return false;
        }

        if (compraActual.getDetallesCompra().isEmpty()) {
            Mensajes.advertencia(this, "Agregue al menos un producto a la compra.");
            return false;
        }

        return true;
    }
    
    private void limpiar() {
        txtIdCompra.setText("");
        txtCantidad.setText("");
        txtPrecioCompra.setText("");
        txtSubtotal.setText("");
        txtTotal.setText("");

        txtFecha.setText(
            new java.text.SimpleDateFormat("dd/MM/yyyy")
            .format(new Date())
        );

        if (cboProveedor.getItemCount() > 0) cboProveedor.setSelectedIndex(0);
        if (cboEmpleado.getItemCount() > 0) cboEmpleado.setSelectedIndex(0);
        if (cboProducto.getItemCount() > 0) cboProducto.setSelectedIndex(0);

        compraActual = new Compra();
        modeloTabla.setRowCount(0);

        txtIdCompra.setEditable(true);

        btnRegistrarCompra.setEnabled(true);
        btnAgregarDetalle.setEnabled(true);
        btnQuitarDetalle.setEnabled(true);

        txtIdCompra.requestFocus();
    }
}
