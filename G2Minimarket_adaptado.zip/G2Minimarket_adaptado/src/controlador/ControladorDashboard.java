/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import dao.DashboardDAO;
import java.util.Map;
/**
 *
 * @author USUARIO
 */
public class ControladorDashboard {
    private DashboardDAO dashboardDAO;

    public ControladorDashboard() {
        dashboardDAO = new DashboardDAO();
    }

    public double ventasDelDia() {
        return dashboardDAO.ventasDelDia();
    }

    public double gananciaDelDia() {
       return dashboardDAO.gananciaDelDia();
    }

    public int totalClientes() {
        return dashboardDAO.totalClientes();
    }

    public int totalProductos() {
        return dashboardDAO.totalProductos();
    }

    public int totalEmpleados() {
        return dashboardDAO.totalEmpleados();
    }

    public int productosStockBajo() {
        return dashboardDAO.productosStockBajo();
    }
    
    public Map<String, Double> ventasUltimos7Dias() {
        return dashboardDAO.ventasUltimos7Dias();
    }
}