/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexion.ConexionBD;
import modelo.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author USUARIO
 */
public class VentaDAO {
    public boolean registrar(Venta venta) {
        
        Connection cn = null;
        try {
            cn = ConexionBD.conectar();
            cn.setAutoCommit(false);

            int idCliente = obtenerIdCliente(cn, venta.getCliente().getIdPersona());
            int idEmpleado = obtenerIdEmpleado(cn, venta.getEmpleado().getIdPersona());

            venta.calcularTotales();

            PreparedStatement psVenta = cn.prepareStatement(
              "INSERT INTO Venta "
              + "(idCliente, idEmpleado, fecha, hora, subtotal, igv, total, estado) "
              + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS
            );

            psVenta.setInt(1, idCliente);
            psVenta.setInt(2, idEmpleado);

            if (venta.getFecha() != null) {
                psVenta.setDate(3, new java.sql.Date(venta.getFecha().getTime()));
            } else {
                psVenta.setDate(3, new java.sql.Date(System.currentTimeMillis()));
            }

            if (venta.getHora() != null && !venta.getHora().trim().isEmpty()) {
                psVenta.setTime(4, Time.valueOf(venta.getHora()));
            } else {
                psVenta.setTime(4, new Time(System.currentTimeMillis()));
            }

            psVenta.setDouble(5, venta.getSubtotal());
            psVenta.setDouble(6, venta.getIgv());
            psVenta.setDouble(7, venta.getTotal());
            psVenta.setString(8, "ACTIVA");

            int resVenta = psVenta.executeUpdate();

            if (resVenta == 0) {
                cn.rollback();
                return false;
            }

            ResultSet rs = psVenta.getGeneratedKeys();

            int idVenta = 0;

            if (rs.next()) {
                idVenta = rs.getInt(1);
            } else {
                cn.rollback();
                return false;
            }

            PreparedStatement psDetalle = cn.prepareStatement(
                "INSERT INTO DetalleVenta "
              + "(idVenta, idProducto, cantidad, precioUnitario, subtotal) "
              + "VALUES (?, ?, ?, ?, ?)"
            );

            PreparedStatement psStock = cn.prepareStatement(
                "UPDATE Producto SET stock = stock - ? WHERE idProducto = ?"
            );

            for (DetalleVenta detalle : venta.getDetallesVenta()) {
                detalle.calcularSubtotal();

                if (!hayStockDisponible(cn, detalle.getProducto().getIdProducto(), detalle.getCantidad())) {
                    cn.rollback();
                    return false;
                }

                psDetalle.setInt(1, idVenta);
                psDetalle.setInt(2, detalle.getProducto().getIdProducto());
                psDetalle.setInt(3, detalle.getCantidad());
                psDetalle.setDouble(4, detalle.getPrecioUnitario());
                psDetalle.setDouble(5, detalle.getSubtotal());
                psDetalle.executeUpdate();

                psStock.setInt(1, detalle.getCantidad());
                psStock.setInt(2, detalle.getProducto().getIdProducto());
                psStock.executeUpdate();
            }

            rs.close();
            psVenta.close();
            psDetalle.close();
            psStock.close();

            cn.commit();
            return true;

        } catch (SQLException e) {
            hacerRollback(cn);
            System.out.println("Error registrar venta: " + e.getMessage());
            return false;

        } finally {
            ConexionBD.cerrar(cn);
        }
    }

    public Venta buscarPorId(int idVenta) {
        Venta venta = null;

        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement psVenta = cn.prepareStatement(
                consultaVenta()
              + "WHERE v.idVenta = ?"
            );

            psVenta.setInt(1, idVenta);

            ResultSet rsVenta = psVenta.executeQuery();

            if (rsVenta.next()) {
                venta = convertirVenta(rsVenta);
                cargarDetallesVenta(cn, venta);
            }

            rsVenta.close();
            psVenta.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error buscar venta: " + e.getMessage());
        }

        return venta;
    }

    public List<Venta> listar() {
        List<Venta> lista = new ArrayList<>();

        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                consultaVenta()
              + "ORDER BY v.idVenta DESC"
            );

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(convertirVenta(rs));
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error listar ventas: " + e.getMessage());
        }

        return lista;
    }

    private void cargarDetallesVenta(Connection cn, Venta venta) throws SQLException {
        PreparedStatement ps = cn.prepareStatement(
            "SELECT "
          + "dv.idDetalleVenta, dv.cantidad, dv.precioUnitario, dv.subtotal, "
          + "p.idProducto, p.codigo, p.nombre, p.marca, "
          + "p.precioCompra, p.precioVenta, p.stock, p.stockMinimo, p.estado, "
          + "cat.idCategoria, cat.nombre AS nombreCategoria "
          + "FROM DetalleVenta dv "
          + "INNER JOIN Producto p ON dv.idProducto = p.idProducto "
          + "INNER JOIN Categoria cat ON p.idCategoria = cat.idCategoria "
          + "WHERE dv.idVenta = ?"
        );

        ps.setInt(1, venta.getIdVenta());

        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Categoria categoria = new Categoria();
            categoria.setIdCategoria(rs.getInt("idCategoria"));
            categoria.setNombre(rs.getString("nombreCategoria"));

            Producto producto = new Producto();
            producto.setIdProducto(rs.getInt("idProducto"));
            producto.setCodigo(rs.getString("codigo"));
            producto.setNombre(rs.getString("nombre"));
            producto.setMarca(rs.getString("marca"));
            producto.setPrecioCompra(rs.getDouble("precioCompra"));
            producto.setPrecioVenta(rs.getDouble("precioVenta"));
            producto.setStock(rs.getInt("stock"));
            producto.setStockMinimo(rs.getInt("stockMinimo"));
            producto.setEstado(rs.getBoolean("estado"));
            producto.setCategoria(categoria);

            DetalleVenta detalle = new DetalleVenta();
            detalle.setIdDetalleVenta(rs.getInt("idDetalleVenta"));
            detalle.setCantidad(rs.getInt("cantidad"));
            detalle.setPrecioUnitario(rs.getDouble("precioUnitario"));
            detalle.setProducto(producto);

            venta.getDetallesVenta().add(detalle);
        }

        rs.close();
        ps.close();
    }

    private void restaurarStockAntesEliminar(Connection cn, int idVenta) throws SQLException {
        PreparedStatement ps = cn.prepareStatement(
            "SELECT idProducto, cantidad FROM DetalleVenta WHERE idVenta = ?"
        );

        ps.setInt(1, idVenta);

        ResultSet rs = ps.executeQuery();

        PreparedStatement psStock = cn.prepareStatement(
            "UPDATE Producto SET stock = stock + ? WHERE idProducto = ?"
        );

        while (rs.next()) {
            psStock.setInt(1, rs.getInt("cantidad"));
            psStock.setInt(2, rs.getInt("idProducto"));
            psStock.executeUpdate();
        }

        rs.close();
        ps.close();
        psStock.close();
    }

    private boolean hayStockDisponible(Connection cn, int idProducto, int cantidad) throws SQLException {
        PreparedStatement ps = cn.prepareStatement(
            "SELECT stock FROM Producto WHERE idProducto = ?"
        );

        ps.setInt(1, idProducto);

        ResultSet rs = ps.executeQuery();

        boolean disponible = false;

        if (rs.next()) {
            disponible = rs.getInt("stock") >= cantidad;
        }

        rs.close();
        ps.close();

        return disponible;
    }

    private Venta convertirVenta(ResultSet rs) throws SQLException {
        Cliente cliente = new Cliente();
        cliente.setIdPersona(rs.getInt("idPersonaCliente"));
        cliente.setNombre(rs.getString("nombreCliente"));
        cliente.setApPaterno(rs.getString("apPaternoCliente"));
        cliente.setApMaterno(rs.getString("apMaternoCliente"));
        cliente.setPuntosAcumulados(rs.getInt("puntosAcumulados"));

        Empleado empleado = new Empleado();
        empleado.setIdPersona(rs.getInt("idPersonaEmpleado"));
        empleado.setNombre(rs.getString("nombreEmpleado"));
        empleado.setApPaterno(rs.getString("apPaternoEmpleado"));
        empleado.setApMaterno(rs.getString("apMaternoEmpleado"));
        empleado.setCodigoEmpleado(rs.getString("codigoEmpleado"));

        Venta venta = new Venta();
        venta.setIdVenta(rs.getInt("idVenta"));
        venta.setFecha(rs.getDate("fecha"));

        Time hora = rs.getTime("hora");
        venta.setHora(hora != null ? hora.toString() : "");

        venta.setSubtotal(rs.getDouble("subtotal"));
        venta.setIgv(rs.getDouble("igv"));
        venta.setTotal(rs.getDouble("total"));
        venta.setEstado(rs.getString("estado"));
        venta.setCliente(cliente);
        venta.setEmpleado(empleado);
        

        return venta;
    }

    private String consultaVenta() {
        return "SELECT "
             +"v.idVenta, v.fecha, v.hora, v.subtotal, v.igv, v.total, v.estado, "
             + "pCli.idPersona AS idPersonaCliente, "
             + "pCli.nombre AS nombreCliente, "
             + "pCli.apPaterno AS apPaternoCliente, "
             + "pCli.apMaterno AS apMaternoCliente, "
             + "c.puntosAcumulados, "
             + "pEmp.idPersona AS idPersonaEmpleado, "
             + "pEmp.nombre AS nombreEmpleado, "
             + "pEmp.apPaterno AS apPaternoEmpleado, "
             + "pEmp.apMaterno AS apMaternoEmpleado, "
             + "e.codigoEmpleado "
             + "FROM Venta v "
             + "INNER JOIN Cliente c ON v.idCliente = c.idCliente "
             + "INNER JOIN Persona pCli ON c.idPersona = pCli.idPersona "
             + "INNER JOIN Empleado e ON v.idEmpleado = e.idEmpleado "
             + "INNER JOIN Persona pEmp ON e.idPersona = pEmp.idPersona ";
    }

    private int obtenerIdCliente(Connection cn, int idPersona) throws SQLException {
        PreparedStatement ps = cn.prepareStatement(
            "SELECT idCliente FROM Cliente WHERE idPersona = ?"
        );

        ps.setInt(1, idPersona);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            int idCliente = rs.getInt("idCliente");
            rs.close();
            ps.close();
            return idCliente;
        }

        rs.close();
        ps.close();

        throw new SQLException("No se encontró el cliente.");
    }

    private int obtenerIdEmpleado(Connection cn, int idPersona) throws SQLException {
        PreparedStatement ps = cn.prepareStatement(
            "SELECT idEmpleado FROM Empleado WHERE idPersona = ?"
        );

        ps.setInt(1, idPersona);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            int idEmpleado = rs.getInt("idEmpleado");
            rs.close();
            ps.close();
            return idEmpleado;
        }

        rs.close();
        ps.close();

        throw new SQLException("No se encontró el empleado.");
    }

    private void hacerRollback(Connection cn) {
        try {
            if (cn != null) {
                cn.rollback();
            }
        } catch (SQLException e) {
            System.out.println("Error rollback venta: " + e.getMessage());
        }
    }
}
