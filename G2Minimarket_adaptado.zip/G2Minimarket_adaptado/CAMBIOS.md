# Código adaptado al informe (REQ-001 a REQ-057)

Se quitó del código lo que el Word no documenta. Todo lo demás quedó igual (MySQL/JDBC, capas, Dashboard con JFreeChart, reportes).

| Módulo | Qué documenta el Word | Cambio en el código |
|---|---|---|
| Empleados, Proveedores, Usuarios, Productos | Registrar, buscar, actualizar, **inactivar** (RN-013) | El botón "Eliminar" ahora solo **inactiva** (`inactivar...()` → `dao.desactivar()`). Se quitó el borrado físico (`DELETE`), el botón "Activar", el checkbox "Mostrar inactivos" y `listarTodos...` |
| Clientes | Registrar, buscar, actualizar | Se quitó Eliminar, Desactivar, Activar, "Mostrar inactivos" y `tieneVentasAsociadas` |
| Categorías | Registrar, buscar, actualizar | Se quitó Eliminar, Desactivar, Activar, "Mostrar inactivos" y `tieneProductosAsociados` |
| Asistencia | Registrar (entrada/salida) y buscar | Se quitó Eliminar (se conserva `actualizar`, necesario para registrar la hora de salida) |
| Compras / Ventas | Registrar, detalle, cálculos, stock, buscar | Se quitó `eliminar` y `anular` en DAO y controlador |
| Inventario | Mostrar, actualizar stock, estado, stock bajo | Se quitó `eliminar` en DAO y controlador (`registrar`/`actualizar` se conservan: los usa Productos) |

Verificación: compila sin errores con JDK 21 (FrmDashboard no se pudo compilar aquí por falta de JFreeChart; no se modificó). No se probó contra MySQL.
