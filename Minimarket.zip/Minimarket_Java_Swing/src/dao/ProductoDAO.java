package dao;

import java.util.List;
import modelo.Producto;

public class ProductoDAO implements CrudDAO<Producto> {

    private static final Almacen<Producto> ALMACEN = new Almacen<>(0);

    @Override
    public boolean registrar(Producto pro) {
        pro.setIdProducto(ALMACEN.siguienteId());
        ALMACEN.agregar(pro);
        return true;
    }

    @Override
    public boolean actualizar(Producto pro) {
        return ALMACEN.reemplazar(p -> p.getIdProducto() == pro.getIdProducto(), pro);
    }

    @Override
    public boolean eliminar(int idProducto) {
        if (tieneMovimientosAsociados(idProducto)) {
            return desactivar(idProducto);
        }
        return ALMACEN.quitar(p -> p.getIdProducto() == idProducto);
    }

    public boolean desactivar(int idProducto) {
        return cambiarEstado(idProducto, false);
    }

    public boolean activar(int idProducto) {
        return cambiarEstado(idProducto, true);
    }

    private boolean cambiarEstado(int idProducto, boolean estado) {
        Producto pro = buscarPorId(idProducto);
        if (pro == null) {
            return false;
        }
        pro.setEstado(estado);
        return true;
    }

    /** Un producto con ventas o con registro en inventario no se borra, solo se desactiva. */
    public boolean tieneMovimientosAsociados(int idProducto) {
        boolean enInventario = new InventarioDAO().existeProductoEnInventario(idProducto);
        boolean enVentas = new VentaDAO().listar().stream()
                .flatMap(v -> v.getDetallesVenta().stream())
                .anyMatch(d -> d.getProducto().getIdProducto() == idProducto);
        return enInventario || enVentas;
    }

    public Producto buscarPorId(int idProducto) {
        return ALMACEN.buscar(p -> p.getIdProducto() == idProducto).orElse(null);
    }

    public Producto buscarPorCodigo(String codigo) {
        return ALMACEN.buscar(p -> p.getCodigo().equalsIgnoreCase(codigo.trim())).orElse(null);
    }

    @Override
    public List<Producto> listar() {
        return ALMACEN.todos();
    }

    public List<Producto> listarActivos() {
        return ALMACEN.filtrar(Producto::isEstado);
    }

    public boolean existeCodigo(String codigo) {
        return ALMACEN.existe(p -> p.getCodigo().equalsIgnoreCase(codigo.trim()));
    }
}
