/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import dao.ProveedorDAO;
import modelo.Proveedor;
import java.util.List;
/**
 *
 * @author USUARIO
 */
public class ControladorProveedor {
private ProveedorDAO proveedorDAO;

    public ControladorProveedor() {
        proveedorDAO = new ProveedorDAO();
    }

    public boolean registrarProveedor(Proveedor pro) {

        if (pro == null) {
            return false;
        }

        if (proveedorDAO.existeDocumento(pro.getNroDocumento())) {
            return false;
        }

        if (proveedorDAO.existeRuc(pro.getRuc())) {
            return false;
        }

        return proveedorDAO.registrar(pro);
    }

    public boolean actualizarProveedor(Proveedor pro) {

        if (pro == null || pro.getIdPersona() <= 0) {
            return false;
        }

        return proveedorDAO.actualizar(pro);
    }

    public boolean eliminarProveedor(int idPersona) {

        if (idPersona <= 0) {
            return false;
        }

        return proveedorDAO.eliminar(idPersona);
    }

    public Proveedor buscarPorDocumento(String nroDocumento) {

        if (nroDocumento == null || nroDocumento.trim().isEmpty()) {
            return null;
        }

        return proveedorDAO.buscarPorDocumento(nroDocumento.trim());
    }

    public Proveedor buscarPorRuc(String ruc) {

        if (ruc == null || ruc.trim().isEmpty()) {
            return null;
        }

        return proveedorDAO.buscarPorRuc(ruc.trim());
    }

    public boolean existeDocumento(String nroDocumento) {

        if (nroDocumento == null || nroDocumento.trim().isEmpty()) {
            return false;
        }

        return proveedorDAO.existeDocumento(nroDocumento.trim());
    }

    public boolean existeRuc(String ruc) {

        if (ruc == null || ruc.trim().isEmpty()) {
            return false;
        }

        return proveedorDAO.existeRuc(ruc.trim());
    }
    
    public boolean activarProveedor(int idPersona){
        return proveedorDAO.activar(idPersona);
    }

    public List<Proveedor> listarProveedoresActivos(){
        return proveedorDAO.listarActivos();
    }

    public List<Proveedor> listarTodosLosProveedores(){
        return proveedorDAO.listar();
    }
    
    public List<Proveedor> listarProveedores() {
        return proveedorDAO.listarActivos();
    }
}
