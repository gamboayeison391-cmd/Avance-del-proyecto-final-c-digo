package dao;

import java.util.List;
import modelo.Empleado;

public class EmpleadoDAO implements CrudDAO<Empleado> {

    private static final Almacen<Empleado> ALMACEN = new Almacen<>(0);

    @Override
    public boolean registrar(Empleado emp) {
        emp.setIdPersona(ALMACEN.siguienteId());
        ALMACEN.agregar(emp);
        return true;
    }

    @Override
    public boolean actualizar(Empleado emp) {
        return ALMACEN.reemplazar(e -> e.getIdPersona() == emp.getIdPersona(), emp);
    }

    @Override
    public boolean eliminar(int idPersona) {
        if (tieneRelacionesAsociadas(idPersona)) {
            return desactivar(idPersona);
        }
        return ALMACEN.quitar(e -> e.getIdPersona() == idPersona);
    }

    public boolean activar(int idPersona) {
        return cambiarEstado(idPersona, true);
    }

    public boolean desactivar(int idPersona) {
        return cambiarEstado(idPersona, false);
    }

    private boolean cambiarEstado(int idPersona, boolean estado) {
        Empleado emp = ALMACEN.buscar(e -> e.getIdPersona() == idPersona).orElse(null);
        if (emp == null) {
            return false;
        }
        emp.setEstado(estado);
        return true;
    }

    public boolean tieneRelacionesAsociadas(int idPersona) {
        boolean tieneVentas = new VentaDAO().listar().stream()
                .anyMatch(v -> v.getEmpleado() != null && v.getEmpleado().getIdPersona() == idPersona);
        return tieneVentas || new UsuarioDAO().existeEmpleadoUsuario(idPersona);
    }

    public Empleado buscarPorDocumento(String nroDocumento) {
        return ALMACEN.buscar(e -> e.getNroDocumento().equals(nroDocumento)).orElse(null);
    }

    @Override
    public List<Empleado> listar() {
        return ALMACEN.todos();
    }

    public List<Empleado> listarActivos() {
        return ALMACEN.filtrar(Empleado::isEstado);
    }

    public boolean existeDocumento(String nroDocumento) {
        return ALMACEN.existe(e -> e.getNroDocumento().equals(nroDocumento));
    }

    public boolean existeCodigo(String codigoEmpleado) {
        return ALMACEN.existe(e -> e.getCodigoEmpleado().equalsIgnoreCase(codigoEmpleado));
    }
}
