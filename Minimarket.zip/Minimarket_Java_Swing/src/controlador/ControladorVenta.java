/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import dao.VentaDAO;
import java.util.List;
import modelo.Venta;

/**
 *
 * @author USUARIO
 */
public class ControladorVenta {
    private VentaDAO ventaDAO;
    public ControladorVenta() {
        ventaDAO = new VentaDAO();
    }

    public boolean registrarVenta(Venta venta) {

        if (venta == null) {
            return false;
        }

        if (venta.getCliente() == null) {
            return false;
        }

        if (venta.getEmpleado() == null) {
            return false;
        }

        if (venta.getDetallesVenta() == null
                || venta.getDetallesVenta().isEmpty()) {
            return false;
        }

        venta.calcularTotales();

        return ventaDAO.registrar(venta);
    }

    public boolean eliminarVenta(int idVenta) {

        if (idVenta <= 0) {
            return false;
        }

        return ventaDAO.eliminar(idVenta);
    }

    public Venta buscarVenta(int idVenta) {

        if (idVenta <= 0) {
            return null;
        }

        return ventaDAO.buscarPorId(idVenta);
    }

    public List<Venta> listarVentas() {
        return ventaDAO.listar();
    }
}
