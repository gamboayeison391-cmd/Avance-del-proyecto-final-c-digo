/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexion.ConexionBD;
import modelo.Proveedor;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author USUARIO
 */
public class ProveedorDAO {

    public boolean registrar(Proveedor pro) {
        Connection cn = null;

        try {
            cn = ConexionBD.conectar();
            cn.setAutoCommit(false);

            PreparedStatement psPersona = cn.prepareStatement(
                "INSERT INTO Persona "
              + "(tipoDocumento, nroDocumento, nombre, apPaterno, apMaterno, "
              + "fechaNacimiento, sexo, telefono, correo, direccion, estado) "
              + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS
            );

            cargarDatosPersona(psPersona, pro);
            psPersona.setBoolean(11, pro.isEstado());

            int resPersona = psPersona.executeUpdate();

            if (resPersona == 0) {
                cn.rollback();
                return false;
            }

            ResultSet rs = psPersona.getGeneratedKeys();

            int idPersona = 0;

            if (rs.next()) {
                idPersona = rs.getInt(1);
            } else {
                cn.rollback();
                return false;
            }

            PreparedStatement psProveedor = cn.prepareStatement(
                "INSERT INTO Proveedor (idPersona, ruc, razonSocial) "
              + "VALUES (?, ?, ?)"
            );

            psProveedor.setInt(1, idPersona);
            psProveedor.setString(2, pro.getRuc());
            psProveedor.setString(3, pro.getRazonSocial());

            int resProveedor = psProveedor.executeUpdate();

            rs.close();
            psPersona.close();
            psProveedor.close();

            if (resProveedor > 0) {
                cn.commit();
                return true;
            } else {
                cn.rollback();
                return false;
            }

        } catch (SQLException e) {
            hacerRollback(cn);
            System.out.println("Error registrar proveedor: " + e.getMessage());
            return false;

        } finally {
            ConexionBD.cerrar(cn);
        }
    }

    public boolean actualizar(Proveedor pro) {
        Connection cn = null;

        try {
            cn = ConexionBD.conectar();
            cn.setAutoCommit(false);

            PreparedStatement psPersona = cn.prepareStatement(
                "UPDATE Persona SET "
              + "tipoDocumento = ?, "
              + "nroDocumento = ?, "
              + "nombre = ?, "
              + "apPaterno = ?, "
              + "apMaterno = ?, "
              + "fechaNacimiento = ?, "
              + "sexo = ?, "
              + "telefono = ?, "
              + "correo = ?, "
              + "direccion = ?, "
              + "estado = ? "
              + "WHERE idPersona = ?"
            );

            cargarDatosPersona(psPersona, pro);
            psPersona.setBoolean(11, pro.isEstado());
            psPersona.setInt(12, pro.getIdPersona());

            int resPersona = psPersona.executeUpdate();

            PreparedStatement psProveedor = cn.prepareStatement(
                "UPDATE Proveedor SET "
              + "ruc = ?, "
              + "razonSocial = ? "
              + "WHERE idPersona = ?"
            );

            psProveedor.setString(1, pro.getRuc());
            psProveedor.setString(2, pro.getRazonSocial());
            psProveedor.setInt(3, pro.getIdPersona());

            int resProveedor = psProveedor.executeUpdate();

            psPersona.close();
            psProveedor.close();

            if (resPersona > 0 && resProveedor > 0) {
                cn.commit();
                return true;
            } else {
                cn.rollback();
                return false;
            }

        } catch (SQLException e) {
            hacerRollback(cn);
            System.out.println("Error actualizar proveedor: " + e.getMessage());
            return false;

        } finally {
            ConexionBD.cerrar(cn);
        }
    }

    
    public Proveedor buscarPorDocumento(String nroDocumento) {
        Proveedor pro = null;

        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "SELECT "
              + "p.idPersona, p.tipoDocumento, p.nroDocumento, p.nombre, "
              + "p.apPaterno, p.apMaterno, p.fechaNacimiento, p.sexo, "
              + "p.telefono, p.correo, p.direccion, p.estado, "
              + "pr.ruc, pr.razonSocial "
              + "FROM Persona p "
              + "INNER JOIN Proveedor pr ON p.idPersona = pr.idPersona "
              + "WHERE p.nroDocumento = ?"
            );

            ps.setString(1, nroDocumento);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                pro = convertirProveedor(rs);
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error buscar proveedor: " + e.getMessage());
        }

        return pro;
    }

    public Proveedor buscarPorRuc(String ruc) {
        Proveedor pro = null;

        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "SELECT "
              + "p.idPersona, p.tipoDocumento, p.nroDocumento, p.nombre, "
              + "p.apPaterno, p.apMaterno, p.fechaNacimiento, p.sexo, "
              + "p.telefono, p.correo, p.direccion, p.estado, "
              + "pr.ruc, pr.razonSocial "
              + "FROM Persona p "
              + "INNER JOIN Proveedor pr ON p.idPersona = pr.idPersona "
              + "WHERE pr.ruc = ?"
            );

            ps.setString(1, ruc);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                pro = convertirProveedor(rs);
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error buscar proveedor por RUC: " + e.getMessage());
        }

        return pro;
    }

    public List<Proveedor> listar() {
        List<Proveedor> lista = new ArrayList<>();

        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "SELECT "
              + "p.idPersona, p.tipoDocumento, p.nroDocumento, p.nombre, "
              + "p.apPaterno, p.apMaterno, p.fechaNacimiento, p.sexo, "
              + "p.telefono, p.correo, p.direccion, p.estado, "
              + "pr.ruc, pr.razonSocial "
              + "FROM Persona p "
              + "INNER JOIN Proveedor pr ON p.idPersona = pr.idPersona "
              + "ORDER BY p.idPersona DESC"
            );

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(convertirProveedor(rs));
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error listar proveedores: " + e.getMessage());
        }

        return lista;
    }
    
    public List<Proveedor> listarActivos() {
        List<Proveedor> lista = new ArrayList<>();
        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "SELECT "
              + "p.idPersona, p.tipoDocumento, p.nroDocumento, p.nombre, "
              + "p.apPaterno, p.apMaterno, p.fechaNacimiento, p.sexo, "
              + "p.telefono, p.correo, p.direccion, p.estado, "
              + "pr.ruc, pr.razonSocial "
              + "FROM Persona p "
              + "INNER JOIN Proveedor pr ON p.idPersona = pr.idPersona "
              + "WHERE p.estado = 1 "
              + "ORDER BY p.idPersona DESC"
            );

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(convertirProveedor(rs));
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error listar proveedores activos: " + e.getMessage());
        }

        return lista;
    }

    public boolean existeDocumento(String nroDocumento) {
        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "SELECT COUNT(*) FROM Persona WHERE nroDocumento = ?"
            );

            ps.setString(1, nroDocumento);

            ResultSet rs = ps.executeQuery();

            boolean existe = false;

            if (rs.next()) {
                existe = rs.getInt(1) > 0;
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

            return existe;

        } catch (SQLException e) {
            System.out.println("Error verificar documento proveedor: " + e.getMessage());
            return false;
        }
    }

    public boolean existeRuc(String ruc) {
        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "SELECT COUNT(*) FROM Proveedor WHERE ruc = ?"
            );

            ps.setString(1, ruc);

            ResultSet rs = ps.executeQuery();

            boolean existe = false;

            if (rs.next()) {
                existe = rs.getInt(1) > 0;
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

            return existe;

        } catch (SQLException e) {
            System.out.println("Error verificar RUC proveedor: " + e.getMessage());
            return false;
        }
    }

    public boolean desactivar(int idPersona) {
        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "UPDATE Persona SET estado = 0 WHERE idPersona = ?"
            );

            ps.setInt(1, idPersona);

            int res = ps.executeUpdate();

            ps.close();
            ConexionBD.cerrar(cn);

            return res > 0;

        } catch (SQLException e) {
            System.out.println("Error desactivar proveedor: " + e.getMessage());
            return false;
        }
    }

    private void cargarDatosPersona(PreparedStatement ps, Proveedor pro) throws SQLException {
        ps.setString(1, pro.getTipoDocumento());
        ps.setString(2, pro.getNroDocumento());
        ps.setString(3, pro.getNombre());
        ps.setString(4, pro.getApPaterno());
        ps.setString(5, pro.getApMaterno());

        if (pro.getFechaNacimiento() != null) {
            ps.setDate(6, new java.sql.Date(pro.getFechaNacimiento().getTime()));
        } else {
            ps.setNull(6, Types.DATE);
        }

        ps.setString(7, pro.getSexo());
        ps.setString(8, pro.getTelefono());
        ps.setString(9, pro.getCorreo());
        ps.setString(10, pro.getDireccion());
    }

    private Proveedor convertirProveedor(ResultSet rs) throws SQLException {
        Proveedor pro = new Proveedor();

        pro.setIdPersona(rs.getInt("idPersona"));
        pro.setTipoDocumento(rs.getString("tipoDocumento"));
        pro.setNroDocumento(rs.getString("nroDocumento"));
        pro.setNombre(rs.getString("nombre"));
        pro.setApPaterno(rs.getString("apPaterno"));
        pro.setApMaterno(rs.getString("apMaterno"));
        pro.setFechaNacimiento(rs.getDate("fechaNacimiento"));
        pro.setSexo(rs.getString("sexo"));
        pro.setTelefono(rs.getString("telefono"));
        pro.setCorreo(rs.getString("correo"));
        pro.setDireccion(rs.getString("direccion"));
        pro.setEstado(rs.getBoolean("estado"));

        pro.setRuc(rs.getString("ruc"));
        pro.setRazonSocial(rs.getString("razonSocial"));

        return pro;
    }

    private void hacerRollback(Connection cn) {
        try {
            if (cn != null) {
                cn.rollback();
            }
        } catch (SQLException e) {
            System.out.println("Error rollback proveedor: " + e.getMessage());
        }
    }
}
