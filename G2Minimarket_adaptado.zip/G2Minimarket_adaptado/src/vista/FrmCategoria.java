/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import util.Validaciones;

import controlador.ControladorCategoria;
import modelo.Categoria;
import java.util.List;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import util.Iconos;
import util.Mensajes;

/**
 *
 * @author UCF20429
 */
public class FrmCategoria extends JInternalFrame{
    
    private ControladorCategoria controlador = new ControladorCategoria();
    
    private JLabel lblTitulo, lblIdCategoria, lblNombre, lblDescripcion, lblEstado;

    private JTextField txtIdCategoria, txtNombre;
    private JTextArea txtDescripcion;
    private JComboBox<String> cboEstado;

    private JButton btnRegistrar, btnActualizar, btnBuscar;
    private JButton btnListar, btnLimpiar;
    

    private JTable tablaCategoria;
    private DefaultTableModel modeloTabla;
    private JScrollPane scrollTabla, scrollDescripcion;

    public FrmCategoria() {
        iniciarComponentes();
        listar();
    }

    private void iniciarComponentes() {
        setTitle("Gestión de Categorías");
        setSize(1200, 700);
        setClosable(true);
        setIconifiable(false);
        setMaximizable(false);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        lblTitulo = new JLabel("GESTIÓN DE CATEGORÍAS");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitulo.setBounds(420, 25, 400, 35);

        lblIdCategoria = new JLabel("ID Categoría:");
        lblIdCategoria.setBounds(180, 100, 120, 25);
        txtIdCategoria = new JTextField();
        txtIdCategoria.setBounds(300, 100, 180, 25);
        txtIdCategoria.setEditable(true);
        txtIdCategoria.setBackground(Color.WHITE);

        lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(550, 100, 100, 25);
        txtNombre = new JTextField();
        txtNombre.setBounds(650, 100, 300, 25);

        lblDescripcion = new JLabel("Descripción:");
        lblDescripcion.setBounds(180, 150, 120, 25);
        txtDescripcion = new JTextArea();
        txtDescripcion.setLineWrap(true);
        txtDescripcion.setWrapStyleWord(true);
        scrollDescripcion = new JScrollPane(txtDescripcion);
        scrollDescripcion.setBounds(300, 150, 650, 80);

        lblEstado = new JLabel("Estado:");
        lblEstado.setBounds(180, 250, 120, 25);
        cboEstado = new JComboBox<>();
        cboEstado.addItem("Activo");
        cboEstado.addItem("Inactivo");
        cboEstado.setBounds(300, 250, 180, 25);

        btnRegistrar = new JButton("Registrar");
        btnRegistrar.setBounds(220, 320, 110, 32);

        btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(350, 320, 110, 32);


        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(610, 320, 110, 32);

        //btnListar = new JButton("Listar");
        //btnListar.setBounds(740, 320, 100, 32);

        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(740, 320, 100, 32);
        
        
        //check
        
        //iconos de botones
        btnRegistrar.setIcon(Iconos.cargar("/imagenes/registrar.png", 20, 20));
        btnActualizar.setIcon(Iconos.cargar("/imagenes/actualizar.png", 20, 20));
        btnBuscar.setIcon(Iconos.cargar("/imagenes/buscar.png", 20, 20));
        //btnListar.setIcon(Iconos.cargar("/imagenes/listar.png", 20, 20));
        btnLimpiar.setIcon(Iconos.cargar("/imagenes/limpiar.png", 20, 20));

        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("ID Categoría");
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Descripción");
        modeloTabla.addColumn("Estado");

        tablaCategoria = new JTable(modeloTabla);
        scrollTabla = new JScrollPane(tablaCategoria);
        scrollTabla.setBounds(90, 390, 980, 210);
        tablaCategoria.setRowHeight(25);
        tablaCategoria.getTableHeader().setReorderingAllowed(false);
        tablaCategoria.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tablaCategoria.setAutoCreateRowSorter(true);
        tablaCategoria.setFillsViewportHeight(true);

        btnRegistrar.addActionListener(e -> registrar());
        btnActualizar.addActionListener(e -> actualizar());
        btnBuscar.addActionListener(e -> buscar());
        //btnListar.addActionListener(e -> listar());
        btnLimpiar.addActionListener(e -> limpiar());

        panel.add(lblTitulo);
        panel.add(lblIdCategoria);
        panel.add(txtIdCategoria);
        panel.add(lblNombre);
        panel.add(txtNombre);
        panel.add(lblDescripcion);
        panel.add(scrollDescripcion);
        panel.add(lblEstado);
        panel.add(cboEstado);

        panel.add(btnRegistrar);
        panel.add(btnActualizar);
        panel.add(btnBuscar);
        //panel.add(btnListar);
        panel.add(btnLimpiar);

        panel.add(scrollTabla);

        add(panel);
    }

    
    //Metodos
    private Categoria leerDatos() {
        Categoria cat = new Categoria();

        cat.setNombre(txtNombre.getText().trim());
        cat.setDescripcion(txtDescripcion.getText().trim());
        cat.setEstado(cboEstado.getSelectedItem().toString().equals("Activo"));

        return cat;
    }

    private void registrar() {
        if (!validarCampos()) {
            return;
        }
        Categoria cat = leerDatos();
    
        if (controlador.existeNombre(cat.getNombre())) {
            Mensajes.advertencia(this,"Ya existe una categoría con ese nombre.");
            txtNombre.requestFocus();
            return;
        }

        if (controlador.registrarCategoria(cat)) {
            Mensajes.exito(this, "Categoría registrada correctamente");
            listar();
            limpiar();
        } else {
            Mensajes.error(this, "No se pudo registrar la categoría");
        }
    }

    private void actualizar() {
        if (txtIdCategoria.getText().trim().isEmpty()) {
            Mensajes.advertencia(this, "Primero busque una categoría para actualizar.");
            return;
        }

        if (!validarCampos()) {
            return;
        }

        Categoria cat = leerDatos();
        cat.setIdCategoria(Integer.parseInt(txtIdCategoria.getText().trim()));

        Categoria actual = controlador.buscarPorId(cat.getIdCategoria());

        if (actual == null) {
            Mensajes.advertencia(this, "La categoría ya no existe.");
            return;
        }

        if (controlador.actualizarCategoria(cat)) {
            Mensajes.exito(this, "Categoría actualizada correctamente");
            listar();
            limpiar();
        } else {
            Mensajes.error(this, "No se pudo actualizar la categoría");
        }
    }

    //Validaciones para btn r y g
    private boolean validarCampos() {

        if (Validaciones.estaVacio(txtNombre.getText())) {
            Mensajes.advertencia(this, "Ingrese el nombre de la categoría");
            txtNombre.requestFocus();
            return false;
        }
    
        if (!Validaciones.soloLetras(txtNombre.getText().trim())) {
            Mensajes.advertencia(this, "El nombre de la categoría solo debe contener letras");
            txtNombre.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtDescripcion.getText())) {
            Mensajes.advertencia(this, "Ingrese la descripción");
            txtDescripcion.requestFocus();
            return false;
        }

        return true;
    }

    
    private void buscar() {
        if (txtIdCategoria.getText().trim().isEmpty()) {
            Mensajes.advertencia(this, "Ingrese el ID de la categoría");
            txtIdCategoria.requestFocus();
            return;
        }

        if (!Validaciones.enteroValido(txtIdCategoria.getText())) {
            Mensajes.advertencia(this, "Ingrese un ID válido.");
            return;
        }

        int id = Integer.parseInt(txtIdCategoria.getText().trim());

        Categoria cat = controlador.buscarPorId(id);

        if (cat != null) {
            txtNombre.setText(cat.getNombre());
            txtDescripcion.setText(cat.getDescripcion());
            cboEstado.setSelectedItem(cat.isEstado() ? "Activo" : "Inactivo");
    
            txtIdCategoria.setEditable(false);

            btnRegistrar.setEnabled(false);
            btnActualizar.setEnabled(true);


        } else {
            Mensajes.advertencia(this, "Categoría no encontrada");
        }
    }

    private void listar() {
        modeloTabla.setRowCount(0);

        List<Categoria> lista = controlador.listarTodasLasCategorias();

        for (Categoria cat : lista) {
            modeloTabla.addRow(new Object[]{
                cat.getIdCategoria(),
                cat.getNombre(),
                cat.getDescripcion(),
                cat.isEstado() ? "Activo" : "Inactivo"
            });
        }
    }

    private void limpiar() {
        txtIdCategoria.setText("");
        txtNombre.setText("");
        txtDescripcion.setText("");

        cboEstado.setSelectedIndex(0);

        txtIdCategoria.setEditable(true);

        btnRegistrar.setEnabled(true);
        btnActualizar.setEnabled(false);

        txtNombre.requestFocus();
    }
}
