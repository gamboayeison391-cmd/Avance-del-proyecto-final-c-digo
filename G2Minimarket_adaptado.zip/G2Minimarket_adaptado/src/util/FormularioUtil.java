/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.table.JTableHeader;

/**
 *
 * @author USUARIO
 */
public class FormularioUtil {
    // Configuración estándar para todas las tablas
    public static void configurarTabla(JTable tabla) {

        tabla.setRowHeight(25);
        tabla.setAutoCreateRowSorter(true);
        tabla.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tabla.setFillsViewportHeight(true);
        tabla.setGridColor(new Color(220, 220, 220));
        tabla.setShowGrid(true);

        JTableHeader cabecera = tabla.getTableHeader();
        cabecera.setReorderingAllowed(false);
        cabecera.setFont(new Font("Segoe UI", Font.BOLD, 13));
    }

    // Configuración estándar de botones
    public static void configurarBoton(javax.swing.JButton boton) {
        boton.setFocusPainted(false);
        boton.setFont(new Font("Segoe UI", Font.PLAIN, 13));
    }

    // Configuración estándar de campos solo lectura
    public static void soloLectura(javax.swing.JTextField txt) {
        txt.setEditable(false);
        txt.setBackground(Color.WHITE);
    }
}
