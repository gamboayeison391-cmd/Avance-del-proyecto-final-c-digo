/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author UCF20429
 */
public class DetalleVenta {
    private int idDetalleVenta;
    private int cantidad;
    private double precioUnitario;
    private double subtotal;

    // Relación con Producto
    private Producto producto;

    public DetalleVenta() {
    }

    public DetalleVenta(int idDetalleVenta,
                        int cantidad,
                        double precioUnitario,
                        double subtotal,
                        Producto producto) {

        this.idDetalleVenta = idDetalleVenta;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
        this.producto = producto;

        calcularSubtotal();
    }

    public int getIdDetalleVenta() {
        return idDetalleVenta;
    }

    public void setIdDetalleVenta(int idDetalleVenta) {
        this.idDetalleVenta = idDetalleVenta;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
        calcularSubtotal();
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
        calcularSubtotal();
    }

    public double getSubtotal() {
        return subtotal;
    }

    // Ya no existe setSubtotal()

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    //metodo    
    public void calcularSubtotal() {
        subtotal = cantidad * precioUnitario;
    }

    @Override
    public String toString() {
        return producto != null
                ? producto.getNombre()
                : "Detalle Venta";
    }
}