package dao;

import java.util.List;

/**
 * Contrato común de los DAO de mantenimiento (Categoría, Producto, Cliente).
 * Cada DAO implementa estas operaciones sobre su propia entidad T.
 */
public interface CrudDAO<T> {

    boolean registrar(T entidad);

    boolean actualizar(T entidad);

    boolean eliminar(int id);

    List<T> listar();
}
