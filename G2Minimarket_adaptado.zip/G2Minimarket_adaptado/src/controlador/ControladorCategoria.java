/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import dao.CategoriaDAO;
import modelo.Categoria;
import java.util.List;
/**
 *
 * @author USUARIO
 */
public class ControladorCategoria {
    private CategoriaDAO categoriaDAO;

    public ControladorCategoria() {
        categoriaDAO = new CategoriaDAO();
    }

    public boolean registrarCategoria(Categoria cat) {

        if (cat == null) {
            return false;
        }

        if (categoriaDAO.existeNombre(cat.getNombre())) {
            return false;
        }

        return categoriaDAO.registrar(cat);
    }

    public boolean actualizarCategoria(Categoria cat) {

        if (cat == null || cat.getIdCategoria() <= 0) {
            return false;
        }

        return categoriaDAO.actualizar(cat);
    }

    public Categoria buscarPorId(int idCategoria) {

        if (idCategoria <= 0) {
            return null;
        }

        return categoriaDAO.buscarPorId(idCategoria);
    }

    public List<Categoria> listarCategorias() {
        return categoriaDAO.listar();
    }

    public boolean existeNombre(String nombre) {

        if (nombre == null || nombre.trim().isEmpty()) {
            return false;
        }

        return categoriaDAO.existeNombre(nombre.trim());
    }
    
    
    public List<Categoria> listarCategoriasActivas() {
        return categoriaDAO.listarActivos();
    }

    public List<Categoria> listarTodasLasCategorias(){
        return categoriaDAO.listar();
    }
}
