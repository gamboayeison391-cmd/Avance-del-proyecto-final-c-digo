/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author UCF20429
 */
public class DetalleCompra {

    private int idDetalleCompra;
    private int cantidad;
    private double precioCompra;
    private double subtotal;

    // Relación con Producto
    private Producto producto;

    public DetalleCompra() {
    }

    public DetalleCompra(int idDetalleCompra,
                         int cantidad,
                         double precioCompra,
                         double subtotal,
                         Producto producto) {

        this.idDetalleCompra = idDetalleCompra;
        this.cantidad = cantidad;
        this.precioCompra = precioCompra;
        this.producto = producto;

        calcularSubtotal();
    }

    public int getIdDetalleCompra() {
        return idDetalleCompra;
    }

    public void setIdDetalleCompra(int idDetalleCompra) {
        this.idDetalleCompra = idDetalleCompra;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
        calcularSubtotal();
    }

    public double getPrecioCompra() {
        return precioCompra;
    }

    public void setPrecioCompra(double precioCompra) {
        this.precioCompra = precioCompra;
        calcularSubtotal();
    }

    public double getSubtotal() {
        return subtotal;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    //metodo
    public void calcularSubtotal() {
        subtotal = cantidad * precioCompra;
    }

    @Override
    public String toString() {
        return producto != null
                ? producto.getNombre()
                : "Detalle Compra";
    }
}
