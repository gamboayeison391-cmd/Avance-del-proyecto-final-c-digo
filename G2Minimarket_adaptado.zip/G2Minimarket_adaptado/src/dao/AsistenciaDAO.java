/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexion.ConexionBD;
import modelo.Asistencia;
import modelo.Empleado;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USUARIO
 */
public class AsistenciaDAO {

    public boolean registrar(Asistencia asistencia) {
        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "INSERT INTO Asistencia "
              + "(idEmpleado, fecha, horaEntrada, horaSalida, estado, observacion) "
              + "VALUES (?, ?, ?, ?, ?, ?)"
            );

            int idEmpleado = obtenerIdEmpleado(cn, asistencia.getEmpleado().getIdPersona());

            ps.setInt(1, idEmpleado);
            cargarDatosAsistencia(ps, asistencia);

            int res = ps.executeUpdate();

            ps.close();
            ConexionBD.cerrar(cn);

            return res > 0;

        } catch (SQLException e) {
            System.out.println("Error registrar asistencia: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizar(Asistencia asistencia) {
        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "UPDATE Asistencia SET "
              + "idEmpleado = ?, "
              + "fecha = ?, "
              + "horaEntrada = ?, "
              + "horaSalida = ?, "
              + "estado = ?, "
              + "observacion = ? "
              + "WHERE idAsistencia = ?"
            );

            int idEmpleado = obtenerIdEmpleado(cn, asistencia.getEmpleado().getIdPersona());

            ps.setInt(1, idEmpleado);
            cargarDatosAsistencia(ps, asistencia);
            ps.setInt(7, asistencia.getIdAsistencia());

            int res = ps.executeUpdate();

            ps.close();
            ConexionBD.cerrar(cn);

            return res > 0;

        } catch (SQLException e) {
            System.out.println("Error actualizar asistencia: " + e.getMessage());
            return false;
        }
    }

    public Asistencia buscarPorId(int idAsistencia) {
        Asistencia asistencia = null;

        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                consultaAsistencia()
              + "WHERE a.idAsistencia = ?"
            );

            ps.setInt(1, idAsistencia);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                asistencia = convertirAsistencia(rs);
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error buscar asistencia: " + e.getMessage());
        }

        return asistencia;
    }

    public List<Asistencia> listar() {
        List<Asistencia> lista = new ArrayList<>();

        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                consultaAsistencia()
              + "ORDER BY a.idAsistencia DESC"
            );

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(convertirAsistencia(rs));
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error listar asistencias: " + e.getMessage());
        }

        return lista;
    }

    public boolean existeAsistenciaHoy(int idPersona, java.util.Date fecha) {
        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "SELECT COUNT(*) "
              + "FROM Asistencia a "
              + "INNER JOIN Empleado e ON a.idEmpleado = e.idEmpleado "
              + "WHERE e.idPersona = ? AND a.fecha = ?"
            );

            ps.setInt(1, idPersona);
            ps.setDate(2, new java.sql.Date(fecha.getTime()));

            ResultSet rs = ps.executeQuery();

            boolean existe = false;

            if (rs.next()) {
                existe = rs.getInt(1) > 0;
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

            return existe;

        } catch (SQLException e) {
            System.out.println("Error verificar asistencia: " + e.getMessage());
            return false;
        }
    }

    private void cargarDatosAsistencia(PreparedStatement ps, Asistencia asistencia) throws SQLException {
        if (asistencia.getFecha() != null) {
            ps.setDate(2, new java.sql.Date(asistencia.getFecha().getTime()));
        } else {
            ps.setDate(2, new java.sql.Date(System.currentTimeMillis()));
        }

        colocarHora(ps, 3, asistencia.getHoraEntrada());
        colocarHora(ps, 4, asistencia.getHoraSalida());

        ps.setString(5, asistencia.getEstado());
        ps.setString(6, asistencia.getObservacion());
    }

    private void colocarHora(PreparedStatement ps, int posicion, String hora) throws SQLException {
        if (hora == null || hora.trim().isEmpty()) {
            ps.setNull(posicion, Types.TIME);
        } else {
            ps.setTime(posicion, Time.valueOf(hora));
        }
    }

    private Asistencia convertirAsistencia(ResultSet rs) throws SQLException {
        Empleado empleado = new Empleado();

        empleado.setIdPersona(rs.getInt("idPersona"));
        empleado.setNombre(rs.getString("nombre"));
        empleado.setApPaterno(rs.getString("apPaterno"));
        empleado.setApMaterno(rs.getString("apMaterno"));
        empleado.setCodigoEmpleado(rs.getString("codigoEmpleado"));

        Asistencia asistencia = new Asistencia();

        asistencia.setIdAsistencia(rs.getInt("idAsistencia"));
        asistencia.setFecha(rs.getDate("fecha"));
        asistencia.setHoraEntrada(convertirHora(rs.getTime("horaEntrada")));
        asistencia.setHoraSalida(convertirHora(rs.getTime("horaSalida")));
        asistencia.setEstado(rs.getString("estado"));
        asistencia.setObservacion(rs.getString("observacion"));
        asistencia.setEmpleado(empleado);

        return asistencia;
    }

    private String convertirHora(Time hora) {
        return hora != null ? hora.toString() : "";
    }

    private String consultaAsistencia() {
        return "SELECT "
             + "a.idAsistencia, a.fecha, a.horaEntrada, a.horaSalida, "
             + "a.estado, a.observacion, "
             + "p.idPersona, p.nombre, p.apPaterno, p.apMaterno, "
             + "e.codigoEmpleado "
             + "FROM Asistencia a "
             + "INNER JOIN Empleado e ON a.idEmpleado = e.idEmpleado "
             + "INNER JOIN Persona p ON e.idPersona = p.idPersona ";
    }

    private int obtenerIdEmpleado(Connection cn, int idPersona) throws SQLException {
        PreparedStatement ps = cn.prepareStatement(
            "SELECT idEmpleado FROM Empleado WHERE idPersona = ?"
        );

        ps.setInt(1, idPersona);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            int idEmpleado = rs.getInt("idEmpleado");

            rs.close();
            ps.close();

            return idEmpleado;
        }

        rs.close();
        ps.close();

        throw new SQLException("No se encontró el empleado.");
    }
}