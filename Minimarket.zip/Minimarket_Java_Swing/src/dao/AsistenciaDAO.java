package dao;

import java.util.Date;
import java.util.List;
import java.time.Instant;
import java.time.ZoneId;
import java.time.LocalDate;
import modelo.Asistencia;

/** Registros de asistencia temporales para demostración. */
public class AsistenciaDAO {
    private static final Almacen<Asistencia> ALMACEN = new Almacen<>(0);
    public boolean registrar(Asistencia a) {
        if (a == null) return false;
        a.setIdAsistencia(ALMACEN.siguienteId());
        if (a.getFecha() == null) a.setFecha(new Date());
        ALMACEN.agregar(a);
        return true;
    }
    public boolean actualizar(Asistencia a) {
        return a != null && ALMACEN.reemplazar(x -> x.getIdAsistencia() == a.getIdAsistencia(), a);
    }
    public boolean eliminar(int id) { return ALMACEN.quitar(x -> x.getIdAsistencia() == id); }
    public Asistencia buscarPorId(int id) { return ALMACEN.buscar(x -> x.getIdAsistencia() == id).orElse(null); }
    public List<Asistencia> listar() { return ALMACEN.todos(); }
    public boolean existeAsistenciaHoy(int idPersona, Date fecha) {
        if (fecha == null) return false;
        LocalDate dia = Instant.ofEpochMilli(fecha.getTime()).atZone(ZoneId.systemDefault()).toLocalDate();
        return ALMACEN.existe(a -> a.getEmpleado() != null && a.getEmpleado().getIdPersona() == idPersona &&
            a.getFecha() != null && Instant.ofEpochMilli(a.getFecha().getTime()).atZone(ZoneId.systemDefault()).toLocalDate().equals(dia));
    }
}
