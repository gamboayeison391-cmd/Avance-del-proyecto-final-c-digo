/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author UCF20429
 */
public class Proveedor extends Persona {

    private String ruc;
    private String razonSocial;

    // Relación con Compra
    private ArrayList<Compra> compras;

    public Proveedor() {
        compras = new ArrayList<>();
    }

    public Proveedor(String ruc,
                     String razonSocial,
                     ArrayList<Compra> compras,
                     int idPersona,
                     String tipoDocumento,
                     String nroDocumento,
                     String nombre,
                     String apPaterno,
                     String apMaterno,
                     Date fechaNacimiento,
                     String sexo,
                     String telefono,
                     String correo,
                     String direccion,
                     boolean estado) {

        super(idPersona, tipoDocumento, nroDocumento,
                nombre, apPaterno, apMaterno,
                fechaNacimiento, sexo,
                telefono, correo,
                direccion, estado);

        this.ruc = ruc;
        this.razonSocial = razonSocial;
        this.compras = compras;
    }

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public String getRazonSocial() {
        return razonSocial;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }

    public ArrayList<Compra> getCompras() {
        return compras;
    }

    public void setCompras(ArrayList<Compra> compras) {
        this.compras = compras;
    }

    public String getNombreCompleto() {
        return getNombre() + " " + getApPaterno() + " " + getApMaterno();
    }

    public boolean tieneRucValido() {
        return ruc != null && ruc.matches("\\d{11}");
    }

    public boolean tieneCompras() {
        return compras != null && !compras.isEmpty();
    }

    @Override
    public String toString() {
        return razonSocial;
    }
}
