/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author UCF20429
 */
public class Compra {
    private int idCompra;
    private Date fecha;
    private double total;
    private String estado = "ACTIVA";

    // Relaciones
    private Proveedor proveedor;
    private Empleado empleado;
    private ArrayList<DetalleCompra> detallesCompra;

    public Compra() {
        detallesCompra = new ArrayList<>();
    }

    public Compra(int idCompra,
                  Date fecha,
                  double total,
                  Proveedor proveedor,
                  Empleado empleado,
                  ArrayList<DetalleCompra> detallesCompra) {

        this.idCompra = idCompra;
        this.fecha = fecha;
        this.total = total;
        this.proveedor = proveedor;
        this.empleado = empleado;
        this.detallesCompra = detallesCompra;
    }

    public int getIdCompra() {
        return idCompra;
    }

    public void setIdCompra(int idCompra) {
        this.idCompra = idCompra;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public void setProveedor(Proveedor proveedor) {
        this.proveedor = proveedor;
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

    public ArrayList<DetalleCompra> getDetallesCompra() {
        return detallesCompra;
    }

    public void setDetallesCompra(ArrayList<DetalleCompra> detallesCompra) {
        this.detallesCompra = detallesCompra;
    }
    
    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    //metodos
    public void agregarDetalle(DetalleCompra detalle) {
        detallesCompra.add(detalle);
        calcularTotal();
    }

    public void eliminarDetalle(DetalleCompra detalle) {
        detallesCompra.remove(detalle);
        calcularTotal();
    }

    public void calcularTotal() {

        total = 0;

        for (DetalleCompra detalle : detallesCompra) {
            total += detalle.getSubtotal();
        }
    }

    public int cantidadProductos() {
        return detallesCompra.size();
    }

    @Override
    public String toString() {
        return "Compra N° " + idCompra;
    }
}
