/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import dao.InventarioDAO;
import java.util.List;
import modelo.Inventario;

/**
 *
 * @author USUARIO
 */
public class ControladorInventario {
    private InventarioDAO inventarioDAO;

    public ControladorInventario() {
        inventarioDAO = new InventarioDAO();
    }

    public boolean registrarInventario(Inventario inventario, int idProducto) {

        if (inventarioDAO.existeProductoEnInventario(idProducto)) {
            System.out.println("El producto ya existe en el inventario.");
            return false;
        }

        return inventarioDAO.registrar(inventario, idProducto);
    }

    public boolean actualizarInventario(Inventario inventario, int idProducto) {
        return inventarioDAO.actualizar(inventario, idProducto);
    }

    public Inventario buscarPorId(int idInventario) {
        return inventarioDAO.buscarPorId(idInventario);
    }

    public List<Inventario> listarInventario() {
        return inventarioDAO.listar();
    }

    public boolean existeProductoEnInventario(int idProducto) {
        return inventarioDAO.existeProductoEnInventario(idProducto);
    }
    
    //actualizar
    public boolean actualizarStock(Inventario inventario, int nuevoStock) {
        if (inventario == null) {
            return false;
        }

        if (inventario.getProductos() == null || inventario.getProductos().isEmpty()) {
            System.out.println("El inventario no tiene producto asociado.");
            return false;
        }

        inventario.setStockActual(nuevoStock);
        inventario.setFechaActualizacion(new java.util.Date());

        if (nuevoStock == 0) {
            inventario.setEstado("Sin stock");
        } else if (nuevoStock <= inventario.getStockMinimo()) {
            inventario.setEstado("Stock bajo");
        } else {
            inventario.setEstado("Normal");
        }
        int idProducto = inventario.getProductos().get(0).getIdProducto();  
        return inventarioDAO.actualizar(inventario, idProducto);
    }
    
    public Inventario buscarPorProducto(int idProducto) {
        return inventarioDAO.buscarPorProducto(idProducto);
    }
}
