/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import util.Validaciones;

import controlador.ControladorCliente;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import modelo.Cliente;
import util.Iconos;
import util.Mensajes;

/**
 *
 * @author UCF20429
 */
public class FrmCliente extends JInternalFrame {

    private final ControladorCliente controlador;
    private final SimpleDateFormat formato;

    private JPanel panel;

    private JLabel lblTitulo;
    private JLabel lblId;
    private JLabel lblTipoDocumento;
    private JLabel lblNumeroDocumento;
    private JLabel lblNombre;
    private JLabel lblApPaterno;
    private JLabel lblApMaterno;
    private JLabel lblFechaNacimiento;
    private JLabel lblSexo;
    private JLabel lblTelefono;
    private JLabel lblCorreo;
    private JLabel lblDireccion;
    private JLabel lblPuntos;

    private JTextField txtId;
    private JTextField txtNumeroDocumento;
    private JTextField txtNombre;
    private JTextField txtApPaterno;
    private JTextField txtApMaterno;
    private JTextField txtFechaNacimiento;
    private JTextField txtTelefono;
    private JTextField txtCorreo;
    private JTextField txtDireccion;
    private JTextField txtPuntos;

    private JComboBox<String> cboTipoDocumento;
    private JComboBox<String> cboSexo;

    private JButton btnRegistrar;
    private JButton btnActualizar;
    private JButton btnEliminar;
    private JButton btnBuscar;
    private JButton btnListar;
    private JButton btnLimpiar;
    private JButton btnActivar;
    
    private JCheckBox chkMostrarInactivos;

    private JLabel lblListaClientes;
    private JTable tablaClientes;
    private DefaultTableModel modeloTabla;
    
    private JScrollPane scroll;

    public FrmCliente() {

        controlador = new ControladorCliente();
        formato = new SimpleDateFormat("dd/MM/yyyy");

        initComponents();

        listar();
    }

    private void initComponents() {

        setTitle("Gestión de Clientes");
        setSize(1050, 650);
        setClosable(true);
        setIconifiable(false);
        setMaximizable(false);
        setResizable(false);

        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        lblTitulo = new JLabel("GESTIÓN DE CLIENTES");
        lblTitulo.setFont(new Font("new Font",Font.BOLD,22));
        lblTitulo.setBounds(430,20,400,33);

        lblId = new JLabel("ID");
        lblId.setBounds(80,90,100,25);
        txtId = new JTextField();
        txtId.setBounds(180,90,100,25);
        txtId.setEditable(false);
        txtId.setHorizontalAlignment(JTextField.CENTER);

        lblTipoDocumento = new JLabel("Tipo Documento");
        lblTipoDocumento.setBounds(320,90,120,25);
        cboTipoDocumento = new JComboBox<>();
        cboTipoDocumento.addItem("DNI");
        cboTipoDocumento.addItem("Carnet");
        cboTipoDocumento.addItem("Pasaporte");
        cboTipoDocumento.setBounds(440,90,140,25);

        
        lblNumeroDocumento = new JLabel("N° Documento");
        lblNumeroDocumento.setBounds(630,90,120,25);
        txtNumeroDocumento = new JTextField();
        txtNumeroDocumento.setBounds(760,90,180,25);

        lblNombre = new JLabel("Nombre");
        lblNombre.setBounds(80,135,100,25);
        txtNombre = new JTextField();
        txtNombre.setBounds(180,135,200,25);

        lblApPaterno = new JLabel("Apellido Paterno");
        lblApPaterno.setBounds(420,135,120,25);
        txtApPaterno = new JTextField();
        txtApPaterno.setBounds(520,135,170,25);

        lblApMaterno = new JLabel("Apellido Materno");
        lblApMaterno.setBounds(740,135,120,25);
        txtApMaterno = new JTextField();
        txtApMaterno.setBounds(860,135,180,25);

        lblFechaNacimiento = new JLabel("Fecha Nacimiento");
        lblFechaNacimiento.setBounds(80,180,120,25);
        txtFechaNacimiento = new JTextField();
        txtFechaNacimiento.setBounds(180,180,170,25);

        lblSexo = new JLabel("Sexo");
        lblSexo.setBounds(390,180,70,25);
        cboSexo = new JComboBox<>();
        cboSexo.addItem("Masculino");
        cboSexo.addItem("Femenino");
        cboSexo.setBounds(450,180,150,25);

        lblTelefono = new JLabel("Teléfono");
        lblTelefono.setBounds(650,180,80,25);
        txtTelefono = new JTextField();
        txtTelefono.setBounds(740,180,180,25);

        lblCorreo = new JLabel("Correo");
        lblCorreo.setBounds(80,225,100,25);
        txtCorreo = new JTextField();
        txtCorreo.setBounds(180,225,280,25);

        lblDireccion = new JLabel("Dirección");
        lblDireccion.setBounds(500,225,80,25);
        txtDireccion = new JTextField();
        txtDireccion.setBounds(590,225,370,25);

        
        lblPuntos = new JLabel("Puntos");
        lblPuntos.setBounds(80,270,80,25);
        txtPuntos = new JTextField();
        txtPuntos.setBounds(180,270,100,25);
        txtPuntos.setHorizontalAlignment(JTextField.CENTER);
        txtPuntos.setText("0");
        txtPuntos.setEditable(false);
        txtPuntos.setBackground(Color.WHITE);

        //botone
        btnRegistrar = new JButton("Registrar");
        btnRegistrar.setBounds(320,270,110,32);
        //btnRegistrar.setBackground(new Color(46,204,113));
        //btnRegistrar.setForeground(Color.WHITE);
        btnRegistrar.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(450,270,110,32);
        btnActualizar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        //btnActualizar.setBackground(new Color(52,152,219));
        //btnActualizar.setForeground(Color.WHITE);

        btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(580,270,110,32);
        btnEliminar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        //btnEliminar.setBackground(new Color(231,76,60));
        //btnEliminar.setForeground(Color.WHITE);

        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(710,270,110,32);
        btnBuscar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        //btnBuscar.setBackground(new Color(241,196,15));

        //btnListar = new JButton("Listar");
        //btnListar.setBounds(840,270,90,32);
        //btnListar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        //btnListar.setBackground(new Color(155,89,182));
        //btnListar.setForeground(Color.WHITE);

        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(950,270,100,32);
        btnLimpiar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        //btnLimpiar.setBackground(new Color(149,165,166));
        //btnLimpiar.setForeground(Color.WHITE);
        
        btnActivar = new JButton("Activar");
        btnActivar.setBounds(840,270,100,32);
        btnActivar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        //check inactivos
        chkMostrarInactivos = new JCheckBox("Mostrar inactivos");
        chkMostrarInactivos.setBounds(930, 320, 180, 25);
        chkMostrarInactivos.setBackground(Color.WHITE);
        
        //iconos de botones
        btnRegistrar.setIcon(Iconos.cargar("/imagenes/registrar.png", 20, 20));
        btnActualizar.setIcon(Iconos.cargar("/imagenes/actualizar.png", 20, 20));
        btnEliminar.setIcon(Iconos.cargar("/imagenes/eliminar.png", 20, 20));
        btnBuscar.setIcon(Iconos.cargar("/imagenes/buscar.png", 20, 20));
        //btnListar.setIcon(Iconos.cargar("/imagenes/listar.png", 20, 20));
        btnLimpiar.setIcon(Iconos.cargar("/imagenes/limpiar.png", 20, 20));
        btnActivar.setIcon(Iconos.cargar("/imagenes/actualizar.png", 20, 20));
        
        //Color para botones
        Color boton = new Color(240,240,240);
        btnRegistrar.setBackground(boton);
        btnActualizar.setBackground(boton);
        btnEliminar.setBackground(boton);
        btnBuscar.setBackground(boton);
        btnLimpiar.setBackground(boton);
        btnActivar.setBackground(boton);
        
        

        //titulo tabla
        lblListaClientes = new JLabel("LISTADO DE CLIENTES");
        lblListaClientes.setFont(new Font("Arial", Font.BOLD, 14));
        lblListaClientes.setBounds(80, 325, 250, 25);
        
        
        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("ID");
        modeloTabla.addColumn("Tipo Doc.");
        modeloTabla.addColumn("N° Documento");
        modeloTabla.addColumn("Nombre Completo");
        modeloTabla.addColumn("Teléfono");
        modeloTabla.addColumn("Correo");
        modeloTabla.addColumn("Puntos");
        modeloTabla.addColumn("Tipo Cliente");
        modeloTabla.addColumn("Estado");

        
        btnRegistrar.addActionListener(e -> registrar());
        btnActualizar.addActionListener(e -> actualizar());
        btnEliminar.addActionListener(e -> eliminar());
        btnBuscar.addActionListener(e -> buscar());
        //btnListar.addActionListener(e -> listar());
        btnLimpiar.addActionListener(e -> limpiar());
        btnActivar.addActionListener(e -> activar());
        chkMostrarInactivos.addActionListener(e -> listar());
        
        
        
        tablaClientes = new JTable(modeloTabla);

        //Mjoras en la tabla
        tablaClientes.setRowHeight(25);
        tablaClientes.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD,13));
        tablaClientes.getTableHeader().setBackground(new Color(52,73,94));
        tablaClientes.getTableHeader().setForeground(Color.WHITE);
        
        scroll = new JScrollPane(tablaClientes);
        scroll.setBounds(80,355,980,230);
        panel.add(lblListaClientes);
     

        panel.add(lblTitulo);
        panel.add(lblId);
        panel.add(txtId);

        panel.add(lblTipoDocumento);
        panel.add(cboTipoDocumento);

        panel.add(lblNumeroDocumento);
        panel.add(txtNumeroDocumento);

        panel.add(lblNombre);
        panel.add(txtNombre);

        panel.add(lblApPaterno);
        panel.add(txtApPaterno);

        panel.add(lblApMaterno);
        panel.add(txtApMaterno);

        panel.add(lblFechaNacimiento);
        panel.add(txtFechaNacimiento);

        panel.add(lblSexo);
        panel.add(cboSexo);

        panel.add(lblTelefono);
        panel.add(txtTelefono);

        panel.add(lblCorreo);
        panel.add(txtCorreo);

        panel.add(lblDireccion);
        panel.add(txtDireccion);

        panel.add(lblPuntos);
        panel.add(txtPuntos);

        panel.add(btnRegistrar);
        panel.add(btnActualizar);
        panel.add(btnEliminar);
        panel.add(btnBuscar);
        //panel.add(btnListar);
        panel.add(btnLimpiar);
        panel.add(btnActivar);
        panel.add(chkMostrarInactivos);

        panel.add(scroll);

        add(panel);
    }
    
    //
    private Cliente leerDatos() throws Exception {

        Cliente cli = new Cliente();

        cli.setTipoDocumento(cboTipoDocumento.getSelectedItem().toString());
        cli.setNroDocumento(txtNumeroDocumento.getText().trim());
        cli.setNombre(txtNombre.getText().trim());
        cli.setApPaterno(txtApPaterno.getText().trim());
        cli.setApMaterno(txtApMaterno.getText().trim());

        if (!txtFechaNacimiento.getText().trim().isEmpty()) {
            cli.setFechaNacimiento(formato.parse(txtFechaNacimiento.getText().trim()));
        }

        cli.setSexo(cboSexo.getSelectedItem().toString());
        cli.setTelefono(txtTelefono.getText().trim());
        cli.setCorreo(txtCorreo.getText().trim());
        cli.setDireccion(txtDireccion.getText().trim());
        cli.setEstado(true);
    
        if (txtPuntos.getText().trim().isEmpty()) {
            cli.setPuntosAcumulados(0);
        } else {
            cli.setPuntosAcumulados(Integer.parseInt(txtPuntos.getText().trim()));
        }

        return cli;
    }

    private void registrar() {
        try {
            if (!validarCampos()) {
                return;
            }
            Cliente cli = leerDatos();
        
            if (controlador.existeDocumento(cli.getNroDocumento())) {
                Mensajes.advertencia(this, "Ya existe un cliente registrado con ese documento.");
                txtNumeroDocumento.requestFocus();
                return;
            }
            
            if (controlador.registrarCliente(cli)) {
                Mensajes.exito(this, "Cliente registrado correctamente");
                listar();
                limpiar();
                } else {
                    Mensajes.error(this, "No se pudo registrar el cliente");
                }
            } catch (Exception e) {
            Mensajes.error(this, "Error: revise los datos ingresados");
        }
    }

    private void actualizar() {
        try {
            if (txtId.getText().trim().isEmpty()) {
                Mensajes.advertencia(this, "Primero busque un cliente para actualizar.");
                txtNumeroDocumento.requestFocus();
                return;
            }
            if (!validarCampos()) {
                return;
            }

            Cliente cli = leerDatos();
            cli.setIdPersona(Integer.parseInt(txtId.getText().trim()));

            if (controlador.actualizarCliente(cli)) {
                JOptionPane.showMessageDialog(this, "Cliente actualizado correctamente");
                listar();
                limpiar();
                } else {
                    JOptionPane.showMessageDialog(this, "No se pudo actualizar el cliente");
                }
            } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: revise los datos ingresados");
        }
    }
    
    //Validaciones para btn registrar y actualizar

    private boolean validarCampos() {

    if (Validaciones.estaVacio(txtNumeroDocumento.getText())) {
        JOptionPane.showMessageDialog(this, "Ingrese el número de documento");
        txtNumeroDocumento.requestFocus();
        return false;
    }

    if (cboTipoDocumento.getSelectedItem().toString().equals("DNI")
            && !Validaciones.dniValido(txtNumeroDocumento.getText().trim())) {
        JOptionPane.showMessageDialog(this, "El DNI debe tener 8 dígitos");
        txtNumeroDocumento.requestFocus();
        return false;
    }

    if (Validaciones.estaVacio(txtNombre.getText())) {
        JOptionPane.showMessageDialog(this, "Ingrese el nombre");
        txtNombre.requestFocus();
        return false;
    }

    if (!Validaciones.soloLetras(txtNombre.getText().trim())) {
        JOptionPane.showMessageDialog(this, "El nombre solo debe contener letras");
        txtNombre.requestFocus();
        return false;
    }

    if (Validaciones.estaVacio(txtApPaterno.getText())) {
        JOptionPane.showMessageDialog(this, "Ingrese el apellido paterno");
        txtApPaterno.requestFocus();
        return false;
    }

    if (!Validaciones.soloLetras(txtApPaterno.getText().trim())) {
        JOptionPane.showMessageDialog(this, "El apellido paterno solo debe contener letras");
        txtApPaterno.requestFocus();
        return false;
    }

    if (Validaciones.estaVacio(txtApMaterno.getText())) {
        JOptionPane.showMessageDialog(this, "Ingrese el apellido materno");
        txtApMaterno.requestFocus();
        return false;
    }

    if (!Validaciones.soloLetras(txtApMaterno.getText().trim())) {
        JOptionPane.showMessageDialog(this, "El apellido materno solo debe contener letras");
        txtApMaterno.requestFocus();
        return false;
    }

    if (Validaciones.estaVacio(txtFechaNacimiento.getText())) {
        JOptionPane.showMessageDialog(this, "Ingrese la fecha de nacimiento");
        txtFechaNacimiento.requestFocus();
        return false;
    }

    if (!Validaciones.fechaValida(txtFechaNacimiento.getText().trim())) {
        JOptionPane.showMessageDialog(this, "La fecha debe tener formato dd/MM/yyyy");
        txtFechaNacimiento.requestFocus();
        return false;
    }

    if (Validaciones.estaVacio(txtTelefono.getText())) {
        JOptionPane.showMessageDialog(this, "Ingrese el teléfono");
        txtTelefono.requestFocus();
        return false;
    }

    if (!Validaciones.telefonoValido(txtTelefono.getText().trim())) {
        JOptionPane.showMessageDialog(this, "El teléfono debe tener 9 dígitos");
        txtTelefono.requestFocus();
        return false;
    }

    if (Validaciones.estaVacio(txtCorreo.getText())) {
        JOptionPane.showMessageDialog(this, "Ingrese el correo");
        txtCorreo.requestFocus();
        return false;
    }

    if (!Validaciones.correoValido(txtCorreo.getText().trim())) {
        JOptionPane.showMessageDialog(this, "Ingrese un correo válido");
        txtCorreo.requestFocus();
        return false;
    }

    if (Validaciones.estaVacio(txtDireccion.getText())) {
        JOptionPane.showMessageDialog(this, "Ingrese la dirección");
        txtDireccion.requestFocus();
        return false;
    }

    if (!Validaciones.estaVacio(txtPuntos.getText())
            && !Validaciones.enteroValido(txtPuntos.getText().trim())) {
        JOptionPane.showMessageDialog(this, "Los puntos deben ser numéricos");
        txtPuntos.requestFocus();
        return false;
    }
    return true;
    }

    private void eliminar() {
        if (txtId.getText().trim().isEmpty()) {
            Mensajes.advertencia(this, "Primero busque el cliente que desea eliminar.");
            return;
        }

        int idPersona = Integer.parseInt(txtId.getText().trim());
    
        if (!Mensajes.confirmar(this, "¿Está seguro de eliminar este cliente?")) {
            return;
        }

        if (controlador.tieneVentasAsociadas(idPersona)) {

            if (controlador.desactivarCliente(idPersona)) {
                Mensajes.advertencia(this,
                    "El cliente tiene ventas registradas.\n"
                    + "Por seguridad, no se eliminó. Se desactivó para conservar el historial.");
                listar();
                limpiar();
            } else {
                Mensajes.error(this, "No se pudo desactivar el cliente.");
            }

        } else {

            if (controlador.eliminarCliente(idPersona)) {
                Mensajes.exito(this, "Cliente eliminado correctamente.");
                listar();
                limpiar();
            } else {
                Mensajes.error(this, "No se pudo eliminar el cliente.");
            }
        }
    }
    
    private void activar() {
        if (txtId.getText().trim().isEmpty()) {
            Mensajes.advertencia(this, "Primero busque el cliente que desea activar.");
            return;
        }

        int idPersona = Integer.parseInt(txtId.getText().trim());
        if (!Mensajes.confirmar(this, "¿Desea activar este cliente?")) {
            return;
        }

        if (controlador.activarCliente(idPersona)) {
            Mensajes.exito(this, "Cliente activado correctamente.");
            listar();
            limpiar();
        } else {
            Mensajes.error(this, "No se pudo activar el cliente.");
        }
    }

    private void buscar() {
        String documento = txtNumeroDocumento.getText().trim();

        if (documento.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese el número de documento");
            txtNumeroDocumento.requestFocus();
            return;
        }

        Cliente cli = controlador.buscarPorDocumento(documento);

        if (cli != null) {
            txtId.setText(String.valueOf(cli.getIdPersona()));
            cboTipoDocumento.setSelectedItem(cli.getTipoDocumento());
            txtNumeroDocumento.setText(cli.getNroDocumento());
            txtNombre.setText(cli.getNombre());
            txtApPaterno.setText(cli.getApPaterno());
            txtApMaterno.setText(cli.getApMaterno());

            if (cli.getFechaNacimiento() != null) {
                txtFechaNacimiento.setText(formato.format(cli.getFechaNacimiento()));
            }

            cboSexo.setSelectedItem(cli.getSexo());
            txtTelefono.setText(cli.getTelefono());
            txtCorreo.setText(cli.getCorreo());
            txtDireccion.setText(cli.getDireccion());
            txtPuntos.setText(String.valueOf(cli.getPuntosAcumulados()));

            txtNumeroDocumento.setEditable(false);

            btnRegistrar.setEnabled(false);
            btnActualizar.setEnabled(true);
            btnEliminar.setEnabled(true);

            if (cli.isEstado()) {
                btnActivar.setEnabled(false);
            } else {
                btnActivar.setEnabled(true);
            }

        } else {
            JOptionPane.showMessageDialog(this, "Cliente no encontrado");
        }
    }

    private void listar() {
        modeloTabla.setRowCount(0);
        
        List<Cliente> lista;

        if (chkMostrarInactivos.isSelected()) {
            lista = controlador.listarTodosLosClientes();
        } else {
            lista = controlador.listarClientesActivos();
        }
        
        for (Cliente cli : lista) {
            modeloTabla.addRow(new Object[]{
               cli.getIdPersona(),
               cli.getTipoDocumento(),
               cli.getNroDocumento(),
               cli.getNombreCompleto(),
               cli.getTelefono(),
               cli.getCorreo(),
               cli.getPuntosAcumulados(),
               cli.getTipoCliente(),
               cli.isEstado() ? "Activo" : "Inactivo"
           });
        }
    }
    
    private void limpiar() {
        txtId.setText("");
        txtNumeroDocumento.setText("");
        txtNombre.setText("");
        txtApPaterno.setText("");
        txtApMaterno.setText("");
        txtFechaNacimiento.setText("");
        txtTelefono.setText("");
        txtCorreo.setText("");
        txtDireccion.setText("");
        txtPuntos.setText("0");

        cboTipoDocumento.setSelectedIndex(0);
        cboSexo.setSelectedIndex(0);

        txtNumeroDocumento.setEditable(true);

        btnRegistrar.setEnabled(true);
        btnActualizar.setEnabled(false);
        btnEliminar.setEnabled(false);
        btnActivar.setEnabled(false);

        txtNumeroDocumento.requestFocus();
    }
}