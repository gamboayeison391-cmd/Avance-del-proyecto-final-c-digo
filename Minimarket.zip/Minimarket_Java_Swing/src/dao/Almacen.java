package dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

/**
 * Almacén temporal en memoria utilizado por el prototipo Java Swing.
 * Cada DAO guarda sus entidades en un Almacen propio (compartido entre pantallas).
 */
public class Almacen<T> {

    private final List<T> datos = new ArrayList<>();
    private int ultimoId;

    public Almacen(int idInicial) {
        this.ultimoId = idInicial;
    }

    public int siguienteId() {
        return ++ultimoId;
    }

    public void agregar(T entidad) {
        datos.add(entidad);
    }

    public Optional<T> buscar(Predicate<T> condicion) {
        return datos.stream().filter(condicion).findFirst();
    }

    public boolean existe(Predicate<T> condicion) {
        return datos.stream().anyMatch(condicion);
    }

    public List<T> filtrar(Predicate<T> condicion) {
        List<T> resultado = new ArrayList<>();
        for (T t : datos) {
            if (condicion.test(t)) {
                resultado.add(t);
            }
        }
        return resultado;
    }

    /** Reemplaza la primera entidad que cumpla la condición. */
    public boolean reemplazar(Predicate<T> condicion, T nueva) {
        for (int i = 0; i < datos.size(); i++) {
            if (condicion.test(datos.get(i))) {
                datos.set(i, nueva);
                return true;
            }
        }
        return false;
    }

    public boolean quitar(Predicate<T> condicion) {
        return datos.removeIf(condicion);
    }

    public List<T> todos() {
        return new ArrayList<>(datos);
    }
}
