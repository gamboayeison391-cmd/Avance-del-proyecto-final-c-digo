/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import util.Validaciones;

import controlador.ControladorProducto;
import controlador.ControladorCategoria;
import controlador.ControladorInventario;
import modelo.Producto;
import modelo.Categoria;
import java.util.List;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import modelo.Inventario;
import util.Iconos;
import util.Mensajes;

/**
 *
 * @author UCF20429
 */
public class FrmProducto extends JInternalFrame{
    private ControladorProducto controlador = new ControladorProducto();
    private ControladorCategoria controladorCategoria = new ControladorCategoria();
    private ControladorInventario controladorInventario = new ControladorInventario();
   
    private List<Categoria> listaCategorias;

    private JLabel lblTitulo, lblIdProducto, lblCodigo, lblNombre, lblMarca;
    private JLabel lblCategoria, lblPrecioCompra, lblPrecioVenta, lblStock;
    private JLabel lblStockMinimo, lblEstado;

    private JTextField txtIdProducto, txtCodigo, txtNombre, txtMarca;
    private JTextField txtPrecioCompra, txtPrecioVenta, txtStock, txtStockMinimo;

    private JComboBox<String> cboCategoria, cboEstado;

    private JButton btnRegistrar, btnActualizar, btnEliminar, btnBuscar;
    private JButton btnListar, btnLimpiar;
    

    private JTable tablaProducto;
    private DefaultTableModel modeloTabla;
    private JScrollPane scrollTabla;

    private JLabel lblListaProductos;
    
    public FrmProducto() {
        iniciarComponentes();
           cargarCategorias();
           listar();
    }

    private void iniciarComponentes() {
        setTitle("Gestión de Productos");
        setClosable(true);
        setIconifiable(false);
        setMaximizable(false);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        lblTitulo = new JLabel("GESTIÓN DE PRODUCTOS");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitulo.setBounds(400, 20, 400, 35);
        setSize(1200, 700);
        setClosable(true);
        setIconifiable(false);
        setMaximizable(false);
        setResizable(false);

        lblIdProducto = new JLabel("ID Producto:");
        lblIdProducto.setBounds(70, 80, 120, 25);
        txtIdProducto = new JTextField();
        txtIdProducto.setBounds(180, 80, 140, 25);
        txtIdProducto.setBackground(Color.WHITE);
        txtIdProducto.setEditable(false);

        lblCodigo = new JLabel("Código:");
        lblCodigo.setBounds(360, 80, 90, 25);
        txtCodigo = new JTextField();
        txtCodigo.setBounds(440, 80, 180, 25);

        lblCategoria = new JLabel("Categoría:");
        lblCategoria.setBounds(660, 80, 100, 25);
        cboCategoria = new JComboBox<>();
        cboCategoria.addItem("Seleccione");
        cboCategoria.setBounds(760, 80, 270, 25);

        lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(70, 125, 120, 25);
        txtNombre = new JTextField();
        txtNombre.setBounds(180, 125, 250, 25);

        lblMarca = new JLabel("Marca:");
        lblMarca.setBounds(470, 125, 80, 25);
        txtMarca = new JTextField();
        txtMarca.setBounds(550, 125, 200, 25);

        lblPrecioCompra = new JLabel("Precio Compra:");
        lblPrecioCompra.setBounds(70, 170, 120, 25);
        txtPrecioCompra = new JTextField();
        txtPrecioCompra.setBounds(190, 170, 150, 25);

        lblPrecioVenta = new JLabel("Precio Venta:");
        lblPrecioVenta.setBounds(380, 170, 120, 25);
        txtPrecioVenta = new JTextField();
        txtPrecioVenta.setBounds(500, 170, 150, 25);

        lblStock = new JLabel("Stock:");
        txtStock = new JTextField();
        lblStock.setBounds(690, 170, 80, 25);
        txtStock.setBounds(760, 170, 120, 25);

        lblStockMinimo = new JLabel("Stock Mínimo:");
        lblStockMinimo.setBounds(70, 215, 120, 25);
        txtStockMinimo = new JTextField();
        txtStockMinimo.setBounds(190, 215, 150, 25);

        lblEstado = new JLabel("Estado:");
        lblEstado.setBounds(380, 215, 100, 25);
        cboEstado = new JComboBox<>();
        cboEstado.addItem("Activo");
        cboEstado.addItem("Inactivo");
        cboEstado.setBounds(500, 215, 150, 25);

        //botones
        btnRegistrar = new JButton("Registrar");
        btnRegistrar.setBounds(170, 275, 125, 35);

        btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(310, 275, 125, 35);

        btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(450, 275, 125, 35);

        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(590, 275, 125, 35);

        //btnListar = new JButton("Listar");
        //btnListar.setBounds(730, 275, 125, 35);

        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(730, 275, 125, 35);
        
        
        //chec

        //Cargar iconos
        btnRegistrar.setIcon(Iconos.cargar("/imagenes/registrar.png", 20, 20));
        btnActualizar.setIcon(Iconos.cargar("/imagenes/actualizar.png", 20, 20));
        btnEliminar.setIcon(Iconos.cargar("/imagenes/eliminar.png", 20, 20));
        btnBuscar.setIcon(Iconos.cargar("/imagenes/buscar.png", 20, 20));
        //btnListar.setIcon(Iconos.cargar("/imagenes/listar.png", 20, 20));
        btnLimpiar.setIcon(Iconos.cargar("/imagenes/limpiar.png", 20, 20));
        
        
        lblListaProductos = new JLabel("LISTADO DE PRODUCTOS");
        lblListaProductos.setFont(new Font("Arial", Font.BOLD, 14));
        lblListaProductos.setBounds(80, 330, 250, 25);
        
        
        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("ID");
        modeloTabla.addColumn("Código");
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Marca");
        modeloTabla.addColumn("Categoría");
        modeloTabla.addColumn("Precio Compra");
        modeloTabla.addColumn("Precio Venta");
        modeloTabla.addColumn("Stock");
        modeloTabla.addColumn("Stock Mínimo");
        modeloTabla.addColumn("Estado");

        tablaProducto = new JTable(modeloTabla);
        tablaProducto.setRowHeight(25);
        tablaProducto.getTableHeader().setReorderingAllowed(false);
        tablaProducto.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tablaProducto.setFillsViewportHeight(true);
        tablaProducto.setGridColor(new Color(220, 220, 220));
        tablaProducto.setShowGrid(true);
        tablaProducto.setAutoCreateRowSorter(true);
        tablaProducto.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        scrollTabla = new JScrollPane(tablaProducto);
        scrollTabla.setBounds(80, 360, 980, 230);

        btnRegistrar.addActionListener(e -> registrar());
        btnActualizar.addActionListener(e -> actualizar());
        btnEliminar.addActionListener(e -> inactivar());
        btnBuscar.addActionListener(e -> buscar());
        //btnListar.addActionListener(e -> listar());
        btnLimpiar.addActionListener(e -> limpiar());

        panel.add(lblTitulo);
        panel.add(lblIdProducto);
        panel.add(txtIdProducto);
        panel.add(lblCodigo);
        panel.add(txtCodigo);
        panel.add(lblCategoria);
        panel.add(cboCategoria);
        panel.add(lblNombre);
        panel.add(txtNombre);
        panel.add(lblMarca);
        panel.add(txtMarca);
        panel.add(lblPrecioCompra);
        panel.add(txtPrecioCompra);
        panel.add(lblPrecioVenta);
        panel.add(txtPrecioVenta);
        panel.add(lblStock);
        panel.add(txtStock);
        panel.add(lblStockMinimo);
        panel.add(txtStockMinimo);
        panel.add(lblEstado);
        panel.add(cboEstado);

        panel.add(btnRegistrar);
        panel.add(btnActualizar);
        panel.add(btnEliminar);
        panel.add(btnBuscar);
        //panel.add(btnListar);
        panel.add(btnLimpiar);

        panel.add(scrollTabla);

        panel.add(lblListaProductos);
        add(panel);
    }
    
    private void cargarCategorias() {
        cboCategoria.removeAllItems();
        listaCategorias = controladorCategoria.listarCategorias();

        for (Categoria cat : listaCategorias) {
            cboCategoria.addItem(cat.getNombre());
        }
    }

    private Categoria obtenerCategoriaSeleccionada() {
        int index = cboCategoria.getSelectedIndex();

        if (index >= 0 && listaCategorias != null && index < listaCategorias.size()) {
            return listaCategorias.get(index);
        }

        return null;
    }

    private Producto leerDatos() {
        Producto pro = new Producto();

        pro.setCodigo(txtCodigo.getText().trim());
        pro.setNombre(txtNombre.getText().trim());
        pro.setMarca(txtMarca.getText().trim());
        pro.setPrecioCompra(Double.parseDouble(txtPrecioCompra.getText().trim()));
        pro.setPrecioVenta(Double.parseDouble(txtPrecioVenta.getText().trim()));
        pro.setStock(Integer.parseInt(txtStock.getText().trim()));
        pro.setStockMinimo(Integer.parseInt(txtStockMinimo.getText().trim()));
        pro.setEstado(cboEstado.getSelectedItem().toString().equals("Activo"));
        pro.setCategoria(obtenerCategoriaSeleccionada());

        return pro;
    }

    private void registrar() {
        try {
            if (!validarCampos()) {
               return;
            }
            Producto pro = leerDatos();

            if (pro.getCategoria() == null) {
                Mensajes.advertencia(this, "Seleccione una categoría");
                return;
            }

            if (controlador.registrarProducto(pro)) {

            // Buscar el producto recién registrado para obtener su ID
            Producto productoRegistrado = controlador.buscarPorCodigo(pro.getCodigo());
    
            if (productoRegistrado != null) {

                Inventario inv = new Inventario();
                inv.setStockActual(productoRegistrado.getStock());
                inv.setStockMinimo(productoRegistrado.getStockMinimo());
                inv.setUbicacion("Almacén");
                inv.setFechaActualizacion(new java.util.Date());
                inv.verificarStock();

                controladorInventario.registrarInventario(inv, productoRegistrado.getIdProducto());
                boolean ok = controladorInventario.registrarInventario(
                inv,
                productoRegistrado.getIdProducto());
                if(!ok){
                    Mensajes.error(this,"No se pudo registrar el inventario.");
                }
            }

            Mensajes.exito(this, "Producto registrado correctamente");
            listar();
            limpiar();

        } else {
            Mensajes.error(this, "No se pudo registrar el producto");
        }

        } catch (Exception e) {
            Mensajes.advertencia(this, "Revise los datos ingresados");
        }
    }

    private void actualizar() {
        try {
            if (txtIdProducto.getText().trim().isEmpty()) {
                Mensajes.advertencia(this, "Primero busque un producto para actualizar.");
                return;
            }

            if (!validarCampos()) {
                return;
            }

            Producto pro = leerDatos();
            pro.setIdProducto(Integer.parseInt(txtIdProducto.getText().trim()));

            if (controlador.actualizarProducto(pro)) {

                Inventario inv = controladorInventario.buscarPorProducto(pro.getIdProducto());

                if (inv != null) {
                    inv.setStockActual(pro.getStock());
                    inv.setStockMinimo(pro.getStockMinimo());
                    inv.setFechaActualizacion(new java.util.Date());
                    inv.verificarStock();
                    controladorInventario.actualizarInventario(inv, pro.getIdProducto());
                }

                Mensajes.exito(this, "Producto actualizado correctamente");
                listar();
                limpiar();

            } else {
                Mensajes.error(this, "No se pudo actualizar el producto");
            }

        } catch (Exception e) {
            Mensajes.advertencia(this, "Revise los datos ingresados");
        }
    }

    //Validaciones para btn r y g
    private boolean validarCampos() {

        if (Validaciones.estaVacio(txtCodigo.getText())) {
            Mensajes.advertencia(this, "Ingrese el código del producto");
            txtCodigo.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtNombre.getText())) {
            Mensajes.advertencia(this, "Ingrese el nombre del producto");
            txtNombre.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtMarca.getText())) {
            Mensajes.advertencia(this, "Ingrese la marca");
            txtMarca.requestFocus();
            return false;
        }

        if (cboCategoria.getSelectedIndex() == -1) {
            Mensajes.advertencia(this, "Seleccione una categoría");
            cboCategoria.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtPrecioCompra.getText())) {
            Mensajes.advertencia(this, "Ingrese el precio de compra");
            txtPrecioCompra.requestFocus();
            return false;
        }

        if (!Validaciones.decimalValido(txtPrecioCompra.getText().trim())) {
            Mensajes.advertencia(this, "El precio de compra debe ser numérico");
            txtPrecioCompra.requestFocus();
            return false;
        }

        if (Double.parseDouble(txtPrecioCompra.getText().trim()) <= 0) {
            Mensajes.advertencia(this, "El precio de compra debe ser mayor que cero");
            txtPrecioCompra.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtPrecioVenta.getText())) {
            Mensajes.advertencia(this, "Ingrese el precio de venta");
            txtPrecioVenta.requestFocus();
            return false;
        }

        if (!Validaciones.decimalValido(txtPrecioVenta.getText().trim())) {
            Mensajes.advertencia(this, "El precio de venta debe ser numérico");
            txtPrecioVenta.requestFocus();
            return false;
        }    

        if (Double.parseDouble(txtPrecioVenta.getText().trim()) <= 0) {
            Mensajes.advertencia(this, "El precio de venta debe ser mayor que cero");
            txtPrecioVenta.requestFocus();
            return false;
        }    

        if (Double.parseDouble(txtPrecioVenta.getText().trim())
                <= Double.parseDouble(txtPrecioCompra.getText().trim())) {
    
            Mensajes.advertencia(this,
                "El precio de venta debe ser mayor que el precio de compra");

            txtPrecioVenta.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtStock.getText())) {
            Mensajes.advertencia(this, "Ingrese el stock");
            txtStock.requestFocus();
            return false;
        }

        if (!Validaciones.enteroValido(txtStock.getText().trim())) {
            Mensajes.advertencia(this, "El stock debe ser numérico");
            txtStock.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtStockMinimo.getText())) {
            Mensajes.advertencia(this, "Ingrese el stock mínimo");
            txtStockMinimo.requestFocus();
            return false;
        }

        if (!Validaciones.enteroValido(txtStockMinimo.getText().trim())) {
            Mensajes.advertencia(this, "El stock mínimo debe ser numérico");
            txtStockMinimo.requestFocus();
            return false;
        }

        return true;
    }
     
    private void inactivar() {
        if (txtIdProducto.getText().trim().isEmpty()) {
            Mensajes.advertencia(this, "Primero busque el producto que desea inactivar.");
            return;
        }

        if (!Mensajes.confirmar(this,
            "¿Está seguro de inactivar este producto?")) {
            return;
        }

        int id = Integer.parseInt(txtIdProducto.getText().trim());

        if (controlador.inactivarProducto(id)) {
        
            Mensajes.exito(this,"Producto inactivado correctamente.");    
            listar();
            limpiar();

        } else {
            Mensajes.error(this,"No se pudo inactivar el producto.");
        }
    }
    
    
    private void buscar() {
        String codigo = txtCodigo.getText().trim();

        if (codigo.isEmpty()) {
            Mensajes.advertencia(this, "Ingrese el código del producto");
            txtCodigo.requestFocus();
        return;
        }

        Producto pro = controlador.buscarPorCodigo(codigo);

        if (pro != null) {
            txtIdProducto.setText(String.valueOf(pro.getIdProducto()));
            txtCodigo.setText(pro.getCodigo());
            txtNombre.setText(pro.getNombre());
            txtMarca.setText(pro.getMarca());
            txtPrecioCompra.setText(String.valueOf(pro.getPrecioCompra()));
            txtPrecioVenta.setText(String.valueOf(pro.getPrecioVenta()));
            txtStock.setText(String.valueOf(pro.getStock()));
            txtStockMinimo.setText(String.valueOf(pro.getStockMinimo()));
            cboEstado.setSelectedItem(pro.isEstado() ? "Activo" : "Inactivo");

            if (pro.getCategoria() != null) {
                cboCategoria.setSelectedItem(pro.getCategoria().getNombre());
            }

            txtCodigo.setEditable(false);

            btnRegistrar.setEnabled(false);
            btnActualizar.setEnabled(true);
            btnEliminar.setEnabled(true);


        } else {
            Mensajes.advertencia(this, "Producto no encontrado");
        }
    }

    private void listar() {
        modeloTabla.setRowCount(0);
    
        List<Producto> lista = controlador.listarProductosActivos();
        
        for (Producto pro : lista) {
            modeloTabla.addRow(new Object[]{
                pro.getIdProducto(),
                pro.getCodigo(),
                pro.getNombre(),
                pro.getMarca(),
                pro.getCategoria() != null ? pro.getCategoria().getNombre() : "",
                pro.getPrecioCompra(),
                pro.getPrecioVenta(),
                pro.getStock(),
                pro.getStockMinimo(),
                pro.isEstado() ? "Activo" : "Inactivo"
            });
        }
    }

    private void limpiar() {
        txtIdProducto.setText("");
        txtCodigo.setText("");
        txtNombre.setText("");
        txtMarca.setText("");
        txtPrecioCompra.setText("");
        txtPrecioVenta.setText("");
        txtStock.setText("");
        txtStockMinimo.setText("");

        if (cboCategoria.getItemCount() > 0) {
            cboCategoria.setSelectedIndex(0);
        }

        cboEstado.setSelectedIndex(0);

        txtCodigo.setEditable(true);

        btnRegistrar.setEnabled(true);
        btnActualizar.setEnabled(false);
        btnEliminar.setEnabled(false);

        txtCodigo.requestFocus();
    }   
}
