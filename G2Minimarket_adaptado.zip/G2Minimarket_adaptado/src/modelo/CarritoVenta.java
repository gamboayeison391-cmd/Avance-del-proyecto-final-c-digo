/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;

/**
 *
 * @author UCF20429
 */
public class CarritoVenta {
    private int idCarrito;
    private ArrayList<DetalleVenta> detallesVenta;

    public CarritoVenta() {
        detallesVenta = new ArrayList<>();
    }

    public CarritoVenta(int idCarrito, ArrayList<DetalleVenta> detallesVenta) {
        this.idCarrito = idCarrito;
        this.detallesVenta = detallesVenta;
    }

    public int getIdCarrito() {
        return idCarrito;
    }

    public void setIdCarrito(int idCarrito) {
        this.idCarrito = idCarrito;
    }

    public ArrayList<DetalleVenta> getDetallesVenta() {
        return detallesVenta;
    }

    public void setDetallesVenta(ArrayList<DetalleVenta> detallesVenta) {
        this.detallesVenta = detallesVenta;
    }

    
     //Agrega un detalle al carrito
    
    public void agregarDetalle(DetalleVenta detalle) {
        detallesVenta.add(detalle);
    }

    
     //Elimina un detalle del carrito
    
    public void eliminarDetalle(DetalleVenta detalle) {
        detallesVenta.remove(detalle);
    }

   
    // Vacía el carrito

    public void vaciarCarrito() {
        detallesVenta.clear();
    }

    //Calcula el total del carrito
    public double calcularTotal() {

        double total = 0;

        for (DetalleVenta detalle : detallesVenta) {
            total += detalle.getSubtotal();
        }

        return total;
    }
}
