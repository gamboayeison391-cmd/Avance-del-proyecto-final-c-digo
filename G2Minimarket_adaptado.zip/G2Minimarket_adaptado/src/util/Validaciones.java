/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

/**
 *
 * @author USUARIO
 */
public class Validaciones {

    public static boolean estaVacio(String texto) {
        return texto == null || texto.trim().isEmpty();
    }

    public static boolean soloLetras(String texto) {
        return texto.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+");
    }

    public static boolean soloNumeros(String texto) {
        return texto.matches("\\d+");
    }

    public static boolean dniValido(String dni) {
        return dni.matches("\\d{8}");
    }

    public static boolean rucValido(String ruc) {
        return ruc.matches("\\d{11}");
    }

    public static boolean telefonoValido(String telefono) {
        return telefono.matches("\\d{9}");
    }

    public static boolean correoValido(String correo) {
        return correo.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$");
    }

    public static boolean decimalValido(String numero) {
        return numero.matches("\\d+(\\.\\d+)?");
    }

    public static boolean enteroValido(String numero) {
        return numero.matches("\\d+");
    }

    public static boolean fechaValida(String fecha) {
        return fecha.matches("\\d{2}/\\d{2}/\\d{4}");
    }

    public static boolean horaValida(String hora) {
        return hora.matches("\\d{2}:\\d{2}:\\d{2}");
    }
}