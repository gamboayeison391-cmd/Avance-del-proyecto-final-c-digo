package dao;

import java.util.Date;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import modelo.Compra;
import modelo.DetalleCompra;
import modelo.Inventario;
import modelo.Producto;

/** Compras simuladas y movimientos de stock dentro de esta ejecución. */
public class CompraDAO {
    private static final Almacen<Compra> ALMACEN = new Almacen<>(0);
    public boolean registrar(Compra compra) {
        if (compra == null || compra.getProveedor() == null || compra.getEmpleado() == null ||
            compra.getDetallesCompra() == null || compra.getDetallesCompra().isEmpty()) return false;
        ProductoDAO productos = new ProductoDAO();
        for (DetalleCompra d: compra.getDetallesCompra()) {
            if (d == null || d.getProducto() == null || d.getCantidad() <= 0 || d.getPrecioCompra() < 0 ||
                productos.buscarPorId(d.getProducto().getIdProducto()) == null) return false;
        }
        compra.calcularTotal();
        compra.setIdCompra(ALMACEN.siguienteId());
        if (compra.getFecha() == null) compra.setFecha(new Date());
        compra.setEstado("ACTIVA");
        int detId = 0;
        for (DetalleCompra d : compra.getDetallesCompra()) {
            d.setIdDetalleCompra(++detId);
            d.calcularSubtotal();
            Producto p = productos.buscarPorId(d.getProducto().getIdProducto());
            p.setStock(p.getStock() + d.getCantidad());
            actualizarInventario(p);
        }
        ALMACEN.agregar(compra);
        return true;
    }
    private void actualizarInventario(Producto p) {
        Inventario inv = new InventarioDAO().buscarPorProducto(p.getIdProducto());
        if (inv != null) {
            inv.setStockActual(p.getStock());
            inv.setFechaActualizacion(new Date());
        }
    }
    public boolean eliminar(int idCompra) { return anular(idCompra); }
    public boolean anular(int idCompra) {
        Compra compra = buscarPorId(idCompra);
        if (compra == null || "ANULADA".equalsIgnoreCase(compra.getEstado())) return false;
        ProductoDAO productos = new ProductoDAO();
        Map<Integer,Integer> cantidades = new HashMap<>();
        for (DetalleCompra d : compra.getDetallesCompra()) {
            int id = d.getProducto().getIdProducto();
            cantidades.put(id, cantidades.getOrDefault(id, 0) + d.getCantidad());
        }
        for (Map.Entry<Integer,Integer> e : cantidades.entrySet()) {
            Producto p = productos.buscarPorId(e.getKey());
            if (p == null || p.getStock() < e.getValue()) return false;
        }
        for (Map.Entry<Integer,Integer> e : cantidades.entrySet()) {
            Producto p = productos.buscarPorId(e.getKey());
            p.setStock(p.getStock() - e.getValue());
            actualizarInventario(p);
        }
        compra.setEstado("ANULADA");
        return true;
    }
    public Compra buscarPorId(int id) { return ALMACEN.buscar(c -> c.getIdCompra() == id).orElse(null); }
    public List<Compra> listar() { return ALMACEN.todos(); }
}
