package dao;

import java.util.List;
import modelo.Cliente;

public class ClienteDAO implements CrudDAO<Cliente> {

    private static final Almacen<Cliente> ALMACEN = new Almacen<>(100);

    @Override
    public boolean registrar(Cliente cli) {
        cli.setIdPersona(ALMACEN.siguienteId());
        ALMACEN.agregar(cli);
        return true;
    }

    @Override
    public boolean actualizar(Cliente cli) {
        return ALMACEN.reemplazar(c -> c.getIdPersona() == cli.getIdPersona(), cli);
    }

    @Override
    public boolean eliminar(int idPersona) {
        if (tieneVentasAsociadas(idPersona)) {
            return desactivar(idPersona);
        }
        return ALMACEN.quitar(c -> c.getIdPersona() == idPersona);
    }

    public boolean activar(int idPersona) {
        return cambiarEstado(idPersona, true);
    }

    public boolean desactivar(int idPersona) {
        return cambiarEstado(idPersona, false);
    }

    private boolean cambiarEstado(int idPersona, boolean estado) {
        Cliente cli = ALMACEN.buscar(c -> c.getIdPersona() == idPersona).orElse(null);
        if (cli == null) {
            return false;
        }
        cli.setEstado(estado);
        return true;
    }

    public boolean tieneVentasAsociadas(int idPersona) {
        return new VentaDAO().listar().stream()
                .anyMatch(v -> v.getCliente() != null && v.getCliente().getIdPersona() == idPersona);
    }

    public Cliente buscarPorDocumento(String nroDocumento) {
        return ALMACEN.buscar(c -> c.getNroDocumento().equals(nroDocumento)).orElse(null);
    }

    @Override
    public List<Cliente> listar() {
        return ALMACEN.todos();
    }

    public List<Cliente> listarActivos() {
        return ALMACEN.filtrar(Cliente::isEstado);
    }

    public boolean existeDocumento(String nroDocumento) {
        return ALMACEN.existe(c -> c.getNroDocumento().equals(nroDocumento));
    }
}
