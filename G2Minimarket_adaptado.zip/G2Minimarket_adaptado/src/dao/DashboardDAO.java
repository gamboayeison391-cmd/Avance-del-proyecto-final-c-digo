/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexion.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;
/**
 *
 * @author USUARIO
 */
public class DashboardDAO {
    public double ventasDelDia() {
        String sql = """
            SELECT IFNULL(SUM(total), 0)
            FROM Venta
            WHERE fecha = CURDATE()
        """;

        return obtenerDouble(sql);
    }

    public double gananciaDelDia() {
        String sql = """
            SELECT IFNULL(SUM(
                (dv.precioUnitario - p.precioCompra) * dv.cantidad
            ), 0)
            FROM DetalleVenta dv
            INNER JOIN Producto p ON dv.idProducto = p.idProducto
            INNER JOIN Venta v ON dv.idVenta = v.idVenta
            WHERE v.fecha = CURDATE()
        """;

        return obtenerDouble(sql);
    }

    public int totalClientes() {
        return obtenerEntero("SELECT COUNT(*) FROM Cliente");
    }

    public int totalProductos() {
        return obtenerEntero("SELECT COUNT(*) FROM Producto");
    }

    public int totalEmpleados() {
        return obtenerEntero("SELECT COUNT(*) FROM Empleado");
    }

    public int productosStockBajo() {
        String sql = """
            SELECT COUNT(*)
            FROM Producto
            WHERE stock <= stockMinimo
        """;

        return obtenerEntero(sql);
    }

    public Map<String, Double> ventasUltimos7Dias() {
        Map<String, Double> datos = new LinkedHashMap<>();

        String sql = """
            SELECT
                DATE_FORMAT(fecha, '%d/%m/%Y') AS dia,
                IFNULL(SUM(total), 0) AS total
            FROM Venta
            WHERE fecha >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
            GROUP BY fecha
            ORDER BY fecha
        """;

        try {
            Connection cn = ConexionBD.conectar();
            PreparedStatement ps = cn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                datos.put(
                    rs.getString("dia"),
                    rs.getDouble("total")
                );
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error Dashboard ventas últimos 7 días: " + e.getMessage());
        }

        return datos;
    }

    private int obtenerEntero(String sql) {
        try {
            Connection cn = ConexionBD.conectar();
            PreparedStatement ps = cn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int valor = rs.getInt(1);

                rs.close();
                ps.close();
                ConexionBD.cerrar(cn);

                return valor;
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error dashboard entero: " + e.getMessage());
        }

        return 0;
    }

    private double obtenerDouble(String sql) {
        try {
            Connection cn = ConexionBD.conectar();
            PreparedStatement ps = cn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                double valor = rs.getDouble(1);

                rs.close();
                ps.close();
                ConexionBD.cerrar(cn);

                return valor;
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error dashboard decimal: " + e.getMessage());
        }

        return 0;
    }
}