/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexion.ConexionBD;
import modelo.Categoria;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author USUARIO
 */
public class CategoriaDAO {

    public boolean registrar(Categoria cat) {
        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "INSERT INTO Categoria (nombre, descripcion, estado) "
              + "VALUES (?, ?, ?)"
            );

            ps.setString(1, cat.getNombre());
            ps.setString(2, cat.getDescripcion());
            ps.setBoolean(3, cat.isEstado());

            int res = ps.executeUpdate();

            ps.close();
            ConexionBD.cerrar(cn);

            return res > 0;

        } catch (SQLException e) {
            System.out.println("Error registrar categoría: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizar(Categoria cat) {
        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "UPDATE Categoria SET "
              + "nombre = ?, "
              + "descripcion = ?, "
              + "estado = ? "
              + "WHERE idCategoria = ?"
            );

            ps.setString(1, cat.getNombre());
            ps.setString(2, cat.getDescripcion());
            ps.setBoolean(3, cat.isEstado());
            ps.setInt(4, cat.getIdCategoria());

            int res = ps.executeUpdate();

            ps.close();
            ConexionBD.cerrar(cn);

            return res > 0;

        } catch (SQLException e) {
            System.out.println("Error actualizar categoría: " + e.getMessage());
            return false;
        }
    }

    
    public Categoria buscarPorId(int idCategoria) {
        Categoria cat = null;

        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "SELECT idCategoria, nombre, descripcion, estado "
              + "FROM Categoria "
              + "WHERE idCategoria = ?"
            );

            ps.setInt(1, idCategoria);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                cat = convertirCategoria(rs);
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error buscar categoría: " + e.getMessage());
        }

        return cat;
    }

    public List<Categoria> listar() {
        List<Categoria> lista = new ArrayList<>();

        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "SELECT idCategoria, nombre, descripcion, estado "
              + "FROM Categoria "
              + "ORDER BY idCategoria DESC"
            );

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(convertirCategoria(rs));
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error listar categorías: " + e.getMessage());
        }

        return lista;
    }

    public List<Categoria> listarActivos() {
        List<Categoria> lista = new ArrayList<>();

        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "SELECT idCategoria, nombre, descripcion, estado "
              + "FROM Categoria "
              + "WHERE estado = 1 "
              + "ORDER BY nombre ASC"
            );

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(convertirCategoria(rs));
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error listar categorías activas: " + e.getMessage());
        }

        return lista;
    }

    public boolean existeNombre(String nombre) {
        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "SELECT COUNT(*) FROM Categoria WHERE UPPER(nombre) = UPPER(?)"
            );

            ps.setString(1, nombre.trim());

            ResultSet rs = ps.executeQuery();

            boolean existe = false;

            if (rs.next()) {
                existe = rs.getInt(1) > 0;
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

            return existe;

        } catch (SQLException e) {
            System.out.println("Error verificar nombre de categoría: " + e.getMessage());
            return false;
        }
    }

    private Categoria convertirCategoria(ResultSet rs) throws SQLException {
        Categoria cat = new Categoria();

        cat.setIdCategoria(rs.getInt("idCategoria"));
        cat.setNombre(rs.getString("nombre"));
        cat.setDescripcion(rs.getString("descripcion"));
        cat.setEstado(rs.getBoolean("estado"));

        return cat;
    }
}
