/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import util.Validaciones;

import controlador.ControladorUsuario;
import controlador.ControladorEmpleado;
import modelo.Usuario;
import modelo.Empleado;
import java.util.List;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import util.FormularioUtil;
import util.Iconos;
import util.Mensajes;

/**
 *
 * @author UCF20429
 */
public class FrmUsuario extends JInternalFrame{
    private ControladorUsuario controlador = new ControladorUsuario();
    private ControladorEmpleado controladorEmpleado = new ControladorEmpleado();
    private List<Empleado> listaEmpleados;

    private JLabel lblTitulo, lblIdUsuario, lblEmpleado, lblUsuario;
    private JLabel lblPassword, lblRol, lblEstado;

    private JTextField txtIdUsuario, txtUsuario;
    private JPasswordField txtPassword;

    private JComboBox<String> cboEmpleado, cboRol, cboEstado;

    private JButton btnRegistrar, btnActualizar, btnEliminar, btnBuscar;
    private JButton btnListar, btnLimpiar, btnActivar;
    
    private JCheckBox chkMostrarInactivos;

    private JTable tablaUsuario;
    private DefaultTableModel modeloTabla;
    private JScrollPane scrollTabla;

    public FrmUsuario() {
        iniciarComponentes();
        cargarEmpleados();
        listar();
    }

    private void iniciarComponentes() {

        setTitle("Gestión de Usuarios");
        setSize(1200, 700);
        setClosable(true);
        setIconifiable(false);
        setMaximizable(false);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        lblTitulo = new JLabel("GESTIÓN DE USUARIOS");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBounds(350, 20, 500, 35);

        lblIdUsuario = new JLabel("ID Usuario:");
        lblIdUsuario.setBounds(120, 80, 120, 25);
        txtIdUsuario = new JTextField();
        txtIdUsuario.setBounds(240, 80, 170, 25);
        FormularioUtil.soloLectura(txtIdUsuario);

        lblEmpleado = new JLabel("Empleado:");
        lblEmpleado.setBounds(460, 80, 120, 25);
        cboEmpleado = new JComboBox<>();
        cboEmpleado.setBounds(580, 80, 300, 25);

        lblUsuario = new JLabel("Usuario:");
        lblUsuario.setBounds(120, 125, 120, 25);
        txtUsuario = new JTextField();
        txtUsuario.setBounds(240, 125, 170, 25);
        
        lblPassword = new JLabel("Contraseña:");
        lblPassword.setBounds(460, 125, 120, 25);
        txtPassword = new JPasswordField();
        txtPassword.setBounds(580, 125, 170, 25);

        lblRol = new JLabel("Rol:");
        lblRol.setBounds(120, 170, 120, 25);
        cboRol = new JComboBox<>();
        cboRol.addItem("Administrador");
        cboRol.addItem("Cajero");
        cboRol.addItem("Almacenero");
        cboRol.setBounds(240, 170, 170, 25);

        lblEstado = new JLabel("Estado:");
        lblEstado.setBounds(460, 170, 120, 25);
        cboEstado = new JComboBox<>();
        cboEstado.addItem("Activo");
        cboEstado.addItem("Inactivo");
        cboEstado.setBounds(580, 170, 170, 25);

        // Botones centrados
        btnRegistrar = new JButton("Registrar");
        btnRegistrar.setBounds(180, 240, 120, 35);

        btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(320, 240, 120, 35);

        btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(460, 240, 120, 35);

        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(600, 240, 120, 35);

        //btnListar = new JButton("Listar");
        //btnListar.setBounds(740, 240, 120, 35);

        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(740, 240, 120, 35);
        
        btnActivar = new JButton("Activar");
        btnActivar.setBounds(880,240,120,35);
        
        //ver inactivos
        chkMostrarInactivos = new JCheckBox("Mostrar inactivos");
        chkMostrarInactivos.setBounds(950, 290, 170, 25);
        chkMostrarInactivos.setBackground(Color.WHITE);

        // Iconos
        btnRegistrar.setIcon(Iconos.cargar("/imagenes/registrar.png", 20, 20));
        btnActualizar.setIcon(Iconos.cargar("/imagenes/actualizar.png", 20, 20));
        btnEliminar.setIcon(Iconos.cargar("/imagenes/eliminar.png", 20, 20));
        btnBuscar.setIcon(Iconos.cargar("/imagenes/buscar.png", 20, 20));
        //btnListar.setIcon(Iconos.cargar("/imagenes/listar.png", 20, 20));
        btnLimpiar.setIcon(Iconos.cargar("/imagenes/limpiar.png", 20, 20));

        // Estilo botones
        FormularioUtil.configurarBoton(btnRegistrar);
        FormularioUtil.configurarBoton(btnActualizar);
        FormularioUtil.configurarBoton(btnEliminar);
        FormularioUtil.configurarBoton(btnBuscar);
        //FormularioUtil.configurarBoton(btnListar);
        FormularioUtil.configurarBoton(btnLimpiar);
        FormularioUtil.configurarBoton(btnActivar);
        
        
        JLabel lblListaUsuarios = new JLabel("LISTADO DE USUARIOS");
        lblListaUsuarios.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblListaUsuarios.setBounds(120, 310, 250, 25);
        panel.add(lblListaUsuarios);
        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("ID Usuario");
        modeloTabla.addColumn("Empleado");
        modeloTabla.addColumn("Usuario");
        modeloTabla.addColumn("Rol");
        modeloTabla.addColumn("Estado");

        tablaUsuario = new JTable(modeloTabla);
        scrollTabla = new JScrollPane(tablaUsuario);
        scrollTabla.setBounds(120, 340, 950, 230);
        FormularioUtil.configurarTabla(tablaUsuario);

        btnRegistrar.addActionListener(e -> registrar());
        btnActualizar.addActionListener(e -> actualizar());
        btnEliminar.addActionListener(e -> eliminar());
        btnBuscar.addActionListener(e -> buscar());
        //btnListar.addActionListener(e -> listar());
        btnLimpiar.addActionListener(e -> limpiar());
        btnActivar.addActionListener(e -> activar());
        chkMostrarInactivos.addActionListener(e -> listar());

        panel.add(lblTitulo);
        panel.add(lblIdUsuario);
        panel.add(txtIdUsuario);
        panel.add(lblEmpleado);
        panel.add(cboEmpleado);
        panel.add(lblUsuario);
        panel.add(txtUsuario);
        panel.add(lblPassword);
        panel.add(txtPassword);
        panel.add(lblRol);
        panel.add(cboRol);
        panel.add(lblEstado);
        panel.add(cboEstado);

        panel.add(btnRegistrar);
        panel.add(btnActualizar);
        panel.add(btnEliminar);
        panel.add(btnBuscar);
        //panel.add(btnListar);
        panel.add(btnLimpiar);
        panel.add(btnActivar);
        panel.add(chkMostrarInactivos);
        
        panel.add(scrollTabla);

        add(panel);
    }

    private void cargarEmpleados() {
        cboEmpleado.removeAllItems();
        listaEmpleados = controladorEmpleado.listarEmpleados();

        for (Empleado emp : listaEmpleados) {
            cboEmpleado.addItem(emp.getNombre() + " " + emp.getApPaterno());
        }
    }

    private Empleado obtenerEmpleadoSeleccionado() {
        int index = cboEmpleado.getSelectedIndex();

        if (index >= 0 && listaEmpleados != null && index < listaEmpleados.size()) {
            return listaEmpleados.get(index);
        }
        return null;
    }

    private Usuario leerDatos() {
        Usuario usu = new Usuario();

        usu.setEmpleado(obtenerEmpleadoSeleccionado());
        usu.setNombreUsuario(txtUsuario.getText().trim());
        usu.setContrasena(String.valueOf(txtPassword.getPassword()).trim());
        usu.setRol(cboRol.getSelectedItem().toString());
        usu.setEstado(cboEstado.getSelectedItem().toString().equals("Activo"));

        return usu;
    }

    private void registrar() {
        if (!validarCampos()) {
            return;
        }
        Usuario usu = leerDatos();

        if (controlador.existeUsuario(usu.getNombreUsuario())) {
            Mensajes.advertencia(this,
           "El nombre de usuario ya se encuentra registrado.");
            txtUsuario.requestFocus();
            return;
        }

        if (controlador.existeEmpleadoUsuario(usu.getEmpleado().getIdPersona())) {
            Mensajes.advertencia(this,
            "El empleado seleccionado ya tiene un usuario registrado.");
            cboEmpleado.requestFocus();
            return;
        }
        
        if (usu.getEmpleado() == null) {
           Mensajes.advertencia(this, "Seleccione un empleado");
            return;
        }

        if (usu.getNombreUsuario().isEmpty()) {
            Mensajes.advertencia(this, "Ingrese el usuario");
            return;
        }

        if (usu.getContrasena().isEmpty()) {
            Mensajes.advertencia(this, "Ingrese la contraseña");
            return;
        }

        if (controlador.registrarUsuario(usu)) {
            Mensajes.exito(this, "Usuario registrado correctamente");
            listar();
            limpiar();
        } else {
            Mensajes.error(this, "No se pudo registrar el usuario");
        }    
    }

    private void actualizar() {
        if (txtIdUsuario.getText().trim().isEmpty()) {
            Mensajes.advertencia(this,
            "Primero busque un usuario para actualizar.");
            txtUsuario.requestFocus();
            return;
        }
        
        if (!validarCampos()) {
            return;
        }

        Usuario usu = leerDatos();
        usu.setIdUsuario(Integer.parseInt(txtIdUsuario.getText().trim()));

        if (controlador.actualizarUsuario(usu)) {
            Mensajes.exito(this, "Usuario actualizado correctamente");
            listar();
            limpiar();
        } else {
            Mensajes.error(this, "No se pudo actualizar el usuario");
        }
    }

    private void eliminar() {

        if (txtIdUsuario.getText().trim().isEmpty()) {
            Mensajes.advertencia(this,
                "Primero busque un usuario para eliminar.");
            return;
        }

        if (!Mensajes.confirmar(this,
            "¿Está seguro de eliminar este usuario?")) {
            return;
        }

        int id = Integer.parseInt(txtIdUsuario.getText().trim());

        if (controlador.eliminarUsuario(id)) {

            Mensajes.exito(this,
                "Usuario eliminado correctamente.");

            listar();
            limpiar();

        } else {

            Mensajes.error(this,
                "No se pudo eliminar el usuario.");
        }
    }

    private void activar() {
        if (txtIdUsuario.getText().trim().isEmpty()) {
            Mensajes.advertencia(this,"Primero busque el usuario.");
            return;
        }

        int idUsuario = Integer.parseInt(txtIdUsuario.getText());
        if (!Mensajes.confirmar(this,"¿Desea activar este usuario?")) {
            return;
        }

        if (controlador.activarUsuario(idUsuario)) {
            Mensajes.exito(this,"Usuario activado correctamente.");
            listar();
            limpiar();
        } else {
            Mensajes.error(this,"No se pudo activar el usuario.");
        }
    }

    //Validaciones para r y a
    private boolean validarCampos() {
        if (cboEmpleado.getSelectedIndex() == -1) {
            Mensajes.advertencia(this, "Seleccione un empleado");
            cboEmpleado.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtUsuario.getText())) {
            Mensajes.advertencia(this, "Ingrese el nombre de usuario");
            txtUsuario.requestFocus();
            return false;
        }

        if (txtUsuario.getText().trim().length() < 4) {
            Mensajes.advertencia(this,
                "El usuario debe tener al menos 4 caracteres");
            txtUsuario.requestFocus();
            return false;
        }

        String password = String.valueOf(txtPassword.getPassword()).trim();

        if (password.isEmpty()) {
            Mensajes.advertencia(this, "Ingrese la contraseña");
            txtPassword.requestFocus();
            return false;
        }

        if (password.length() < 4) {
            Mensajes.advertencia(this,
                "La contraseña debe tener al menos 4 caracteres");
            txtPassword.requestFocus();
            return false;
        }

        if (cboRol.getSelectedIndex() == -1) {
            Mensajes.advertencia(this, "Seleccione el rol");
            cboRol.requestFocus();
            return false;
        }

        if (cboEstado.getSelectedIndex() == -1) {
            Mensajes.advertencia(this, "Seleccione el estado");
            cboEstado.requestFocus();
            return false;
        }
        return true;
    }
    
    private void buscar() {
        String usuario = txtUsuario.getText().trim();

        if (usuario.isEmpty()) {
            Mensajes.advertencia(this, "Ingrese el usuario");
            txtUsuario.requestFocus();
            return;
        }

        Usuario usu = controlador.buscarPorUsuario(usuario);
        if (usu != null) {
            txtIdUsuario.setText(String.valueOf(usu.getIdUsuario()));
            txtUsuario.setText(usu.getNombreUsuario());
            txtPassword.setText(usu.getContrasena());
            cboRol.setSelectedItem(usu.getRol());
            cboEstado.setSelectedItem(usu.isEstado() ? "Activo" : "Inactivo");

            if (usu.getEmpleado() != null) {
                cboEmpleado.setSelectedItem(
                    usu.getEmpleado().getNombre() + " " + usu.getEmpleado().getApPaterno()
                );
            }

            txtUsuario.setEditable(true);
            cboEmpleado.setEnabled(false);

            btnRegistrar.setEnabled(false);
            btnActualizar.setEnabled(true);
            btnEliminar.setEnabled(true);

            if (usu.isEstado()) {
                btnActivar.setEnabled(false);
            } else {
                btnActivar.setEnabled(true);
            }

        } else {
            Mensajes.advertencia(this, "Usuario no encontrado");
        }
    }

    private void listar() {
        modeloTabla.setRowCount(0);

        List<Usuario> lista;
        if (chkMostrarInactivos.isSelected()) {
            lista = controlador.listarTodosLosUsuarios();
        } else {
            lista = controlador.listarUsuariosActivos();
        }
        
        for (Usuario usu : lista) {
            modeloTabla.addRow(new Object[]{
            usu.getIdUsuario(),
            usu.getEmpleado().getNombre() + " " + usu.getEmpleado().getApPaterno(),
            usu.getNombreUsuario(),
            usu.getRol(),
            usu.isEstado() ? "Activo" : "Inactivo"
            });
        }
    }

    private void limpiar() {
        txtIdUsuario.setText("");
        txtUsuario.setText("");
        txtPassword.setText("");

        if (cboEmpleado.getItemCount() > 0) {
            cboEmpleado.setSelectedIndex(0);
        }

        cboRol.setSelectedIndex(0);
        cboEstado.setSelectedIndex(0);

        txtUsuario.setEditable(true);
        cboEmpleado.setEnabled(true);

        btnRegistrar.setEnabled(true);
        btnActualizar.setEnabled(false);
        btnEliminar.setEnabled(false);
        btnActivar.setEnabled(false);

        txtUsuario.requestFocus();
    }
}
