/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author UCF20429
 */
public class Reporte {
    private int idReporte;
    private Date fechaInicio;
    private Date fechaFin;
    private String tipoReporte;
    private String descripcion;
    private double total;

    private Empleado empleado;
    private Inventario inventario;
    private ArrayList<Venta> ventas;

    public Reporte() {
        ventas = new ArrayList<>();
    }

    public Reporte(int idReporte, Date fechaInicio, Date fechaFin,
                   String tipoReporte, String descripcion, double total,
                   Empleado empleado, Inventario inventario,
                   ArrayList<Venta> ventas) {

        this.idReporte = idReporte;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.tipoReporte = tipoReporte;
        this.descripcion = descripcion;
        this.total = total;
        this.empleado = empleado;
        this.inventario = inventario;
        this.ventas = ventas;
    }

    public int getIdReporte() {
        return idReporte;
    }

    public void setIdReporte(int idReporte) {
        this.idReporte = idReporte;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    public String getTipoReporte() {
        return tipoReporte;
    }

    public void setTipoReporte(String tipoReporte) {
        this.tipoReporte = tipoReporte;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

    public Inventario getInventario() {
        return inventario;
    }

    public void setInventario(Inventario inventario) {
        this.inventario = inventario;
    }

    public ArrayList<Venta> getVentas() {
        return ventas;
    }

    public void setVentas(ArrayList<Venta> ventas) {
        this.ventas = ventas;
    }
    
    public double calcularTotalVentas() {
        total = 0;

        for (Venta venta : ventas) {
            total += venta.getTotal();
        }

        return total;
    }

    public int cantidadVentas() {
        return ventas != null ? ventas.size() : 0;
    }

    @Override
    public String toString() {
        return tipoReporte + " - " + descripcion;
    }
}
