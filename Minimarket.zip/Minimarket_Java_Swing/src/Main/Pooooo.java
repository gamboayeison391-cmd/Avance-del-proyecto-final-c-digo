package Main;

import dao.DatosIniciales;
import javax.swing.SwingUtilities;
import vista.Login;

/** Punto de entrada del prototipo de escritorio: datos de prueba en memoria. */
public class Pooooo {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            DatosIniciales.cargar();
            new Login().setVisible(true);
        });
    }
}
