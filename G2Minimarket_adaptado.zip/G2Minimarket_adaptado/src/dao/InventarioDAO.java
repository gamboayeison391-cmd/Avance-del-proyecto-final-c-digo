/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexion.ConexionBD;
import modelo.Inventario;
import modelo.Producto;
import modelo.Categoria;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author USUARIO
 */
public class InventarioDAO {

    public boolean registrar(Inventario inv, int idProducto) {
        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "INSERT INTO Inventario "
              + "(idProducto, stockActual, stockMinimo, ubicacion, fechaActualizacion, estado) "
              + "VALUES (?, ?, ?, ?, ?, ?)"
            );

            cargarDatosInventario(ps, inv, idProducto);

            int res = ps.executeUpdate();

            ps.close();
            ConexionBD.cerrar(cn);

            return res > 0;

        } catch (SQLException e) {
            System.out.println("Error registrar inventario: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizar(Inventario inv, int idProducto) {
        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "UPDATE Inventario SET "
              + "idProducto = ?, "
              + "stockActual = ?, "
              + "stockMinimo = ?, "
              + "ubicacion = ?, "
              + "fechaActualizacion = ?, "
              + "estado = ? "
              + "WHERE idInventario = ?"
            );

            cargarDatosInventario(ps, inv, idProducto);
            ps.setInt(7, inv.getIdInventario());

            int res = ps.executeUpdate();

            ps.close();
            ConexionBD.cerrar(cn);

            return res > 0;

        } catch (SQLException e) {
            System.out.println("Error actualizar inventario: " + e.getMessage());
            return false;
        }
    }

    public Inventario buscarPorId(int idInventario) {
        Inventario inv = null;

        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                consultaInventario()
              + "WHERE i.idInventario = ?"
            );

            ps.setInt(1, idInventario);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                inv = convertirInventario(rs);
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error buscar inventario: " + e.getMessage());
        }

        return inv;
    }

    public Inventario buscarPorProducto(int idProducto) {
        Inventario inv = null;

        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                consultaInventario()
              + "WHERE i.idProducto = ?"
            );

            ps.setInt(1, idProducto);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                inv = convertirInventario(rs);
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error buscar inventario por producto: " + e.getMessage());
        }

        return inv;
    }

    public List<Inventario> listar() {
        List<Inventario> lista = new ArrayList<>();

        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                consultaInventario()
              + "ORDER BY i.idInventario DESC"
            );

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(convertirInventario(rs));
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error listar inventario: " + e.getMessage());
        }

        return lista;
    }

    public boolean existeProductoEnInventario(int idProducto) {
        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "SELECT COUNT(*) FROM Inventario WHERE idProducto = ?"
            );

            ps.setInt(1, idProducto);

            ResultSet rs = ps.executeQuery();

            boolean existe = false;

            if (rs.next()) {
                existe = rs.getInt(1) > 0;
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

            return existe;

        } catch (SQLException e) {
            System.out.println("Error verificar inventario: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarFecha(int idInventario) {
        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "UPDATE Inventario SET fechaActualizacion = ? WHERE idInventario = ?"
            );

            ps.setTimestamp(1, new Timestamp(System.currentTimeMillis()));
            ps.setInt(2, idInventario);

            int res = ps.executeUpdate();

            ps.close();
            ConexionBD.cerrar(cn);

            return res > 0;

        } catch (SQLException e) {
            System.out.println("Error actualizar fecha inventario: " + e.getMessage());
            return false;
        }
    }

    private void cargarDatosInventario(PreparedStatement ps, Inventario inv, int idProducto) throws SQLException {
        ps.setInt(1, idProducto);
        ps.setInt(2, inv.getStockActual());
        ps.setInt(3, inv.getStockMinimo());
        ps.setString(4, inv.getUbicacion());

        if (inv.getFechaActualizacion() != null) {
            ps.setTimestamp(5, new Timestamp(inv.getFechaActualizacion().getTime()));
        } else {
            ps.setTimestamp(5, new Timestamp(System.currentTimeMillis()));
        }

        ps.setString(6, inv.getEstado());
    }

    private Inventario convertirInventario(ResultSet rs) throws SQLException {
        Categoria cat = new Categoria();
        cat.setIdCategoria(rs.getInt("idCategoria"));
        cat.setNombre(rs.getString("nombreCategoria"));
        cat.setDescripcion(rs.getString("descripcion"));
        cat.setEstado(rs.getBoolean("estadoCategoria"));

        Producto pro = new Producto();
        pro.setIdProducto(rs.getInt("idProducto"));
        pro.setCodigo(rs.getString("codigo"));
        pro.setNombre(rs.getString("nombre"));
        pro.setMarca(rs.getString("marca"));
        pro.setPrecioCompra(rs.getDouble("precioCompra"));
        pro.setPrecioVenta(rs.getDouble("precioVenta"));
        pro.setStock(rs.getInt("stock"));
        pro.setStockMinimo(rs.getInt("stockMinimoProducto"));
        pro.setEstado(rs.getBoolean("estadoProducto"));
        pro.setCategoria(cat);

        Inventario inv = new Inventario();
        inv.setIdInventario(rs.getInt("idInventario"));
        inv.setStockActual(rs.getInt("stockActual"));
        inv.setStockMinimo(rs.getInt("stockMinimo"));
        inv.setUbicacion(rs.getString("ubicacion"));
        inv.setFechaActualizacion(rs.getTimestamp("fechaActualizacion"));
        inv.setEstado(rs.getString("estado"));
        inv.getProductos().add(pro);

        return inv;
    }

    private String consultaInventario() {
        return "SELECT "
             + "i.idInventario, i.stockActual, i.stockMinimo, "
             + "i.ubicacion, i.fechaActualizacion, i.estado, "
             + "p.idProducto, p.codigo, p.nombre, p.marca, "
             + "p.precioCompra, p.precioVenta, p.stock, "
             + "p.stockMinimo AS stockMinimoProducto, "
             + "p.estado AS estadoProducto, "
             + "c.idCategoria, c.nombre AS nombreCategoria, "
             + "c.descripcion, c.estado AS estadoCategoria "
             + "FROM Inventario i "
             + "INNER JOIN Producto p ON i.idProducto = p.idProducto "
             + "INNER JOIN Categoria c ON p.idCategoria = c.idCategoria ";
    }
}