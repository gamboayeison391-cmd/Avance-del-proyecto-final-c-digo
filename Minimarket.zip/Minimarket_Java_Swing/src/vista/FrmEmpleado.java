/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import util.Validaciones;
import controlador.ControladorEmpleado;
import java.awt.Color;
import java.awt.Font;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import modelo.Empleado;
import util.FormularioUtil;
import util.Iconos;
import util.Mensajes;

/**
 *
 * @author UCF20429
 */
public class FrmEmpleado extends JInternalFrame{
    private ControladorEmpleado controlador = new ControladorEmpleado();
    private SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");

    private JLabel lblTitulo, lblId, lblTipoDoc, lblDocumento, lblNombre;
    private JLabel lblApPaterno, lblApMaterno, lblFechaNacimiento, lblSexo;
    private JLabel lblTelefono, lblCorreo, lblDireccion, lblCodigo, lblFechaIngreso;
    private JLabel lblCargo, lblSueldo;

    private JTextField txtId, txtDocumento, txtNombre, txtApPaterno, txtApMaterno;
    private JTextField txtFechaNacimiento, txtTelefono, txtCorreo, txtDireccion;
    private JTextField txtCodigoEmpleado, txtFechaIngreso, txtCargo, txtSueldo;

    private JComboBox<String> cboTipoDoc, cboSexo;

    private JButton btnRegistrar, btnActualizar, btnEliminar, btnBuscar;
    private JButton btnListar, btnLimpiar, btnActivar;

    private JLabel lblListaEmpleados;
    private JTable tablaEmpleado;
    private DefaultTableModel modeloTabla;
    private JScrollPane scrollTabla;
    
    private JCheckBox chkMostrarInactivos;

    public FrmEmpleado() {
        iniciarComponentes();
        listar();
    }

    private void iniciarComponentes() {

        setTitle("Gestión de Empleados");
        setSize(1200,700);
        setClosable(true);
        setIconifiable(false);
        setMaximizable(false);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        lblTitulo = new JLabel("GESTIÓN DE EMPLEADOS");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitulo.setBounds(390, 20, 420, 35);

        lblId = new JLabel("ID:");
        lblId.setBounds(70, 80, 120, 25);
        txtId = new JTextField();
        txtId.setBounds(180, 80, 120, 25);
        txtId.setEditable(false);

        lblTipoDoc = new JLabel("Tipo Doc:");
        lblTipoDoc.setBounds(340, 80, 100, 25);
        cboTipoDoc = new JComboBox<>();
        cboTipoDoc.addItem("DNI");
        cboTipoDoc.addItem("Carnet");
        cboTipoDoc.addItem("Pasaporte");
        cboTipoDoc.setBounds(430, 80, 150, 25);

        lblDocumento = new JLabel("Nro Documento:");
        lblDocumento.setBounds(640, 80, 130, 25);
        txtDocumento = new JTextField();
        txtDocumento.setBounds(770, 80, 200, 25);

        lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(70, 125, 120, 25);
        txtNombre = new JTextField();
        txtNombre.setBounds(180, 125, 200, 25);

        lblApPaterno = new JLabel("Ap. Paterno:");
        lblApPaterno.setBounds(420, 125, 120, 25);
        txtApPaterno = new JTextField();
        txtApPaterno.setBounds(540, 125, 200, 25);

        lblApMaterno = new JLabel("Ap. Materno:");
        lblApMaterno.setBounds(780, 125, 120, 25);
        txtApMaterno = new JTextField();
        txtApMaterno.setBounds(900, 125, 200, 25);

        lblFechaNacimiento = new JLabel("Fecha Nac:");
        lblFechaNacimiento.setBounds(70, 170, 120, 25);
        txtFechaNacimiento = new JTextField();
        txtFechaNacimiento.setBounds(180, 170, 200, 25);
        txtFechaNacimiento.setToolTipText("Formato: dd/MM/yyyy");

        lblSexo = new JLabel("Sexo:");
        lblSexo.setBounds(420, 170, 120, 25);
        cboSexo = new JComboBox<>();
        cboSexo.addItem("Masculino");
        cboSexo.addItem("Femenino");
        cboSexo.setBounds(540, 170, 200, 25);

        lblTelefono = new JLabel("Teléfono:");
        lblTelefono.setBounds(780, 170, 120, 25);
        txtTelefono = new JTextField();
        txtTelefono.setBounds(900, 170, 200, 25);

        lblCorreo = new JLabel("Correo:");
        lblCorreo.setBounds(70, 215, 120, 25);
        txtCorreo = new JTextField();
        txtCorreo.setBounds(180, 215, 300, 25);

        lblDireccion = new JLabel("Dirección:");
        lblDireccion.setBounds(520, 215, 120, 25);
        txtDireccion = new JTextField();
        txtDireccion.setBounds(640, 215, 460, 25);

        lblCodigo = new JLabel("Código Emp:");
        lblCodigo.setBounds(70, 260, 120, 25);
        txtCodigoEmpleado = new JTextField();
        txtCodigoEmpleado.setBounds(180, 260, 200, 25);

        lblFechaIngreso = new JLabel("Fecha Ingreso:");
        lblFechaIngreso.setBounds(420, 260, 120, 25);
        txtFechaIngreso = new JTextField();
        txtFechaIngreso.setBounds(540, 260, 200, 25);
        txtFechaIngreso.setToolTipText("Formato: dd/MM/yyyy");

        lblCargo = new JLabel("Cargo:");
        lblCargo.setBounds(780, 260, 120, 25);
        txtCargo = new JTextField();
        txtCargo.setBounds(900, 260, 200, 25);

        lblSueldo = new JLabel("Sueldo:");
        lblSueldo.setBounds(70, 305, 120, 25);
        txtSueldo = new JTextField();
        txtSueldo.setBounds(180, 305, 200, 25);

        
        btnRegistrar = new JButton("Registrar");
        btnRegistrar.setBounds(170, 350, 125, 35);

        btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(310, 350, 125, 35);

        btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(450, 350, 125, 35);

        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(590, 350, 125, 35);

        //btnListar = new JButton("Listar");
        //btnListar.setBounds(730, 350, 125, 35);

        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(730, 350, 125, 35);
        
        btnActivar = new JButton("Activar");
        btnActivar.setBounds(870, 350, 125, 35);
        
        //icono de botones
        btnRegistrar.setIcon(Iconos.cargar("/imagenes/registrar.png", 20, 20));
        btnActualizar.setIcon(Iconos.cargar("/imagenes/actualizar.png", 20, 20));
        btnEliminar.setIcon(Iconos.cargar("/imagenes/eliminar.png", 20, 20));
        btnBuscar.setIcon(Iconos.cargar("/imagenes/buscar.png", 20, 20));
        //btnListar.setIcon(Iconos.cargar("/imagenes/listar.png", 20, 20));
        btnLimpiar.setIcon(Iconos.cargar("/imagenes/limpiar.png", 20, 20));
        btnActivar.setIcon(Iconos.cargar("/imagenes/actualizar.png", 20, 20));

        lblListaEmpleados = new JLabel("LISTADO DE EMPLEADOS");
        lblListaEmpleados.setFont(new Font("Arial", Font.BOLD, 14));
        lblListaEmpleados.setBounds(90, 390, 250, 25);
        
        //para ver inac
        chkMostrarInactivos = new JCheckBox("Mostrar inactivos");
        chkMostrarInactivos.setBounds(950,390,170,25);
        chkMostrarInactivos.setBackground(Color.WHITE);
        
        
        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("ID");
        modeloTabla.addColumn("Tipo Doc");
        modeloTabla.addColumn("Documento");
        modeloTabla.addColumn("Nombre completo");
        modeloTabla.addColumn("Teléfono");
        modeloTabla.addColumn("Cargo");
        modeloTabla.addColumn("Sueldo");
        modeloTabla.addColumn("Estado");

        tablaEmpleado = new JTable(modeloTabla);
        scrollTabla = new JScrollPane(tablaEmpleado);
        scrollTabla.setBounds(90, 420, 980, 170);
        FormularioUtil.configurarTabla(tablaEmpleado);
        
        
        btnRegistrar.addActionListener(e -> registrar());
        btnActualizar.addActionListener(e -> actualizar());
        btnEliminar.addActionListener(e -> eliminar());
        btnBuscar.addActionListener(e -> buscar());
        //btnListar.addActionListener(e -> listar());
        btnLimpiar.addActionListener(e -> limpiar());
        btnActivar.addActionListener(e -> activar());
        chkMostrarInactivos.addActionListener(e -> listar());

        panel.add(lblTitulo);
        panel.add(lblId);
        panel.add(txtId);
        panel.add(lblTipoDoc);
        panel.add(cboTipoDoc);
        panel.add(lblDocumento);
        panel.add(txtDocumento);
        panel.add(lblNombre);
        panel.add(txtNombre);
        panel.add(lblApPaterno);
        panel.add(txtApPaterno);
        panel.add(lblApMaterno);
        panel.add(txtApMaterno);
        panel.add(lblFechaNacimiento);
        panel.add(txtFechaNacimiento);
        panel.add(lblSexo);
        panel.add(cboSexo);
        panel.add(lblTelefono);
        panel.add(txtTelefono);
        panel.add(lblCorreo);
        panel.add(txtCorreo);
        panel.add(lblDireccion);
        panel.add(txtDireccion);
        panel.add(lblCodigo);
        panel.add(txtCodigoEmpleado);
        panel.add(lblFechaIngreso);
        panel.add(txtFechaIngreso);
        panel.add(lblCargo);
        panel.add(txtCargo);
        panel.add(lblSueldo);
        panel.add(txtSueldo);

        panel.add(btnRegistrar);
        panel.add(btnActualizar);
        panel.add(btnEliminar);
        panel.add(btnBuscar);
        //panel.add(btnListar);
        panel.add(btnLimpiar);
        panel.add(btnActivar);
        panel.add(chkMostrarInactivos);
        panel.add(scrollTabla);

        panel.add(lblListaEmpleados);
        add(panel);
    }

    private void registrar() {
        try {
            if (!validarCampos()) {
                return;
            }
            Empleado emp = leerDatos();

            if (controlador.buscarPorDocumento(emp.getNroDocumento()) != null) {
                Mensajes.advertencia(this,"Ya existe un empleado registrado con ese número de documento.");
                txtDocumento.requestFocus();
                return;
            }
            
            if (controlador.registrarEmpleado(emp)) {
                Mensajes.exito(this, "Empleado registrado correctamente");
                listar();
                limpiar(); 
            } else {
                Mensajes.error(this, "No se pudo registrar el empleado");
            }

        } catch (Exception e) {
            Mensajes.error(this, "Error: revise los datos ingresados");
        }
    }
    
    private void actualizar() {
        try {
            if (txtId.getText().trim().isEmpty()) {
                Mensajes.advertencia(this, "Primero busque un empleado para actualizar.");
                return;
            }

            if (!validarCampos()) {
                return;
            }

            Empleado emp = leerDatos();
            emp.setIdPersona(Integer.parseInt(txtId.getText().trim()));

            if (controlador.actualizarEmpleado(emp)) {
                Mensajes.exito(this, "Empleado actualizado correctamente.");
                listar();
                limpiar();
            } else {
                Mensajes.error(this, "No se pudo actualizar el empleado.");
            }

        } catch (Exception e) {
            Mensajes.error(this, "Error: revise los datos ingresados.");
        }
    }

    //Validaciones vara registrar y  actualizar
    private boolean validarCampos() {

        if (Validaciones.estaVacio(txtDocumento.getText())) {
            Mensajes.advertencia(this, "Ingrese el número de documento");
            txtDocumento.requestFocus();
            return false;
        }

        if (cboTipoDoc.getSelectedItem().toString().equals("DNI")
                && !Validaciones.dniValido(txtDocumento.getText().trim())) {
            Mensajes.advertencia(this, "El DNI debe tener 8 dígitos");
            txtDocumento.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtNombre.getText())) {
            Mensajes.advertencia(this, "Ingrese el nombre");
            txtNombre.requestFocus();
            return false;
        }

        if (!Validaciones.soloLetras(txtNombre.getText().trim())) {
            Mensajes.advertencia(this, "El nombre solo debe contener letras");
            txtNombre.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtApPaterno.getText())) {
            Mensajes.advertencia(this, "Ingrese el apellido paterno");
            txtApPaterno.requestFocus();
            return false;
        }

        if (!Validaciones.soloLetras(txtApPaterno.getText().trim())) {
            Mensajes.advertencia(this, "El apellido paterno solo debe contener letras");
            txtApPaterno.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtApMaterno.getText())) {
            Mensajes.advertencia(this, "Ingrese el apellido materno");
            txtApMaterno.requestFocus();
            return false;
        }

        if (!Validaciones.soloLetras(txtApMaterno.getText().trim())) {
            Mensajes.advertencia(this, "El apellido materno solo debe contener letras");
            txtApMaterno.requestFocus();
            return false;
        }

        if (!Validaciones.estaVacio(txtTelefono.getText())
                && !Validaciones.telefonoValido(txtTelefono.getText().trim())) {
            Mensajes.advertencia(this, "El teléfono debe tener 9 dígitos");
            txtTelefono.requestFocus();
            return false;
        }

        if (!Validaciones.estaVacio(txtCorreo.getText())
                && !Validaciones.correoValido(txtCorreo.getText().trim())) {
            Mensajes.advertencia(this, "Ingrese un correo válido");
            txtCorreo.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtCodigoEmpleado.getText())) {
            Mensajes.advertencia(this, "Ingrese el código del empleado");
            txtCodigoEmpleado.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtFechaIngreso.getText())) {
            Mensajes.advertencia(this, "Ingrese la fecha de ingreso");
            txtFechaIngreso.requestFocus();
            return false;
        }

        if (!Validaciones.fechaValida(txtFechaIngreso.getText().trim())) {
            Mensajes.advertencia(this, "La fecha debe tener formato dd/MM/yyyy");
            txtFechaIngreso.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtCargo.getText())) {
            Mensajes.advertencia(this, "Ingrese el cargo");
            txtCargo.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtSueldo.getText())) {
            Mensajes.advertencia(this, "Ingrese el sueldo");
            txtSueldo.requestFocus();
            return false;
        }

        if (!Validaciones.decimalValido(txtSueldo.getText().trim())) {
            Mensajes.advertencia(this, "El sueldo debe ser numérico");
            txtSueldo.requestFocus();
            return false;
        }

        if (Double.parseDouble(txtSueldo.getText().trim()) <= 0) {
            Mensajes.advertencia(this, "El sueldo debe ser mayor que cero");
            txtSueldo.requestFocus();
            return false;
        }
        if (Validaciones.estaVacio(txtFechaNacimiento.getText())) {
            Mensajes.advertencia(this, "Ingrese la fecha de nacimiento");
            txtFechaNacimiento.requestFocus();
            return false;
        }

        if (!Validaciones.fechaValida(txtFechaNacimiento.getText().trim())) {
            Mensajes.advertencia(this, "La fecha debe tener formato dd/MM/yyyy");
            txtFechaNacimiento.requestFocus();
            return false;
        }
    
        if (Validaciones.estaVacio(txtTelefono.getText())) {
            Mensajes.advertencia(this, "Ingrese el teléfono");
            txtTelefono.requestFocus();
            return false;
        }
    
        if (!Validaciones.telefonoValido(txtTelefono.getText().trim())) {
            Mensajes.advertencia(this, "El teléfono debe tener 9 dígitos");
            txtTelefono.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtCorreo.getText())) {
            Mensajes.advertencia(this, "Ingrese el correo");
            txtCorreo.requestFocus();
            return false;
        }

        if (!Validaciones.correoValido(txtCorreo.getText().trim())) {
            Mensajes.advertencia(this, "Ingrese un correo válido");
            txtCorreo.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtDireccion.getText())) {
            Mensajes.advertencia(this, "Ingrese la dirección");
            txtDireccion.requestFocus();
            return false;
        }
        return true;
    }

    private void eliminar() {
        if (txtId.getText().trim().isEmpty()) {
            Mensajes.advertencia(this, "Primero busque el empleado que desea eliminar.");
            return;
        }

        if (!Mensajes.confirmar(this, "¿Está seguro de eliminar este empleado?")) {
            return;
        }

        int idPersona = Integer.parseInt(txtId.getText().trim());

        if (controlador.eliminarEmpleado(idPersona)) {
            Mensajes.exito(this, "Empleado eliminado correctamente.");
            listar();
            limpiar();
        } else {
            Mensajes.error(this, "No se pudo eliminar el empleado.");
        }
    }

    private void buscar() {
        String documento = txtDocumento.getText().trim();

        if (documento.isEmpty()) {
            Mensajes.advertencia(this, "Ingrese el número de documento.");
            return;
        }

        Empleado emp = controlador.buscarPorDocumento(documento);

        if (emp != null) {
            txtId.setText(String.valueOf(emp.getIdPersona()));
            cboTipoDoc.setSelectedItem(emp.getTipoDocumento());
            txtDocumento.setText(emp.getNroDocumento());
            txtNombre.setText(emp.getNombre());
            txtApPaterno.setText(emp.getApPaterno());
            txtApMaterno.setText(emp.getApMaterno());

            if (emp.getFechaNacimiento() != null) {
                txtFechaNacimiento.setText(formato.format(emp.getFechaNacimiento()));
            }

            cboSexo.setSelectedItem(emp.getSexo());
            txtTelefono.setText(emp.getTelefono());
            txtCorreo.setText(emp.getCorreo());
            txtDireccion.setText(emp.getDireccion());
            txtCodigoEmpleado.setText(emp.getCodigoEmpleado());

            if (emp.getFechaIngreso() != null) {
                txtFechaIngreso.setText(formato.format(emp.getFechaIngreso()));
            }

            txtCargo.setText(emp.getCargo());
            txtSueldo.setText(String.valueOf(emp.getSueldo()));

            txtDocumento.setEditable(false);
            txtCodigoEmpleado.setEditable(false);

            btnRegistrar.setEnabled(false);
            btnActualizar.setEnabled(true);
            btnEliminar.setEnabled(true);
            btnActivar.setEnabled(true);

        } else {
            Mensajes.advertencia(this, "Empleado no encontrado.");
        }
    }
    
    private void activar() {
        if (txtId.getText().trim().isEmpty()) {
            Mensajes.advertencia(this, "Primero busque el empleado que desea activar.");
            return;
        }

        int idPersona = Integer.parseInt(txtId.getText().trim());

        if (!Mensajes.confirmar(this, "¿Desea activar este empleado?")) {
            return;
        }

        if (controlador.activarEmpleado(idPersona)) {
            Mensajes.exito(this, "Empleado activado correctamente.");
            listar();
            limpiar();
        } else {
            Mensajes.error(this, "No se pudo activar el empleado.");
        }
    }

    private void listar() {
        modeloTabla.setRowCount(0);

        //mostrar todos o solo activos
        List<Empleado> lista;
        if (chkMostrarInactivos.isSelected()) {
            lista = controlador.listarTodosLosEmpleados();
        } else {
            lista = controlador.listarEmpleadosActivos();
        }

        for (Empleado emp : lista) {
            modeloTabla.addRow(new Object[]{
                emp.getIdPersona(),
                emp.getTipoDocumento(),
                emp.getNroDocumento(),
                emp.getNombre()+ " " + emp.getApPaterno() + " " + emp.getApMaterno(),
                emp.getTelefono(),
                emp.getCargo(),
                emp.getSueldo(),
                emp.isEstado() ? "Activo" : "Inactivo"
            });
        }
    }

    private Empleado leerDatos() throws Exception {
        
        Empleado emp = new Empleado();

        emp.setTipoDocumento(cboTipoDoc.getSelectedItem().toString());
        emp.setNroDocumento(txtDocumento.getText().trim());
        emp.setNombre(txtNombre.getText().trim());
        emp.setApPaterno(txtApPaterno.getText().trim());
        emp.setApMaterno(txtApMaterno.getText().trim());

        if (!txtFechaNacimiento.getText().trim().isEmpty()) {
            emp.setFechaNacimiento(formato.parse(txtFechaNacimiento.getText().trim()));
        }

        emp.setSexo(cboSexo.getSelectedItem().toString());
        emp.setTelefono(txtTelefono.getText().trim());
        emp.setCorreo(txtCorreo.getText().trim());
        emp.setDireccion(txtDireccion.getText().trim());
        emp.setEstado(true);

        emp.setCodigoEmpleado(txtCodigoEmpleado.getText().trim());
        emp.setFechaIngreso(formato.parse(txtFechaIngreso.getText().trim()));
        emp.setCargo(txtCargo.getText().trim());
        emp.setSueldo(Double.parseDouble(txtSueldo.getText().trim()));
        emp.setJefe(null);
        return emp;
    }

    private void limpiar() {
        txtId.setText("");
        txtDocumento.setText("");
        txtNombre.setText("");
        txtApPaterno.setText("");
        txtApMaterno.setText("");
        txtFechaNacimiento.setText("");
        txtTelefono.setText("");
        txtCorreo.setText("");
        txtDireccion.setText("");
        txtCodigoEmpleado.setText("");
        txtFechaIngreso.setText("");
        txtCargo.setText("");
        txtSueldo.setText("");

        cboTipoDoc.setSelectedIndex(0);
        cboSexo.setSelectedIndex(0);

        txtDocumento.setEditable(true);
        txtCodigoEmpleado.setEditable(true);

        btnRegistrar.setEnabled(true);
        btnActualizar.setEnabled(false);
        btnEliminar.setEnabled(false);
        btnActivar.setEnabled(false);

        txtDocumento.requestFocus();
    }
}
