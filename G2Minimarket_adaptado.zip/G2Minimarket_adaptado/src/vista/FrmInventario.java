/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import util.Validaciones;

import controlador.ControladorInventario;
import controlador.ControladorProducto;
import modelo.Producto;
import java.util.List;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import modelo.Inventario;
import util.Iconos;
import util.Mensajes;

/**
 *
 * @author UCF20429
 */
public class FrmInventario extends JInternalFrame{
    private ControladorInventario controlador = new ControladorInventario();
    private ControladorProducto controladorProducto = new ControladorProducto();
    private List<Producto> listaProductos;

    private JLabel lblTitulo, lblProducto, lblStockActual, lblStockMinimo, lblEstado, lblFechaActualizacion;

    private JTextField txtStockActual, txtStockMinimo, txtFechaActualizacion;

    private JComboBox<String> cboProducto, cboEstado;

    private JButton btnActualizar, btnBuscar, btnListar, btnLimpiar;

    private JLabel lblListaInventario;
    private JTable tablaInventario;
    private DefaultTableModel modeloTabla;
    private JScrollPane scrollTabla;

    public FrmInventario() {
        iniciarComponentes();
        cargarProductos();
        //listar();
    }

    private void iniciarComponentes() {

        setTitle("Gestión de Inventario");
        setSize(1200, 700);
        setClosable(true);
        setIconifiable(false);
        setMaximizable(false);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        lblTitulo = new JLabel("GESTIÓN DE INVENTARIO");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitulo.setBounds(420, 20, 400, 35);

        lblProducto = new JLabel("Producto:");
        lblProducto.setBounds(120, 90, 100, 25);
        cboProducto = new JComboBox<>();
        cboProducto.setBounds(220, 90, 300, 25);

        lblStockActual = new JLabel("Stock Actual:");
        lblStockActual.setBounds(570, 90, 120, 25);
        txtStockActual = new JTextField();
        txtStockActual.setBounds(690, 90, 120, 25);

        lblStockMinimo = new JLabel("Stock Mínimo:");
        lblStockMinimo.setBounds(120, 140, 120, 25);
        txtStockMinimo = new JTextField();
        txtStockMinimo.setBounds(220, 140, 120, 25);
        txtStockMinimo.setEditable(false);
        txtStockMinimo.setBackground(Color.WHITE);
        
        lblFechaActualizacion = new JLabel("Fecha Actualización:");
        lblFechaActualizacion.setBounds(120, 190, 140, 25);
        txtFechaActualizacion = new JTextField();
        txtFechaActualizacion.setBounds(260, 190, 180, 25);
        txtFechaActualizacion.setEditable(false);
        txtFechaActualizacion.setBackground(Color.WHITE);

        lblEstado = new JLabel("Estado:");
        lblEstado.setBounds(570, 140, 100, 25);
        cboEstado = new JComboBox<>();
        cboEstado.addItem("Normal");
        cboEstado.addItem("Stock bajo");
        cboEstado.addItem("Sin stock");
        cboEstado.setBounds(690, 140, 180, 25);
        cboEstado.setEnabled(false);

        //botones
        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(280, 270, 125, 35);
        
        btnActualizar = new JButton("Actualizar  Stock");
        btnActualizar.setBounds(420, 270, 160, 35);

        btnListar = new JButton("Listar");
        btnListar.setBounds(600, 270, 125, 35);

        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(740, 270, 125, 35);
        
        //iconos de botones
        btnActualizar.setIcon(Iconos.cargar("/imagenes/actualizar.png", 20, 20));
        btnBuscar.setIcon(Iconos.cargar("/imagenes/buscar.png", 20, 20));
        btnListar.setIcon(Iconos.cargar("/imagenes/listar.png", 20, 20));
        btnLimpiar.setIcon(Iconos.cargar("/imagenes/limpiar.png", 20, 20));
        
        //tabla
        lblListaInventario = new JLabel("LISTADO DE INVENTARIO");
        lblListaInventario.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblListaInventario.setBounds(90, 330, 250, 25);

        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("Código");
        modeloTabla.addColumn("Producto");
        modeloTabla.addColumn("Categoría");
        modeloTabla.addColumn("Stock Actual");
        modeloTabla.addColumn("Stock Mínimo");
        modeloTabla.addColumn("Estado");
        modeloTabla.addColumn("Actualizado");

        tablaInventario = new JTable(modeloTabla);
        scrollTabla = new JScrollPane(tablaInventario);
        scrollTabla.setBounds(90, 360, 980, 230);
        //mejora en la tabla
        tablaInventario.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        tablaInventario.setFillsViewportHeight(true);
        tablaInventario.setGridColor(new Color(220,220,220));
        tablaInventario.setShowGrid(true);

        btnActualizar.addActionListener(e -> actualizar());
        btnBuscar.addActionListener(e -> buscar());
        btnListar.addActionListener(e -> listar());
        btnLimpiar.addActionListener(e -> limpiar());

        panel.add(lblTitulo);
        panel.add(lblProducto);
        panel.add(cboProducto);
        panel.add(lblStockActual);
        panel.add(txtStockActual);
        panel.add(lblStockMinimo);
        panel.add(txtStockMinimo);
        panel.add(lblFechaActualizacion);
        panel.add(txtFechaActualizacion);
        panel.add(lblEstado);
        panel.add(cboEstado);

        panel.add(btnActualizar);
        panel.add(btnBuscar);
        panel.add(btnListar);
        panel.add(btnLimpiar);
        
        panel.add(scrollTabla);
        panel.add(lblListaInventario);
        add(panel);
        }

    private void cargarProductos() {
        cboProducto.removeAllItems();
        
        cboProducto.addItem("Seleccione");
        listaProductos = controladorProducto.listarProductos();

        
        for (Producto pro : listaProductos) {
            cboProducto.addItem(pro.getNombre());
        }
    }

    private Producto obtenerProductoSeleccionado() {
        int index = cboProducto.getSelectedIndex();
        if (index <= 0) {
            return null;
        }
        if (listaProductos != null && (index - 1) < listaProductos.size()) {
            return listaProductos.get(index - 1);
        }
        return null;
    }

    private String obtenerEstadoStock(Producto pro) {
        if (pro.getStock() == 0) {
            return "Sin stock";
        } else if (pro.getStock() <= pro.getStockMinimo()) {
            return "Stock bajo";
        } else {
            return "Normal";
        }
    }
    
    private void actualizar() {
        try {
            Producto pro = obtenerProductoSeleccionado();

            if (pro == null) {
                Mensajes.advertencia(this, "Seleccione un producto");
                return;
            }

            if (Validaciones.estaVacio(txtStockActual.getText())) {
                Mensajes.advertencia(this, "Ingrese el nuevo stock");
                return;
            }

            if (!Validaciones.enteroValido(txtStockActual.getText())) {
                Mensajes.advertencia(this, "El stock debe ser numérico");
                return;
            }

            int nuevoStock = Integer.parseInt(txtStockActual.getText().trim());
            
            if (nuevoStock < 0) {
                Mensajes.advertencia(this, "El stock no puede ser negativo");
                txtStockActual.requestFocus();
                return;
            }
            
            pro.setStock(nuevoStock);

            boolean ok = controladorProducto.actualizarProducto(pro);
            if (!ok) {
                Mensajes.error(this,"No se pudo actualizar el producto");
                return;
            }
            
            // Buscar el inventario asociado
            Inventario inv = controlador.buscarPorProducto(pro.getIdProducto());
            if (inv != null) {

                controlador.actualizarStock(inv, nuevoStock);

                txtFechaActualizacion.setText(
                new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss")
                    .format(inv.getFechaActualizacion())
                );
            }    
    
            Mensajes.exito(this, "Stock actualizado correctamente");
            listar();
            limpiar();

        } catch (Exception e) {
            Mensajes.error(this, "No se pudo actualizar el stock");
        }
    }


    private void buscar() {
        Producto pro = obtenerProductoSeleccionado();

        if (pro == null) {
            Mensajes.advertencia(this, "Seleccione un producto.");
            return;
        }

        Inventario inv = controlador.buscarPorProducto(pro.getIdProducto());

        if (inv == null) {
            txtStockActual.setText(String.valueOf(pro.getStock()));
            txtStockMinimo.setText(String.valueOf(pro.getStockMinimo()));
            cboEstado.setSelectedItem(obtenerEstadoStock(pro));
            txtFechaActualizacion.setText("");

            Mensajes.exito(this, "Inventario encontrado correctamente.");
            return;
        }

        txtStockActual.setText(String.valueOf(inv.getStockActual()));
        txtStockMinimo.setText(String.valueOf(inv.getStockMinimo()));
        cboEstado.setSelectedItem(inv.getEstado());

        if (inv.getFechaActualizacion() != null) {
            txtFechaActualizacion.setText(
                    new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss")
                        .format(inv.getFechaActualizacion())
            );
        }

        Mensajes.exito(this, "Inventario encontrado correctamente.");
    }

    private void listar() {
        modeloTabla.setRowCount(0);
        List<Producto> lista = controladorProducto.listarProductos();
        for (Producto pro : lista) {
            Inventario inv = controlador.buscarPorProducto(pro.getIdProducto());

            modeloTabla.addRow(new Object[]{
                pro.getCodigo(),
                pro.getNombre(),
                pro.getCategoria() != null ? pro.getCategoria().getNombre() : "",
                pro.getStock(),
                pro.getStockMinimo(),
                inv != null ? inv.getEstado() : obtenerEstadoStock(pro),
                inv != null && inv.getFechaActualizacion() != null
                        ? new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm")
                            .format(inv.getFechaActualizacion())
                        : ""
            });
        }
    }    
    

    private void limpiar() {
        txtFechaActualizacion.setText("");
        txtStockActual.setText("");
        txtStockMinimo.setText("");

        if (cboProducto.getItemCount() > 0) {
            cboProducto.setSelectedIndex(0);
        }
        cboEstado.setSelectedIndex(0);
        cboProducto.requestFocus();
    }
}
