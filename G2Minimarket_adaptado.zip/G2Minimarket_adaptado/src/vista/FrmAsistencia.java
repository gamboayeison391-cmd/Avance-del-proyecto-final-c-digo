/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import util.Validaciones;

import controlador.ControladorAsistencia;
import controlador.ControladorEmpleado;
import modelo.Asistencia;
import modelo.Empleado;
import java.util.List;

import java.awt.Color;
import java.awt.Font;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import util.FormularioUtil;
import util.Mensajes;

/**
 *
 * @author UCF20429
 */
public class FrmAsistencia extends JInternalFrame {
    private ControladorAsistencia controlador = new ControladorAsistencia();
    private ControladorEmpleado controladorEmpleado = new ControladorEmpleado();
    private List<Empleado> listaEmpleados;

    private JLabel lblTitulo, lblIdAsistencia, lblEmpleado, lblFecha;
    private JLabel lblHoraEntrada, lblHoraSalida, lblEstado, lblObservacion;

    private JTextField txtIdAsistencia, txtFecha, txtHoraEntrada, txtHoraSalida, txtEstado;
    private JTextArea txtObservacion;

    private JComboBox<String> cboEmpleado;

    private JButton btnRegistrarEntrada, btnRegistarSalida, btnBuscar, btnLimpiar;

    private JTable tablaAsistencia;
    private DefaultTableModel modeloTabla;
    private JScrollPane scrollTabla, scrollObservacion;

    public FrmAsistencia() {
        iniciarComponentes();
        cargarEmpleados();
        listar();
    }

    private void iniciarComponentes() {

        setTitle("Gestión de Asistencias");
        setSize(1200, 700);
        setClosable(true);
        setIconifiable(false);
        setMaximizable(false);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        lblTitulo = new JLabel("GESTIÓN DE ASISTENCIAS");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitulo.setBounds(390, 20, 420, 35);

        lblIdAsistencia = new JLabel("ID Asistencia:");
        lblIdAsistencia.setBounds(70, 90, 100, 25);
        txtIdAsistencia = new JTextField();
        txtIdAsistencia.setBounds(180, 90, 180, 25);
        //txtIdAsistencia.setEditable(false);

        lblEmpleado = new JLabel("Empleado:");
        lblEmpleado.setBounds(430, 90,90, 25);
        cboEmpleado = new JComboBox<>();
        cboEmpleado.addItem("Seleccione");
        cboEmpleado.setBounds(530, 90, 350, 25);

        lblFecha = new JLabel("Fecha:");
        lblFecha.setBounds(70, 135, 100, 25);
        txtFecha = new JTextField();
        txtFecha.setBounds(180, 135, 180, 25);
        txtFecha.setToolTipText("Formato: dd/MM/yyyy");
        txtFecha.setText(new SimpleDateFormat("dd/MM/yyyy").format(new Date()));
        //txtFecha.setEditable(false);

        lblHoraEntrada = new JLabel("Hora Entrada:");
        lblHoraEntrada.setBounds(430, 135, 100, 25);
        txtHoraEntrada = new JTextField();
        txtHoraEntrada.setBounds(530, 135, 150, 25);
        txtHoraEntrada.setToolTipText("Formato: HH:mm:ss");
        txtHoraEntrada.setText(new SimpleDateFormat("HH:mm:ss").format(new Date()));
        //txtHoraEntrada.setEditable(false);

        lblHoraSalida = new JLabel("Hora Salida:");
        lblHoraSalida.setBounds(70, 180, 100, 25);
        txtHoraSalida = new JTextField();
        txtHoraSalida.setBounds(180, 180, 180, 25);
        txtHoraSalida.setToolTipText("Formato: HH:mm:ss");

        lblEstado = new JLabel("Estado:");
        lblEstado.setBounds(720, 135, 70, 25);
        txtEstado = new JTextField();
        txtEstado.setBounds(800, 135, 170, 25);
        FormularioUtil.soloLectura(txtEstado);

        lblObservacion = new JLabel("Observación:");
        lblObservacion.setBounds(70, 225, 100, 25);
        txtObservacion = new JTextArea();
        txtObservacion.setLineWrap(true);
        txtObservacion.setWrapStyleWord(true);
        scrollObservacion = new JScrollPane(txtObservacion);
        scrollObservacion.setBounds(180, 225, 790, 70);

        btnRegistrarEntrada = new JButton("Registrar Entrada");
        btnRegistrarEntrada.setBounds(180, 320, 160, 32);

        btnRegistarSalida = new JButton("Registrar Salida");
        btnRegistarSalida.setBounds(360, 320, 160, 32);
    

        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(670, 320, 110, 32);

        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(800, 320, 110, 32);

        
        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("ID Asistencia");
        modeloTabla.addColumn("Empleado");
        modeloTabla.addColumn("Fecha");
        modeloTabla.addColumn("Hora Entrada");
        modeloTabla.addColumn("Hora Salida");
        modeloTabla.addColumn("Estado");
        modeloTabla.addColumn("Observación");

        tablaAsistencia = new JTable(modeloTabla);
        scrollTabla = new JScrollPane(tablaAsistencia);
        scrollTabla.setBounds(50, 380, 1080, 220);

        btnRegistrarEntrada.addActionListener(e -> registrarEntrada());
        btnRegistarSalida.addActionListener(e -> registrarSalida());
        btnBuscar.addActionListener(e -> buscar());
        btnLimpiar.addActionListener(e -> limpiar());

        panel.add(lblTitulo);
        panel.add(lblIdAsistencia);
        panel.add(txtIdAsistencia);
        panel.add(lblEmpleado);
        panel.add(cboEmpleado);
        panel.add(lblFecha);
        panel.add(txtFecha);
        panel.add(lblHoraEntrada);
        panel.add(txtHoraEntrada);
        panel.add(lblHoraSalida);
        panel.add(txtHoraSalida);
        panel.add(lblEstado);
        panel.add(txtEstado);
        panel.add(lblObservacion);
        panel.add(scrollObservacion);

        panel.add(btnRegistrarEntrada);
        panel.add(btnRegistarSalida);
        panel.add(btnBuscar);
        panel.add(btnLimpiar);

        panel.add(scrollTabla);

        add(panel);
    }

    //Metodos
    private void cargarEmpleados() {
        cboEmpleado.removeAllItems();
        listaEmpleados = controladorEmpleado.listarEmpleados();

        for (Empleado emp : listaEmpleados) {
            cboEmpleado.addItem(emp.getNombre() + " " + emp.getApPaterno());
            }
        }

    private Empleado obtenerEmpleadoSeleccionado() {
        int i = cboEmpleado.getSelectedIndex();
    
        if (i >= 0 && listaEmpleados != null && i < listaEmpleados.size()) {
            return listaEmpleados.get(i);
        }
        return null;
    }

    private Asistencia leerDatos() throws Exception {
       Asistencia asistencia = new Asistencia();

       asistencia.setEmpleado(obtenerEmpleadoSeleccionado());
       asistencia.setFecha(new SimpleDateFormat("dd/MM/yyyy").parse(txtFecha.getText().trim()));
       asistencia.setHoraEntrada(txtHoraEntrada.getText().trim());
       asistencia.setHoraSalida(txtHoraSalida.getText().trim());
       asistencia.setObservacion(txtObservacion.getText().trim());

       txtEstado.setText(asistencia.getEstado());

       return asistencia;
    }

    private void registrarEntrada() {
        try {
            if (!validarCampos()) {
                return;
            }
            Asistencia asistencia = leerDatos();

            if (controlador.existeAsistenciaHoy(
                asistencia.getEmpleado().getIdPersona(),
                asistencia.getFecha())) {
                Mensajes.advertencia(this,"Este empleado ya tiene una asistencia registrada para la fecha actual.");
                return;
            }
            
            if (asistencia.getEmpleado() == null) {
                Mensajes.advertencia(this, "Seleccione un empleado");
            return;
        }

        if (controlador.registrarAsistencia(asistencia)) {
            Mensajes.exito(this, "Asistencia registrada correctamente");
            listar();
            limpiar();
            } else {
                Mensajes.error(this, "No se pudo registrar asistencia");
            }

            } catch (Exception e) {
            Mensajes.advertencia(this, "Revise fecha u horas. Formato fecha: dd/MM/yyyy, hora: HH:mm:ss");
        }
    }

    private void registrarSalida() {
        try {
            if (txtIdAsistencia.getText().trim().isEmpty()) {
                Mensajes.advertencia(this, "Primero busque una asistencia para registrar la salida.");
                return;
            }

            if ("Salida registrada".equals(txtEstado.getText())) {
                Mensajes.advertencia(this, "La salida ya fue registrada.");
                return;
            }

            if ("Falta".equals(txtEstado.getText())) {
                Mensajes.advertencia(this, "No se puede registrar la salida de una asistencia marcada como falta.");
                return;
            }

            if (!validarCampos()) {
                return;
            }

            Asistencia asistencia = leerDatos();
            asistencia.setIdAsistencia(Integer.parseInt(txtIdAsistencia.getText().trim()));

            if (controlador.actualizarAsistencia(asistencia)) {
                Mensajes.exito(this, "Salida registrada correctamente");
                listar();
                limpiar();
            } else {
                Mensajes.error(this, "No se pudo registrar la salida");
            }

        } catch (Exception e) {
            Mensajes.advertencia(this, "Revise fecha u horas. Formato fecha: dd/MM/yyyy, hora: HH:mm:ss");
        }
    }

    private boolean validarCampos() {

        if (cboEmpleado.getSelectedIndex() == -1) {
            Mensajes.advertencia(this, "Seleccione un empleado.");
            cboEmpleado.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtFecha.getText())) {
            Mensajes.advertencia(this, "Ingrese la fecha.");
            txtFecha.requestFocus();
            return false;
        }

        if (!Validaciones.fechaValida(txtFecha.getText().trim())) {
            Mensajes.advertencia(this, "La fecha debe tener formato dd/MM/yyyy.");
            txtFecha.requestFocus();
            return false;
        }

        // Hora de entrada (opcional)
        if (!Validaciones.estaVacio(txtHoraEntrada.getText())
            && !Validaciones.horaValida(txtHoraEntrada.getText().trim())) {

            Mensajes.advertencia(this, "La hora de entrada debe tener formato HH:mm:ss.");
            txtHoraEntrada.requestFocus();
            return false;
        }

        // Hora de salida (opcional)
        if (!Validaciones.estaVacio(txtHoraSalida.getText())
            && !Validaciones.horaValida(txtHoraSalida.getText().trim())) {
            Mensajes.advertencia(this, "La hora de salida debe tener formato HH:mm:ss.");
            txtHoraSalida.requestFocus();
            return false;
        }

        // Si hay hora de salida, debe existir hora de entrada
        if (Validaciones.estaVacio(txtHoraEntrada.getText())
            && !Validaciones.estaVacio(txtHoraSalida.getText())) {
            Mensajes.advertencia(this,"No puede registrar una hora de salida sin una hora de entrada.");
            txtHoraEntrada.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtObservacion.getText())) {
            Mensajes.advertencia(this, "Ingrese una observación.");
            txtObservacion.requestFocus();
            return false;
        }

        return true;
    }

    private void buscar() {
        try {
            if (txtIdAsistencia.getText().trim().isEmpty()) {
                Mensajes.advertencia(this, "Ingrese el ID de la asistencia.");
                txtIdAsistencia.requestFocus();
                return;
            }

            int id = Integer.parseInt(txtIdAsistencia.getText().trim());

            Asistencia asistencia = controlador.buscarAsistencia(id);

            if (asistencia != null) {
                txtFecha.setText(new java.text.SimpleDateFormat("dd/MM/yyyy").format(asistencia.getFecha()));
                txtHoraEntrada.setText(asistencia.getHoraEntrada());
                txtHoraSalida.setText(asistencia.getHoraSalida());
                txtEstado.setText(asistencia.getEstado());
                txtObservacion.setText(asistencia.getObservacion());

                if (asistencia.getEmpleado() != null) {
                    cboEmpleado.setSelectedItem(
                        asistencia.getEmpleado().getNombre() + " "
                        + asistencia.getEmpleado().getApPaterno()
                    );
                }

                txtIdAsistencia.setEditable(false);
    
                btnRegistrarEntrada.setEnabled(false);
                btnRegistarSalida.setEnabled(true);

                Mensajes.exito(this, "Asistencia encontrada correctamente.");

            } else {
                Mensajes.advertencia(this, "Asistencia no encontrada.");
            }

        } catch (Exception e) {
            Mensajes.advertencia(this, "Ingrese un ID válido.");
        }
    }

    private void listar() {
        modeloTabla.setRowCount(0);

        List<Asistencia> lista = controlador.listarAsistencias();

        for (Asistencia a : lista) {

            String horaEntrada = a.getHoraEntrada() == null || a.getHoraEntrada().isBlank()
                    ? ""
                    : a.getHoraEntrada();

            String horaSalida;

            if (a.getEstado().equals("Falta")) {
                horaSalida = "No aplica";
            } else {
                horaSalida = a.getHoraSalida() == null || a.getHoraSalida().isBlank()
                        ? "Sin salida"
                        : a.getHoraSalida();
            }

            modeloTabla.addRow(new Object[]{
                a.getIdAsistencia(),
                a.getEmpleado().getNombre() + " " + a.getEmpleado().getApPaterno(),
                new SimpleDateFormat("dd/MM/yyyy").format(a.getFecha()),
                horaEntrada,
                horaSalida,
                a.getEstado(),
                a.getObservacion()
            });
        }
    }

    private void limpiar() {
        txtIdAsistencia.setText("");
        txtFecha.setText(new SimpleDateFormat("dd/MM/yyyy").format(new Date()));
        txtHoraEntrada.setText(new SimpleDateFormat("HH:mm:ss").format(new Date()));
        txtHoraSalida.setText("");
        txtObservacion.setText("");
        txtEstado.setText("");

        if (cboEmpleado.getItemCount() > 0) {
            cboEmpleado.setSelectedIndex(0);
        }

        txtIdAsistencia.setEditable(true);

        btnRegistrarEntrada.setEnabled(true);
        btnRegistarSalida.setEnabled(true);

        txtIdAsistencia.requestFocus();
    }
}