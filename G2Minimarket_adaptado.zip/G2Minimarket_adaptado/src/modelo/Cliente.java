/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author UCF20429
 */
public class Cliente extends Persona {

    private int puntosAcumulados;

    // Relación con Venta
    private ArrayList<Venta> ventas;

    public Cliente() {
        ventas = new ArrayList<>();
    }

    public Cliente(int puntosAcumulados,
                   ArrayList<Venta> ventas,
                   int idPersona,
                   String tipoDocumento,
                   String nroDocumento,
                   String nombre,
                   String apPaterno,
                   String apMaterno,
                   Date fechaNacimiento,
                   String sexo,
                   String telefono,
                   String correo,
                   String direccion,
                   boolean estado) {

        super(idPersona,
              tipoDocumento,
              nroDocumento,
              nombre,
              apPaterno,
              apMaterno,
              fechaNacimiento,
              sexo,
              telefono,
              correo,
              direccion,
              estado);

        this.puntosAcumulados = puntosAcumulados;
        this.ventas = ventas;
    }

    public int getPuntosAcumulados() {
        return puntosAcumulados;
    }

    public void setPuntosAcumulados(int puntosAcumulados) {
        this.puntosAcumulados = puntosAcumulados;
    }

    public ArrayList<Venta> getVentas() {
        return ventas;
    }

    public void setVentas(ArrayList<Venta> ventas) {
        this.ventas = ventas;
    }

    // metodos
    public String getNombreCompleto() {
        return getNombre() + " " +
               getApPaterno() + " " +
               getApMaterno();
    }

    public boolean tieneVentas() {
        return ventas != null && !ventas.isEmpty();
    }

    public String getTipoCliente() {

        if (puntosAcumulados >= 50) {
            return "VIP";
        }

        if (puntosAcumulados >= 20) {
            return "Frecuente";
        }

        return "Nuevo";
    }

    @Override
    public String toString() {
        return getNombreCompleto();
    }
}