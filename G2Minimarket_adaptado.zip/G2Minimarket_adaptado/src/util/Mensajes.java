/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import java.awt.Component;
import javax.swing.JOptionPane;

/**
 *
 * @author USUARIO
 */
public class Mensajes {
    public static void exito(Component parent, String mensaje) {
        JOptionPane.showMessageDialog(
                parent,
                mensaje,
                "Operación exitosa",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    public static void error(Component parent, String mensaje) {
        JOptionPane.showMessageDialog(
                parent,
                mensaje,
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }

    public static void advertencia(Component parent, String mensaje) {
        JOptionPane.showMessageDialog(
                parent,
                mensaje,
                "Advertencia",
                JOptionPane.WARNING_MESSAGE
        );
    }

    public static boolean confirmar(Component parent, String mensaje) {
        int opcion = JOptionPane.showConfirmDialog(
                parent,
                mensaje,
                "Confirmar acción",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        return opcion == JOptionPane.YES_OPTION;
    }
}
