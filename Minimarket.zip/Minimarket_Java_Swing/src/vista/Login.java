/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;
import util.Iconos;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import util.Mensajes;

/**
 *
 * @author UCF20429
 */
public class Login extends JFrame {

    // componentes de la ventana
    private JLabel lblTitulo, lblUsuario, lblPassword, lblLogo;
    private JTextField txtUsuario;
    private JPasswordField txtPassword;
    private JCheckBox chkVerPassword;
    private JButton btnIngresar, btnLimpiar, btnSalir;

    // constructor: solo arma la ventana
    public Login() {
        iniciarComponentes();
    }

    // aqui se crean y se acomodan todos los componentes
    private void iniciarComponentes() {

        // configuracion de la ventana
        setTitle("Sistema Minimarket - Login");
        setSize(420, 360);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        // panel principal con posiciones manuales (layout null)
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(245, 247, 250));
        
        
        // logo del minimarket (imagen nueva)
        lblLogo = new JLabel();
        lblLogo.setBounds(170, 10, 80, 80);
        lblLogo.setHorizontalAlignment(SwingConstants.CENTER);

        try {
            // se carga desde la carpeta imagenes y se ajusta a 80x80
            ImageIcon icono = new ImageIcon(getClass().getResource("/imagenes/logo_login.png"));
            Image img = icono.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);
            lblLogo.setIcon(new ImageIcon(img));
        } catch (Exception e) {
            // si no encuentra la imagen muestra un texto
            lblLogo.setText("LOGO");
        }

        // título del formulario
        lblTitulo = new JLabel("INICIO DE SESIÓN");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitulo.setForeground(new Color(30, 58, 138));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBounds(35, 85, 350, 30);

        // campo usuario
        lblUsuario = new JLabel("Usuario:");
        lblUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblUsuario.setBounds(40, 125, 100, 25);
        lblUsuario.setHorizontalAlignment(SwingConstants.RIGHT);
        txtUsuario = new JTextField();
        txtUsuario.setBounds(150, 125, 200, 28);
        // icono del usuario
        lblUsuario.setIcon(Iconos.cargar("/imagenes/usuario.png",18,18));
        lblUsuario.setIconTextGap(5);

        // campo contraseña
        lblPassword = new JLabel("Contraseña:");
        lblPassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblPassword.setBounds(40, 165, 100, 25);
        lblPassword.setHorizontalAlignment(SwingConstants.RIGHT);
        txtPassword = new JPasswordField();
        txtPassword.setBounds(150, 165, 200, 28);
        // icono de la contraseña
        lblPassword.setIcon(Iconos.cargar("/imagenes/password.png",18,18));
        lblPassword.setIconTextGap(5);
        
        // check para mostrar u ocultar la contraseña
        chkVerPassword = new JCheckBox("Ver contraseña");
        chkVerPassword.setBounds(150, 195, 150, 25);
        chkVerPassword.setBackground(new Color(245, 247, 250));
        chkVerPassword.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        // botón ingresar
        btnIngresar = new JButton("Ingresar");
        btnIngresar.setBounds(110, 230, 190, 38);
        btnIngresar.setBackground(new Color(37, 99, 235));
        btnIngresar.setForeground(Color.WHITE);
        btnIngresar.setFont(new Font("Segoe UI", Font.BOLD, 15));
        // icono del botón
        btnIngresar.setIcon(Iconos.cargar("/imagenes/ingresar.png",20,20));
        btnIngresar.setHorizontalTextPosition(SwingConstants.RIGHT);
        btnIngresar.setIconTextGap(8);
        
        
        // botón limpiar
        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(80, 280, 120, 35);
        btnLimpiar.setBackground(new Color(230,230,230));
        btnLimpiar.setForeground(Color.BLACK);
        btnLimpiar.setFont(new Font("Segoe UI", Font.BOLD, 13));
        // icono del botón
        btnLimpiar.setIcon(Iconos.cargar("/imagenes/limpiar.png",20,20));
        btnLimpiar.setHorizontalTextPosition(SwingConstants.RIGHT);
        btnLimpiar.setIconTextGap(8);

        // botón salir
        btnSalir = new JButton("Salir");
        btnSalir.setBounds(220, 280, 120, 35);
        btnSalir.setBackground(new Color(220, 38, 38));
        btnSalir.setForeground(Color.WHITE);
        btnSalir.setFont(new Font("Segoe UI", Font.BOLD, 13));
        // icono del botón
        btnSalir.setIcon(Iconos.cargar("/imagenes/salir.png",20,20));
        btnSalir.setHorizontalTextPosition(SwingConstants.RIGHT);
        btnSalir.setIconTextGap(8);
        
        // eventos de los botones
        btnIngresar.addActionListener(e -> ingresar());
        btnLimpiar.addActionListener(e -> limpiar());
        btnSalir.addActionListener(e -> salir());
        // si está marcado se ve la contraseña, si no se oculta con •
        chkVerPassword.addActionListener(e -> {
        if (chkVerPassword.isSelected()) {
            txtPassword.setEchoChar((char) 0);
            } else {
                txtPassword.setEchoChar('•');
            }
        });
        
        // con Enter se presiona Ingresar
        getRootPane().setDefaultButton(btnIngresar);

        // agregamos todo al panel
        panel.add(lblLogo);
        panel.add(lblTitulo);
        panel.add(lblUsuario);
        panel.add(txtUsuario);
        panel.add(lblPassword);
        panel.add(txtPassword);
        panel.add(chkVerPassword);
        panel.add(btnIngresar);
        panel.add(btnLimpiar);
        panel.add(btnSalir);

        add(panel);
    }

    // valida los datos y entra al sistema
    private void ingresar() {
        // se obtienen los datos escritos
        String usuario = txtUsuario.getText().trim();
        String password = String.valueOf(txtPassword.getPassword()).trim();

        // validamos que no estén vacíos
        if (usuario.isEmpty()) {
            Mensajes.advertencia(this, "Ingrese el usuario");
            txtUsuario.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            Mensajes.advertencia(this, "Ingrese la contraseña");
            txtPassword.requestFocus();
            return;
        }

        // se comprueban las credenciales con el controlador
        controlador.ControladorUsuario controlador = new controlador.ControladorUsuario();

        if (controlador.validarLogin(usuario, password)) {

            Mensajes.exito(this, "Bienvenido al sistema");

            // abre la ventana principal y cierra el login
            Principal principal = new Principal();
            principal.setVisible(true);

            dispose();

        } else {
            // datos incorrectos: limpia la contraseña
            Mensajes.error(this, "Usuario o contraseña incorrectos");
            txtPassword.setText("");
            txtPassword.requestFocus();
        }
    }

    // deja los campos como al inicio
    private void limpiar() {
        txtUsuario.setText("");
        txtPassword.setText("");
        chkVerPassword.setSelected(false);
        txtPassword.setEchoChar('•');
        txtUsuario.requestFocus();
    }

    // pide confirmación antes de cerrar el programa
    private void salir() {
        int op = JOptionPane.showConfirmDialog(
                this,
                "¿Desea salir del sistema?",
                "Confirmar",
                JOptionPane.YES_NO_OPTION);

        if (op == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }
}
