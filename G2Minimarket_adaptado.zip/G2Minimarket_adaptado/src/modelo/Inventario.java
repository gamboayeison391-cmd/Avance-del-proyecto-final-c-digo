/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author UCF20429
 */
public class Inventario {
    private int idInventario;
    private int stockActual;
    private int stockMinimo;
    private String ubicacion;
    private Date fechaActualizacion;
    private String estado;

    // Relación con Producto
    private ArrayList<Producto> productos;

    public Inventario() {
        productos = new ArrayList<>();
        fechaActualizacion = new Date();
    }

    public Inventario(int idInventario,
                      int stockActual,
                      int stockMinimo,
                      String ubicacion,
                      Date fechaActualizacion,
                      String estado,
                      ArrayList<Producto> productos) {

        this.idInventario = idInventario;
        this.stockActual = stockActual;
        this.stockMinimo = stockMinimo;
        this.ubicacion = ubicacion;
        this.fechaActualizacion = fechaActualizacion;
        this.estado = estado;
        this.productos = productos;
    }

    public int getIdInventario() {
        return idInventario;
    }

    public void setIdInventario(int idInventario) {
        this.idInventario = idInventario;
    }

    public int getStockActual() {
        return stockActual;
    }

    public void setStockActual(int stockActual) {
        this.stockActual = stockActual;
    }

    public int getStockMinimo() {
        return stockMinimo;
    }

    public void setStockMinimo(int stockMinimo) {
        this.stockMinimo = stockMinimo;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public Date getFechaActualizacion() {
        return fechaActualizacion;
    }

    public void setFechaActualizacion(Date fechaActualizacion) {
        this.fechaActualizacion = fechaActualizacion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public ArrayList<Producto> getProductos() {
        return productos;
    }

    public void setProductos(ArrayList<Producto> productos) {
        this.productos = productos;
    }
    
    public Producto buscarProducto(String codigo) {
        if (codigo == null) {
            return null;
        }
        for (Producto pro : productos) {
            if (pro.getCodigo().equalsIgnoreCase(codigo)) {
                return pro;
            }
        }
        return null;
    }

    public int calcularCantidadProductos() {
        return productos.size();
    }

    public void verificarStock() {
        if (stockActual == 0) {
            estado = "Sin stock";
        } else if (stockActual <= stockMinimo) {
            estado = "Stock bajo";
        } else {
            estado = "Normal";
        }
    }
}