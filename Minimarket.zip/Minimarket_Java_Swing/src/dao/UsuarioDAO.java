package dao;

import java.util.List;
import modelo.Usuario;

public class UsuarioDAO implements CrudDAO<Usuario> {

    private static final Almacen<Usuario> ALMACEN = new Almacen<>(0);

    @Override
    public boolean registrar(Usuario usu) {
        usu.setIdUsuario(ALMACEN.siguienteId());
        ALMACEN.agregar(usu);
        return true;
    }

    @Override
    public boolean actualizar(Usuario usu) {
        return ALMACEN.reemplazar(u -> u.getIdUsuario() == usu.getIdUsuario(), usu);
    }

    @Override
    public boolean eliminar(int idUsuario) {
        return ALMACEN.quitar(u -> u.getIdUsuario() == idUsuario);
    }

    public boolean desactivar(int idUsuario) {
        return cambiarEstado(idUsuario, false);
    }

    public boolean activar(int idUsuario) {
        return cambiarEstado(idUsuario, true);
    }

    private boolean cambiarEstado(int idUsuario, boolean estado) {
        Usuario usu = ALMACEN.buscar(u -> u.getIdUsuario() == idUsuario).orElse(null);
        if (usu == null) {
            return false;
        }
        usu.setEstado(estado);
        return true;
    }

    public Usuario buscarPorUsuario(String nombreUsuario) {
        return ALMACEN.buscar(u -> u.getNombreUsuario().equalsIgnoreCase(nombreUsuario)).orElse(null);
    }

    /** Credenciales correctas y usuario activo. */
    public boolean validarLogin(String usuario, String contrasena) {
        Usuario usu = buscarPorUsuario(usuario);
        return usu != null && usu.isEstado() && usu.getContrasena().equals(contrasena);
    }

    @Override
    public List<Usuario> listar() {
        return ALMACEN.todos();
    }

    public List<Usuario> listarActivos() {
        return ALMACEN.filtrar(Usuario::isEstado);
    }

    public boolean existeUsuario(String nombreUsuario) {
        return buscarPorUsuario(nombreUsuario) != null;
    }

    public boolean existeEmpleadoUsuario(int idPersona) {
        return ALMACEN.existe(u -> u.getEmpleado() != null && u.getEmpleado().getIdPersona() == idPersona);
    }
}
