/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexion.ConexionBD;
import modelo.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author USUARIO
 */
public class ReporteDAO {

    public List<Venta> reporteVentas(Date fechaInicio, Date fechaFin) {
        List<Venta> lista = new ArrayList<>();

        String sql = """
            SELECT
                v.idVenta,
                v.fecha,
                v.hora,
                v.subtotal,
                v.igv,
                v.total,
                pc.nombre AS nombreCliente,
                pc.apPaterno AS apPaternoCliente,
                pe.nombre AS nombreEmpleado,
                pe.apPaterno AS apPaternoEmpleado
            FROM Venta v
            INNER JOIN Cliente c ON v.idCliente = c.idCliente
            INNER JOIN Persona pc ON c.idPersona = pc.idPersona
            INNER JOIN Empleado e ON v.idEmpleado = e.idEmpleado
            INNER JOIN Persona pe ON e.idPersona = pe.idPersona
            WHERE v.fecha BETWEEN ? AND ?
            ORDER BY v.fecha DESC
        """;

        try {
            Connection cn = ConexionBD.conectar();
            PreparedStatement ps = cn.prepareStatement(sql);

            ps.setDate(1, fechaInicio);
            ps.setDate(2, fechaFin);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Cliente cliente = new Cliente();
                cliente.setNombre(rs.getString("nombreCliente"));
                cliente.setApPaterno(rs.getString("apPaternoCliente"));

                Empleado empleado = new Empleado();
                empleado.setNombre(rs.getString("nombreEmpleado"));
                empleado.setApPaterno(rs.getString("apPaternoEmpleado"));

                Venta venta = new Venta();
                venta.setIdVenta(rs.getInt("idVenta"));
                venta.setFecha(rs.getDate("fecha"));

                Time hora = rs.getTime("hora");
                venta.setHora(hora != null ? hora.toString() : "");

                venta.setSubtotal(rs.getDouble("subtotal"));
                venta.setIgv(rs.getDouble("igv"));
                venta.setTotal(rs.getDouble("total"));
                venta.setCliente(cliente);
                venta.setEmpleado(empleado);

                lista.add(venta);
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error reporte ventas: " + e.getMessage());
        }

        return lista;
    }

    public List<Compra> reporteCompras(Date fechaInicio, Date fechaFin) {
        List<Compra> lista = new ArrayList<>();

        String sql = """
            SELECT
                c.idCompra,
                c.fecha,
                c.total,
                pr.razonSocial,
                pe.nombre AS nombreEmpleado,
                pe.apPaterno AS apPaternoEmpleado
            FROM Compra c
            INNER JOIN Proveedor pr ON c.idProveedor = pr.idProveedor
            INNER JOIN Empleado e ON c.idEmpleado = e.idEmpleado
            INNER JOIN Persona pe ON e.idPersona = pe.idPersona
            WHERE c.fecha BETWEEN ? AND ?
            ORDER BY c.fecha DESC
        """;

        try {
            Connection cn = ConexionBD.conectar();
            PreparedStatement ps = cn.prepareStatement(sql);

            ps.setDate(1, fechaInicio);
            ps.setDate(2, fechaFin);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Proveedor proveedor = new Proveedor();
                proveedor.setRazonSocial(rs.getString("razonSocial"));

                Empleado empleado = new Empleado();
                empleado.setNombre(rs.getString("nombreEmpleado"));
                empleado.setApPaterno(rs.getString("apPaternoEmpleado"));

                Compra compra = new Compra();
                compra.setIdCompra(rs.getInt("idCompra"));
                compra.setFecha(rs.getDate("fecha"));
                compra.setTotal(rs.getDouble("total"));
                compra.setProveedor(proveedor);
                compra.setEmpleado(empleado);

                lista.add(compra);
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error reporte compras: " + e.getMessage());
        }

        return lista;
    }

    public List<Producto> reporteInventario() {
        List<Producto> lista = new ArrayList<>();

        String sql = """
            SELECT
                p.idProducto,
                p.codigo,
                p.nombre,
                p.marca,
                p.precioCompra,
                p.precioVenta,
                p.stock,
                p.stockMinimo,
                p.estado,
                c.idCategoria,
                c.nombre AS nombreCategoria
            FROM Producto p
            INNER JOIN Categoria c ON p.idCategoria = c.idCategoria
            ORDER BY p.stock ASC
        """;

        try {
            Connection cn = ConexionBD.conectar();
            PreparedStatement ps = cn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Categoria categoria = new Categoria();
                categoria.setIdCategoria(rs.getInt("idCategoria"));
                categoria.setNombre(rs.getString("nombreCategoria"));

                Producto producto = new Producto();
                producto.setIdProducto(rs.getInt("idProducto"));
                producto.setCodigo(rs.getString("codigo"));
                producto.setNombre(rs.getString("nombre"));
                producto.setMarca(rs.getString("marca"));
                producto.setPrecioCompra(rs.getDouble("precioCompra"));
                producto.setPrecioVenta(rs.getDouble("precioVenta"));
                producto.setStock(rs.getInt("stock"));
                producto.setStockMinimo(rs.getInt("stockMinimo"));
                producto.setEstado(rs.getBoolean("estado"));
                producto.setCategoria(categoria);

                lista.add(producto);
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error reporte inventario: " + e.getMessage());
        }

        return lista;
    }

    public double totalVentas(Date fechaInicio, Date fechaFin) {
        String sql = """
            SELECT IFNULL(SUM(total), 0)
            FROM Venta
            WHERE fecha BETWEEN ? AND ?
        """;

        try {
            Connection cn = ConexionBD.conectar();
            PreparedStatement ps = cn.prepareStatement(sql);

            ps.setDate(1, fechaInicio);
            ps.setDate(2, fechaFin);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                double total = rs.getDouble(1);

                rs.close();
                ps.close();
                ConexionBD.cerrar(cn);

                return total;
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error total ventas: " + e.getMessage());
        }

        return 0;
    }

    public double totalCompras(Date fechaInicio, Date fechaFin) {
        String sql = """
            SELECT IFNULL(SUM(total), 0)
            FROM Compra
            WHERE fecha BETWEEN ? AND ?
        """;

        try {
            Connection cn = ConexionBD.conectar();
            PreparedStatement ps = cn.prepareStatement(sql);

            ps.setDate(1, fechaInicio);
            ps.setDate(2, fechaFin);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                double total = rs.getDouble(1);

                rs.close();
                ps.close();
                ConexionBD.cerrar(cn);

                return total;
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error total compras: " + e.getMessage());
        }

        return 0;
    }

    public double gananciaVentas(Date fechaInicio, Date fechaFin) {
        String sql = """
            SELECT IFNULL(SUM(
                (dv.precioUnitario - p.precioCompra) * dv.cantidad
            ), 0) AS ganancia
            FROM DetalleVenta dv
            INNER JOIN Producto p ON dv.idProducto = p.idProducto
            INNER JOIN Venta v ON dv.idVenta = v.idVenta
            WHERE v.fecha BETWEEN ? AND ?
        """;

        try {
            Connection cn = ConexionBD.conectar();
            PreparedStatement ps = cn.prepareStatement(sql);

            ps.setDate(1, fechaInicio);
            ps.setDate(2, fechaFin);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                double ganancia = rs.getDouble("ganancia");

                rs.close();
                ps.close();
                ConexionBD.cerrar(cn);

                return ganancia;
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error calcular ganancia: " + e.getMessage());
        }

        return 0;
    }
}
