package dao;

import java.util.List;
import modelo.Categoria;

public class CategoriaDAO implements CrudDAO<Categoria> {

    private static final Almacen<Categoria> ALMACEN = new Almacen<>(0);

    @Override
    public boolean registrar(Categoria cat) {
        cat.setIdCategoria(ALMACEN.siguienteId());
        ALMACEN.agregar(cat);
        return true;
    }

    @Override
    public boolean actualizar(Categoria cat) {
        return ALMACEN.reemplazar(c -> c.getIdCategoria() == cat.getIdCategoria(), cat);
    }

    @Override
    public boolean eliminar(int idCategoria) {
        if (tieneProductosAsociados(idCategoria)) {
            return desactivar(idCategoria);
        }
        return ALMACEN.quitar(c -> c.getIdCategoria() == idCategoria);
    }

    public boolean desactivar(int idCategoria) {
        return cambiarEstado(idCategoria, false);
    }

    public boolean activar(int idCategoria) {
        return cambiarEstado(idCategoria, true);
    }

    private boolean cambiarEstado(int idCategoria, boolean estado) {
        Categoria cat = buscarPorId(idCategoria);
        if (cat == null) {
            return false;
        }
        cat.setEstado(estado);
        return true;
    }

    public boolean tieneProductosAsociados(int idCategoria) {
        return new ProductoDAO().listar().stream()
                .anyMatch(p -> p.getCategoria() != null && p.getCategoria().getIdCategoria() == idCategoria);
    }

    public Categoria buscarPorId(int idCategoria) {
        return ALMACEN.buscar(c -> c.getIdCategoria() == idCategoria).orElse(null);
    }

    @Override
    public List<Categoria> listar() {
        return ALMACEN.todos();
    }

    public List<Categoria> listarActivos() {
        return ALMACEN.filtrar(Categoria::isEstado);
    }

    public boolean existeNombre(String nombre) {
        return ALMACEN.existe(c -> c.getNombre().equalsIgnoreCase(nombre.trim()));
    }
}
