package dao;

import java.text.SimpleDateFormat;
import java.util.Date;
import modelo.Categoria;
import modelo.Cliente;
import modelo.Empleado;
import modelo.Inventario;
import modelo.Persona;
import modelo.Producto;
import modelo.Usuario;

/**
 * Datos de ejemplo cargados en memoria al iniciar el prototipo.
 * Usuario de acceso: aaa / 123
 */
public class DatosIniciales {

    private static boolean cargado = false;

    public static void cargar() {
        if (cargado) {
            return;
        }
        cargado = true;
        cargarEmpleadosYUsuarios();
        cargarClientes();
        cargarCategoriasProductosEInventario();
    }

    private static void cargarEmpleadosYUsuarios() {
        EmpleadoDAO empleadoDAO = new EmpleadoDAO();
        UsuarioDAO usuarioDAO = new UsuarioDAO();
        Object[][] filas = {
            {"12345678", "Administrador", "Principal", "Sistema", "EMP001", "Administrador", 2500.0, "aaa", "Administrador"},
            {"70000001", "María", "López", "Ramírez", "EMP002", "Cajero", 1600.0, "maria", "Cajero"},
            {"70000002", "Carlos", "Vargas", "Torres", "EMP003", "Almacenero", 1700.0, "carlos", "Empleado"},
            {"70000003", "Lucía", "Rojas", "Mendoza", "EMP004", "Vendedor", 1550.0, "lucia", "Empleado"}
        };
        for (Object[] f : filas) {
            Empleado emp = new Empleado();
            completarPersona(emp, (String) f[0], (String) f[1], (String) f[2], (String) f[3]);
            emp.setCodigoEmpleado((String) f[4]);
            emp.setFechaIngreso(new Date());
            emp.setCargo((String) f[5]);
            emp.setSueldo((Double) f[6]);
            empleadoDAO.registrar(emp);

            Usuario usu = new Usuario();
            usu.setNombreUsuario((String) f[7]);
            usu.setContrasena("123");
            usu.setRol((String) f[8]);
            usu.setEstado(true);
            usu.setEmpleado(emp);
            usuarioDAO.registrar(usu);
        }
    }

    private static void cargarClientes() {
        ClienteDAO clienteDAO = new ClienteDAO();
        Object[][] filas = {
            {"71000001", "Ana", "Salazar", "Ruiz", 20},
            {"71000002", "Luis", "Fernández", "Pérez", 15},
            {"71000003", "Patricia", "Campos", "León", 50}
        };
        for (Object[] f : filas) {
            Cliente cli = new Cliente();
            completarPersona(cli, (String) f[0], (String) f[1], (String) f[2], (String) f[3]);
            cli.setPuntosAcumulados((Integer) f[4]);
            clienteDAO.registrar(cli);
        }
    }

    private static void cargarCategoriasProductosEInventario() {
        CategoriaDAO categoriaDAO = new CategoriaDAO();
        ProductoDAO productoDAO = new ProductoDAO();
        InventarioDAO inventarioDAO = new InventarioDAO();
        String[][] categorias = {
            {"Bebidas", "Bebidas y gaseosas"},
            {"Lácteos", "Productos lácteos"},
            {"Limpieza", "Productos de limpieza"}
        };
        for (String[] c : categorias) {
            Categoria cat = new Categoria();
            cat.setNombre(c[0]);
            cat.setDescripcion(c[1]);
            cat.setEstado(true);
            categoriaDAO.registrar(cat);
        }
        Object[][] productos = {
            {"PROD001", "Inca Kola 500 ml", "Coca Cola", 2.40, 3.50, 40, 10, "Bebidas"},
            {"PROD002", "Leche Gloria", "Gloria", 3.80, 5.20, 30, 8, "Lácteos"},
            {"PROD003", "Detergente Ariel", "Ariel", 9.50, 13.90, 25, 5, "Limpieza"}
        };
        for (Object[] p : productos) {
            Producto pro = new Producto();
            pro.setCodigo((String) p[0]);
            pro.setNombre((String) p[1]);
            pro.setMarca((String) p[2]);
            pro.setPrecioCompra((Double) p[3]);
            pro.setPrecioVenta((Double) p[4]);
            pro.setStock((Integer) p[5]);
            pro.setStockMinimo((Integer) p[6]);
            pro.setEstado(true);
            pro.setCategoria(categoriaDAO.listar().stream()
                    .filter(c -> c.getNombre().equals(p[7])).findFirst().orElse(null));
            productoDAO.registrar(pro);

            Inventario inv = new Inventario();
            inv.setStockActual(pro.getStock());
            inv.setStockMinimo(pro.getStockMinimo());
            inv.setUbicacion("Almacén principal");
            inv.setFechaActualizacion(new Date());
            inv.setEstado("Normal");
            inventarioDAO.registrar(inv, pro.getIdProducto());
        }
    }

    private static void completarPersona(Persona p, String doc, String nombre, String apPat, String apMat) {
        try {
            p.setFechaNacimiento(new SimpleDateFormat("yyyy-MM-dd").parse("1995-01-01"));
        } catch (java.text.ParseException e) {
            p.setFechaNacimiento(new Date());
        }
        p.setTipoDocumento("DNI");
        p.setNroDocumento(doc);
        p.setNombre(nombre);
        p.setApPaterno(apPat);
        p.setApMaterno(apMat);
        p.setSexo("Masculino");
        p.setTelefono("999999999");
        p.setCorreo(nombre.toLowerCase().replace("í", "i").replace("ú", "u") + "@gmail.com");
        p.setDireccion("Cajamarca");
        p.setEstado(true);
    }
}
