/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexion.ConexionBD;
import modelo.Usuario;
import modelo.Empleado;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USUARIO
 */
public class UsuarioDAO {

    public boolean registrar(Usuario usu) {
        try {
            Connection con = ConexionBD.conectar();

            PreparedStatement sql = con.prepareStatement(
                "INSERT INTO Usuario(idEmpleado, nombreUsuario, contrasena, rol, estado) "
              + "VALUES (?, ?, ?, ?, ?)"
            );

            sql.setInt(1, obtenerIdEmpleado(con, usu.getEmpleado().getIdPersona()));
            sql.setString(2, usu.getNombreUsuario());
            sql.setString(3, usu.getContrasena());
            sql.setString(4, usu.getRol());
            sql.setBoolean(5, usu.isEstado());

            int res = sql.executeUpdate();

            sql.close();
            ConexionBD.cerrar(con);

            return res > 0;

        } catch (SQLException e) {
            System.out.println("Error registrar usuario: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizar(Usuario usu) {
        try {
            Connection con = ConexionBD.conectar();

            PreparedStatement sql = con.prepareStatement(
                "UPDATE Usuario SET "
              + "idEmpleado = ?, nombreUsuario = ?, contrasena = ?, rol = ?, estado = ? "
              + "WHERE idUsuario = ?"
            );

            sql.setInt(1, obtenerIdEmpleado(con, usu.getEmpleado().getIdPersona()));
            sql.setString(2, usu.getNombreUsuario());
            sql.setString(3, usu.getContrasena());
            sql.setString(4, usu.getRol());
            sql.setBoolean(5, usu.isEstado());
            sql.setInt(6, usu.getIdUsuario());

            int res = sql.executeUpdate();

            sql.close();
            ConexionBD.cerrar(con);

            return res > 0;

        } catch (SQLException e) {
            System.out.println("Error actualizar usuario: " + e.getMessage());
            return false;
        }
    }

    public boolean desactivar(int idUsuario) {
        try {
            Connection con = ConexionBD.conectar();

            PreparedStatement sql = con.prepareStatement(
                "UPDATE Usuario SET estado = 0 WHERE idUsuario = ?"
            );

            sql.setInt(1, idUsuario);
    
            int res = sql.executeUpdate();

            sql.close();
            ConexionBD.cerrar(con);

            return res > 0;

        } catch (SQLException e) {
            System.out.println("Error desactivar usuario: " + e.getMessage());
            return false;
        }
    }

    
    public Usuario buscarPorUsuario(String nombreUsuario) {
        try {
            Connection con = ConexionBD.conectar();

            PreparedStatement sql = con.prepareStatement(
                "SELECT u.idUsuario, u.nombreUsuario, u.contrasena, u.rol, u.estado, "
              + "e.idEmpleado, e.codigoEmpleado, e.cargo, e.sueldo, "
              + "p.idPersona, p.tipoDocumento, p.nroDocumento, p.nombre, "
              + "p.apPaterno, p.apMaterno, p.telefono, p.correo, p.direccion "
              + "FROM Usuario u "
              + "INNER JOIN Empleado e ON u.idEmpleado = e.idEmpleado "
              + "INNER JOIN Persona p ON e.idPersona = p.idPersona "
              + "WHERE u.nombreUsuario = ?"
            );

            sql.setString(1, nombreUsuario);

            ResultSet res = sql.executeQuery();

            if (res.next()) {
                Empleado emp = new Empleado();
                emp.setIdPersona(res.getInt("idPersona"));
                emp.setTipoDocumento(res.getString("tipoDocumento"));
                emp.setNroDocumento(res.getString("nroDocumento"));
                emp.setNombre(res.getString("nombre"));
                emp.setApPaterno(res.getString("apPaterno"));
                emp.setApMaterno(res.getString("apMaterno"));
                emp.setTelefono(res.getString("telefono"));
                emp.setCorreo(res.getString("correo"));
                emp.setDireccion(res.getString("direccion"));
                emp.setCodigoEmpleado(res.getString("codigoEmpleado"));
                emp.setCargo(res.getString("cargo"));
                emp.setSueldo(res.getDouble("sueldo"));

                Usuario usu = new Usuario();
                usu.setIdUsuario(res.getInt("idUsuario"));
                usu.setNombreUsuario(res.getString("nombreUsuario"));
                usu.setContrasena(res.getString("contrasena"));
                usu.setRol(res.getString("rol"));
                usu.setEstado(res.getBoolean("estado"));
                usu.setEmpleado(emp);

                res.close();
                sql.close();
                ConexionBD.cerrar(con);

                return usu;
            }

            res.close();
            sql.close();
            ConexionBD.cerrar(con);

        } catch (SQLException e) {
            System.out.println("Error buscar usuario: " + e.getMessage());
        }

        return null;
    }

    public boolean validarLogin(String usuario, String contrasena) {
        try {
            Connection con = ConexionBD.conectar();

            PreparedStatement sql = con.prepareStatement(
                "SELECT COUNT(*) FROM Usuario "
              + "WHERE nombreUsuario = ? AND contrasena = ? AND estado = 1"
            );

            sql.setString(1, usuario);
            sql.setString(2, contrasena);

            ResultSet res = sql.executeQuery();

            if (res.next()) {
                boolean valido = res.getInt(1) > 0;

                res.close();
                sql.close();
                ConexionBD.cerrar(con);

                return valido;
            }

            res.close();
            sql.close();
            ConexionBD.cerrar(con);

        } catch (SQLException e) {
            System.out.println("Error validar login: " + e.getMessage());
        }

        return false;
    }

    public List<Usuario> listar() {
        List<Usuario> lista = new ArrayList<>();

        try {
            Connection con = ConexionBD.conectar();

            PreparedStatement sql = con.prepareStatement(
                "SELECT u.idUsuario, u.nombreUsuario, u.contrasena, u.rol, u.estado, "
              + "e.idEmpleado, e.codigoEmpleado, e.cargo, "
              + "p.idPersona, p.nombre, p.apPaterno, p.apMaterno "
              + "FROM Usuario u "
              + "INNER JOIN Empleado e ON u.idEmpleado = e.idEmpleado "
              + "INNER JOIN Persona p ON e.idPersona = p.idPersona "
              + "ORDER BY u.idUsuario DESC"
            );

            ResultSet res = sql.executeQuery();

            while (res.next()) {
                Empleado emp = new Empleado();
                emp.setIdPersona(res.getInt("idPersona"));
                emp.setCodigoEmpleado(res.getString("codigoEmpleado"));
                emp.setCargo(res.getString("cargo"));
                emp.setNombre(res.getString("nombre"));
                emp.setApPaterno(res.getString("apPaterno"));
                emp.setApMaterno(res.getString("apMaterno"));

                Usuario usu = new Usuario();
                usu.setIdUsuario(res.getInt("idUsuario"));
                usu.setNombreUsuario(res.getString("nombreUsuario"));
                usu.setContrasena(res.getString("contrasena"));
                usu.setRol(res.getString("rol"));
                usu.setEstado(res.getBoolean("estado"));
                usu.setEmpleado(emp);

                lista.add(usu);
            }

            res.close();
            sql.close();
            ConexionBD.cerrar(con);

        } catch (SQLException e) {
            System.out.println("Error listar usuarios: " + e.getMessage());
        }

        return lista;
    }
    
    public List<Usuario> listarActivos() {
        List<Usuario> lista = new ArrayList<>();

        try {
            Connection con = ConexionBD.conectar();

            PreparedStatement sql = con.prepareStatement(
                "SELECT u.idUsuario, u.nombreUsuario, u.contrasena, u.rol, u.estado, "
              + "e.idEmpleado, e.codigoEmpleado, e.cargo, "
              + "p.idPersona, p.nombre, p.apPaterno, p.apMaterno "
              + "FROM Usuario u "
              + "INNER JOIN Empleado e ON u.idEmpleado = e.idEmpleado "
              + "INNER JOIN Persona p ON e.idPersona = p.idPersona "
              + "WHERE u.estado = 1 "
              + "ORDER BY u.idUsuario DESC"
            );

            ResultSet res = sql.executeQuery();

            while (res.next()) {
                Empleado emp = new Empleado();
                emp.setIdPersona(res.getInt("idPersona"));
                emp.setCodigoEmpleado(res.getString("codigoEmpleado"));
                emp.setCargo(res.getString("cargo"));
                emp.setNombre(res.getString("nombre"));
                emp.setApPaterno(res.getString("apPaterno"));
                emp.setApMaterno(res.getString("apMaterno"));

                Usuario usu = new Usuario();
                usu.setIdUsuario(res.getInt("idUsuario"));
                usu.setNombreUsuario(res.getString("nombreUsuario"));
                usu.setContrasena(res.getString("contrasena"));
                usu.setRol(res.getString("rol"));
                usu.setEstado(res.getBoolean("estado"));
                usu.setEmpleado(emp);

                lista.add(usu);
            }

            res.close();
            sql.close();
            ConexionBD.cerrar(con);

        } catch (SQLException e) {
            System.out.println("Error listar usuarios activos: " + e.getMessage());
        }

        return lista;
    }

    public boolean existeUsuario(String nombreUsuario) {
        try {
            Connection con = ConexionBD.conectar();

            PreparedStatement sql = con.prepareStatement(
                "SELECT COUNT(*) FROM Usuario WHERE nombreUsuario = ?"
            );

            sql.setString(1, nombreUsuario);

            ResultSet res = sql.executeQuery();

            if (res.next()) {
                boolean existe = res.getInt(1) > 0;

                res.close();
                sql.close();
                ConexionBD.cerrar(con);

                return existe;
            }

            res.close();
            sql.close();
            ConexionBD.cerrar(con);

        } catch (SQLException e) {
            System.out.println("Error verificar usuario: " + e.getMessage());
        }

        return false;
    }

    public boolean existeEmpleadoUsuario(int idPersona) {
        try {
            Connection con = ConexionBD.conectar();

            PreparedStatement sql = con.prepareStatement(
                "SELECT COUNT(*) "
              + "FROM Usuario u "
              + "INNER JOIN Empleado e ON u.idEmpleado = e.idEmpleado "
              + "WHERE e.idPersona = ?"
            );

            sql.setInt(1, idPersona);

            ResultSet res = sql.executeQuery();

            if (res.next()) {
                boolean existe = res.getInt(1) > 0;

                res.close();
                sql.close();
                ConexionBD.cerrar(con);

                return existe;
            }

            res.close();
            sql.close();
            ConexionBD.cerrar(con);

        } catch (SQLException e) {
            System.out.println("Error verificar usuario empleado: " + e.getMessage());
        }

        return false;
    }

    private int obtenerIdEmpleado(Connection con, int idPersona) throws SQLException {
        PreparedStatement sql = con.prepareStatement(
            "SELECT idEmpleado FROM Empleado WHERE idPersona = ?"
        );

        sql.setInt(1, idPersona);

        ResultSet res = sql.executeQuery();

        if (res.next()) {
            int idEmpleado = res.getInt("idEmpleado");

            res.close();
            sql.close();

            return idEmpleado;
        }

        res.close();
        sql.close();

        throw new SQLException("No se encontró el empleado.");
    }
}
