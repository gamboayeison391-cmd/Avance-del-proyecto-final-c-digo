/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import dao.ClienteDAO;
import modelo.Cliente;

import java.util.List;
/**
 *
 * @author USUARIO
 */
public class ControladorCliente {
    private ClienteDAO clienteDAO;
    public ControladorCliente() {
        clienteDAO = new ClienteDAO();
    }

    public boolean registrarCliente(Cliente cli) {
        if (cli == null) {
            return false;
        }
        if (clienteDAO.existeDocumento(cli.getNroDocumento())) {
            return false;
        }
        return clienteDAO.registrar(cli);
    }

    public boolean actualizarCliente(Cliente cli) {
        if (cli == null || cli.getIdPersona() <= 0) {
            return false;
        }

        return clienteDAO.actualizar(cli);
    }

    public Cliente buscarPorDocumento(String nroDocumento) {
        if (nroDocumento == null || nroDocumento.trim().isEmpty()) {
            return null;
        }

        return clienteDAO.buscarPorDocumento(nroDocumento.trim());
    }

    public boolean existeDocumento(String nroDocumento) {
        if (nroDocumento == null || nroDocumento.trim().isEmpty()) {
            return false;
        }

        return clienteDAO.existeDocumento(nroDocumento.trim());
    }

    
    public List<Cliente> listarClientesActivos(){
        return clienteDAO.listarActivos();
    }

    public List<Cliente> listarTodosLosClientes(){
        return clienteDAO.listar();
    }
    
    public List<Cliente> listarClientes() {
        return clienteDAO.listarActivos();
    }
}