/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import java.awt.BorderLayout;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import util.Iconos;

/**
 *
 * @author UCF20429
 */
public class Principal extends JFrame {
    private JDesktopPane escritorio;
    // Barra de menú
    private JMenuBar barraMenu;
    
    // Menús
    private JMenu menuDashboard;
    private JMenu menuMantenimiento;
    private JMenu menuProcesos;
    private JMenu menuReportes;
    private JMenu menuArchivo;

    //Opciones Dashboard;
    private JMenuItem itemDashboard;
    // Opciones Archivo
    private JMenuItem itemCerrarSesion;
    private JMenuItem itemSalir;

    // Opciones Mantenimiento
    private JMenuItem itemEmpleado;
    private JMenuItem itemCliente;
    private JMenuItem itemProveedor;
    private JMenuItem itemCategoria;
    private JMenuItem itemProducto;
    private JMenuItem itemInventario;
    private JMenuItem itemUsuario;

    // Opciones Procesos
    private JMenuItem itemCompra;
    private JMenuItem itemVenta;
    private JMenuItem itemAsistencia;

    // Opciones Reportes
    private JMenuItem itemReporte;

    public Principal() {
        init();  
    }
    
    private void init() {
        setTitle("Sistema de Gestión de Minimarket");
        setSize(1200,700);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        escritorio = new JDesktopPane();
        add(escritorio, BorderLayout.CENTER);
        crearMenu();
        abrirDashboard();
    }
   
    private void abrirFormulario(JInternalFrame frm){
        escritorio.removeAll();
        escritorio.repaint();
        frm.setBorder(null);
        frm.setVisible(true);
        escritorio.add(frm);
        try{
            frm.setMaximum(true);
        }catch(Exception e){}
    }

    private void crearMenu() {
        barraMenu = new JMenuBar();
        menuDashboard = new JMenu("Dashboard"); 
        menuMantenimiento = new JMenu("Mantenimiento");
        menuProcesos = new JMenu("Procesos");
        menuReportes = new JMenu("Reportes");
        menuArchivo = new JMenu("Archivo");

        //icono dashboard
        itemDashboard = new JMenuItem("Inicio", Iconos.cargar("/imagenes/dashboard.png", 20, 20));
        // Mantenimiento iconos
        itemEmpleado = new JMenuItem("Empleado", Iconos.cargar("/imagenes/empleado.png", 20, 20));
        itemCliente = new JMenuItem("Cliente", Iconos.cargar("/imagenes/cliente.png", 20, 20));
        itemProveedor = new JMenuItem("Proveedor", Iconos.cargar("/imagenes/proveedor.png", 20, 20));
        itemCategoria = new JMenuItem("Categoría", Iconos.cargar("/imagenes/categoria.png", 20, 20));
        itemProducto = new JMenuItem("Producto", Iconos.cargar("/imagenes/producto.png", 20, 20));
        itemInventario = new JMenuItem("Inventario", Iconos.cargar("/imagenes/inventario.png", 20, 20));
        itemUsuario = new JMenuItem("Usuario", Iconos.cargar("/imagenes/usuario.png", 20, 20));

        // Procesos iconos
        itemCompra = new JMenuItem("Compra", Iconos.cargar("/imagenes/compra.png", 20, 20));
        itemVenta = new JMenuItem("Venta", Iconos.cargar("/imagenes/venta.png", 20, 20));
        itemAsistencia = new JMenuItem("Asistencia", Iconos.cargar("/imagenes/asistencia.png", 20, 20));
        itemReporte = new JMenuItem("Reportes", Iconos.cargar("/imagenes/reporte.png", 20, 20));
        itemCerrarSesion = new JMenuItem("Cerrar sesión", Iconos.cargar("/imagenes/cerrar_sesion.png", 20, 20));
        itemSalir = new JMenuItem("Salir", Iconos.cargar("/imagenes/salir.png", 20, 20));

        //dashboard
        menuDashboard.add(itemDashboard);
        //ARCHIVO
        menuArchivo.add(itemCerrarSesion);
        menuArchivo.addSeparator();
        menuArchivo.add(itemSalir);

        //MANTENIMIENTO
        menuMantenimiento.add(itemEmpleado);
        menuMantenimiento.add(itemCliente);
        menuMantenimiento.add(itemProveedor);
        menuMantenimiento.add(itemCategoria);
        menuMantenimiento.add(itemProducto);
        menuMantenimiento.add(itemInventario);
        menuMantenimiento.add(itemUsuario);

        //PROCESOS
        menuProcesos.add(itemCompra);
        menuProcesos.add(itemVenta);
        menuProcesos.add(itemAsistencia);

        //REPORTES
        menuReportes.add(itemReporte);

        //........
        barraMenu.add(menuDashboard);
        barraMenu.add(menuMantenimiento);
        barraMenu.add(menuProcesos);
        barraMenu.add(menuReportes);
        barraMenu.add(menuArchivo);
        setJMenuBar(barraMenu);
        eventos();
    }

    private void eventos() {
        itemSalir.addActionListener(e -> System.exit(0));
        itemCerrarSesion.addActionListener(e -> {
            Login login = new Login();
            login.setVisible(true);
            dispose();

        });

        itemEmpleado.addActionListener(e -> abrirEmpleado());
        itemCliente.addActionListener(e -> abrirCliente());
        itemProveedor.addActionListener(e -> abrirProveedor());
        itemCategoria.addActionListener(e -> abrirCategoria());
        itemProducto.addActionListener(e -> abrirProducto());
        itemInventario.addActionListener(e -> abrirInventario());
        itemUsuario.addActionListener(e -> abrirUsuario());
        itemCompra.addActionListener(e -> abrirCompra());
        itemVenta.addActionListener(e -> abrirVenta());
        itemAsistencia.addActionListener(e -> abrirAsistencia());
        itemReporte.addActionListener(e -> abrirReporte());
        
        itemDashboard.addActionListener(e -> abrirDashboard());
        
    }

    // MÉTODOS 
    private void abrirEmpleado() {
        abrirFormulario(new FrmEmpleado());
    }

    private void abrirCliente() {
        abrirFormulario(new FrmCliente());
    }

    private void abrirProveedor() {
        abrirFormulario(new FrmProveedor());
    }

    private void abrirCategoria() {
        abrirFormulario(new FrmCategoria());
    }

    private void abrirProducto() {
        abrirFormulario(new FrmProducto());
    }

    private void abrirInventario() {
        abrirFormulario(new FrmInventario());
    }

    private void abrirUsuario() {
        abrirFormulario(new FrmUsuario());
    }

    private void abrirCompra() {
        abrirFormulario(new FrmCompra());
    }

    private void abrirVenta() {
        abrirFormulario(new FrmVenta());
    }

    private void abrirAsistencia() {
        abrirFormulario(new FrmAsistencia());
    }

    private void abrirReporte() {
        abrirFormulario(new FrmReporte());
    }
    
    private void abrirDashboard() {
        abrirFormulario(new FrmDashboard());
    }
}
