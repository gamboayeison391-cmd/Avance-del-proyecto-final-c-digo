/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import dao.ProductoDAO;
import modelo.Producto;

import java.util.List;
/**
 *
 * @author USUARIO
 */
public class ControladorProducto {
    private ProductoDAO productoDAO;

    public ControladorProducto() {
        productoDAO = new ProductoDAO();
    }

    public boolean registrarProducto(Producto producto) {

        if (productoDAO.existeCodigo(producto.getCodigo())) {
            System.out.println("El código del producto ya existe.");
            return false;
        }

        return productoDAO.registrar(producto);
    }

    public boolean actualizarProducto(Producto producto) {
        return productoDAO.actualizar(producto);
    }

    public boolean inactivarProducto(int idProducto) {
        return productoDAO.desactivar(idProducto);
    }

    public Producto buscarPorCodigo(String codigo) {
        return productoDAO.buscarPorCodigo(codigo);
    }

    public boolean existeCodigo(String codigo) {
        return productoDAO.existeCodigo(codigo);
    }
    
    public List<Producto> listarProductos() {
        return productoDAO.listarActivos();
    }
    
    public List<Producto> listarProductosActivos() {
        return productoDAO.listarActivos();
    }

}
