package dao;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import modelo.Venta;
import modelo.Compra;
import modelo.Producto;
import modelo.DetalleVenta;

/** Consultas y totales hechos sobre colecciones en memoria. */
public class ReporteDAO {
    private boolean dentro(Date fecha, Date inicio, Date fin) {
        if (fecha == null) return false;
        java.time.ZoneId zona = java.time.ZoneId.systemDefault();
        java.time.LocalDate dia = fecha.toInstant().atZone(zona).toLocalDate();
        java.time.LocalDate desde = inicio == null ? null : inicio.toInstant().atZone(zona).toLocalDate();
        java.time.LocalDate hasta = fin == null ? null : fin.toInstant().atZone(zona).toLocalDate();
        return (desde == null || !dia.isBefore(desde)) && (hasta == null || !dia.isAfter(hasta));
    }
    public List<Venta> reporteVentas(Date inicio, Date fin) {
        return new VentaDAO().listar().stream().filter(v -> dentro(v.getFecha(), inicio, fin) &&
            !"ANULADA".equalsIgnoreCase(v.getEstado())).collect(Collectors.toList());
    }
    public List<Compra> reporteCompras(Date inicio, Date fin) {
        return new CompraDAO().listar().stream().filter(c -> dentro(c.getFecha(), inicio, fin) &&
            !"ANULADA".equalsIgnoreCase(c.getEstado())).collect(Collectors.toList());
    }
    public List<Producto> reporteInventario() { return new ProductoDAO().listar(); }
    public double totalVentas(Date inicio, Date fin) { return reporteVentas(inicio, fin).stream().mapToDouble(Venta::getTotal).sum(); }
    public double totalCompras(Date inicio, Date fin) { return reporteCompras(inicio, fin).stream().mapToDouble(Compra::getTotal).sum(); }
    public double gananciaVentas(Date inicio, Date fin) {
        return reporteVentas(inicio, fin).stream().flatMap(v -> v.getDetallesVenta().stream())
            .mapToDouble(d -> (d.getPrecioUnitario()-d.getProducto().getPrecioCompra())*d.getCantidad()).sum();
    }
}
