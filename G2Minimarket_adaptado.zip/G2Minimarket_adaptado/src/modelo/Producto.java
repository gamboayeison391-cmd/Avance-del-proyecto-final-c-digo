/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;

/**
 *
 * @author UCF20429
 */
public class Producto {

    private int idProducto;
    private String codigo;
    private String nombre;
    private String marca;
    private double precioCompra;
    private double precioVenta;
    private int stock;
    private int stockMinimo;
    private boolean estado;

    // Relación con Categoría
    private Categoria categoria;

    // Relación con DetalleCompra
    private ArrayList<DetalleCompra> detalleCompras;

    // Relación con DetalleVenta
    private ArrayList<DetalleVenta> detalleVentas;

    // Constructor vacío
    public Producto() {
        detalleCompras = new ArrayList<>();
        detalleVentas = new ArrayList<>();
    }

    // Constructor con parámetros
    public Producto(int idProducto,
                    String codigo,
                    String nombre,
                    String marca,
                    double precioCompra,
                    double precioVenta,
                    int stock,
                    int stockMinimo,
                    boolean estado,
                    Categoria categoria,
                    ArrayList<DetalleCompra> detalleCompras,
                    ArrayList<DetalleVenta> detalleVentas) {

        this.idProducto = idProducto;
        this.codigo = codigo;
        this.nombre = nombre;
        this.marca = marca;
        this.precioCompra = precioCompra;
        this.precioVenta = precioVenta;
        this.stock = stock;
        this.stockMinimo = stockMinimo;
        this.estado = estado;
        this.categoria = categoria;
        this.detalleCompras = detalleCompras;
        this.detalleVentas = detalleVentas;
    }

    // Getters y Setters

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public double getPrecioCompra() {
        return precioCompra;
    }

    public void setPrecioCompra(double precioCompra) {
        this.precioCompra = precioCompra;
    }

    public double getPrecioVenta() {
        return precioVenta;
    }

    public void setPrecioVenta(double precioVenta) {
        this.precioVenta = precioVenta;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public int getStockMinimo() {
        return stockMinimo;
    }

    public void setStockMinimo(int stockMinimo) {
        this.stockMinimo = stockMinimo;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public ArrayList<DetalleCompra> getDetalleCompras() {
        return detalleCompras;
    }

    public void setDetalleCompras(ArrayList<DetalleCompra> detalleCompras) {
        this.detalleCompras = detalleCompras;
    }

    public ArrayList<DetalleVenta> getDetalleVentas() {
        return detalleVentas;
    }

    public void setDetalleVentas(ArrayList<DetalleVenta> detalleVentas) {
        this.detalleVentas = detalleVentas;
    }
}
