/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import dao.CompraDAO;
import java.util.List;
import modelo.Compra;

/**
 *
 * @author USUARIO
 */
public class ControladorCompra {

    private CompraDAO compraDAO;

    public ControladorCompra() {
        compraDAO = new CompraDAO();
    }

    public boolean registrarCompra(Compra compra) {

        if (compra == null) {
            return false;
        }

        if (compra.getProveedor() == null) {
            return false;
        }

        if (compra.getEmpleado() == null) {
            return false;
        }

        if (compra.getDetallesCompra() == null
                || compra.getDetallesCompra().isEmpty()) {
            return false;
        }

        return compraDAO.registrar(compra);
    }

    public Compra buscarCompra(int idCompra) {

        if (idCompra <= 0) {
            return null;
        }

        return compraDAO.buscarPorId(idCompra);
    }

    public List<Compra> listarCompras() {
        return compraDAO.listar();
    }
}