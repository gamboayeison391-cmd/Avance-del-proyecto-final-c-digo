package dao;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.LinkedHashMap;
import java.util.Map;
import java.text.SimpleDateFormat;
import java.util.Date;
import modelo.Venta;
import modelo.DetalleVenta;

/** Resumen estadístico de los datos temporales del prototipo. */
public class DashboardDAO {
    private LocalDate dia(Date d) {
        return d.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }
    public double ventasDelDia() {
        LocalDate hoy = LocalDate.now();
        return new VentaDAO().listar().stream().filter(v -> v.getFecha() != null && dia(v.getFecha()).equals(hoy) &&
            !"ANULADA".equalsIgnoreCase(v.getEstado())).mapToDouble(Venta::getTotal).sum();
    }
    public double gananciaDelDia() {
        LocalDate hoy = LocalDate.now();
        return new VentaDAO().listar().stream().filter(v -> v.getFecha() != null && dia(v.getFecha()).equals(hoy) &&
            !"ANULADA".equalsIgnoreCase(v.getEstado())).flatMap(v -> v.getDetallesVenta().stream())
            .mapToDouble(d -> (d.getPrecioUnitario()-d.getProducto().getPrecioCompra())*d.getCantidad()).sum();
    }
    public int totalClientes() { return new ClienteDAO().listar().size(); }
    public int totalProductos() { return new ProductoDAO().listar().size(); }
    public int totalEmpleados() { return new EmpleadoDAO().listar().size(); }
    public int productosStockBajo() { return (int) new ProductoDAO().listar().stream().filter(p -> p.getStock() <= p.getStockMinimo()).count(); }
    public Map<String,Double> ventasUltimos7Dias() {
        Map<String,Double> resultado = new LinkedHashMap<>();
        LocalDate hoy = LocalDate.now();
        for (int i = 6; i >= 0; i--) {
            LocalDate fecha = hoy.minusDays(i);
            String etiqueta = String.format("%02d/%02d", fecha.getDayOfMonth(), fecha.getMonthValue());
            double total = new VentaDAO().listar().stream().filter(v -> v.getFecha() != null && dia(v.getFecha()).equals(fecha) &&
                !"ANULADA".equalsIgnoreCase(v.getEstado())).mapToDouble(Venta::getTotal).sum();
            resultado.put(etiqueta, total);
        }
        return resultado;
    }
}
