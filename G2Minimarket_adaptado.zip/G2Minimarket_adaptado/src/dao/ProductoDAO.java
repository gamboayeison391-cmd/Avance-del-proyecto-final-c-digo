/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexion.ConexionBD;
import modelo.Categoria;
import modelo.Producto;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author USUARIO
 */
public class ProductoDAO {

    public boolean registrar(Producto pro) {
        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "INSERT INTO Producto "
              + "(idCategoria, codigo, nombre, marca, precioCompra, precioVenta, "
              + "stock, stockMinimo, estado) "
              + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
            );

            cargarDatosProducto(ps, pro);
            int res = ps.executeUpdate();

            ps.close();
            ConexionBD.cerrar(cn);

            return res > 0;

        } catch (SQLException e) {
            System.out.println("Error registrar producto: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizar(Producto pro) {
        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "UPDATE Producto SET "
              + "idCategoria = ?, "
              + "codigo = ?, "
              + "nombre = ?, "
              + "marca = ?, "
              + "precioCompra = ?, "
              + "precioVenta = ?, "
              + "stock = ?, "
              + "stockMinimo = ?, "
              + "estado = ? "
              + "WHERE idProducto = ?"
            );

            cargarDatosProducto(ps, pro);
            ps.setInt(10, pro.getIdProducto());

            int res = ps.executeUpdate();

            ps.close();
            ConexionBD.cerrar(cn);

            return res > 0;

        } catch (SQLException e) {
            System.out.println("Error actualizar producto: " + e.getMessage());
            return false;
        }
    }

    public boolean desactivar(int idProducto) {
        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "UPDATE Producto SET estado = 0 WHERE idProducto = ?"
            );

            ps.setInt(1, idProducto);

            int res = ps.executeUpdate();

            ps.close();
            ConexionBD.cerrar(cn);

            return res > 0;

        } catch (SQLException e) {
            System.out.println("Error desactivar producto: " + e.getMessage());
            return false;
        }
    }

    
    public Producto buscarPorCodigo(String codigo) {
        Producto pro = null;

        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                consultaProducto()
              + "WHERE p.codigo = ?"
            );

            ps.setString(1, codigo);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                pro = convertirProducto(rs);
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error buscar producto: " + e.getMessage());
        }

        return pro;
    }

    public List<Producto> listar() {
        List<Producto> lista = new ArrayList<>();

        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                consultaProducto()
              + "ORDER BY p.idProducto DESC"
            );

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(convertirProducto(rs));
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error listar productos: " + e.getMessage());
        }

        return lista;
    }
    
    public List<Producto> listarActivos() {
        List<Producto> lista = new ArrayList<>();

        try {
            Connection cn = ConexionBD.conectar();
    
            PreparedStatement ps = cn.prepareStatement(
            consultaProducto()
              + "WHERE p.estado = 1 "
              + "ORDER BY p.idProducto DESC"
            );

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(convertirProducto(rs));
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error listar productos activos: " + e.getMessage());
        }

        return lista;
    }

    public boolean existeCodigo(String codigo) {
        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "SELECT COUNT(*) FROM Producto WHERE codigo = ?"
            );

            ps.setString(1, codigo);

            ResultSet rs = ps.executeQuery();

            boolean existe = false;

            if (rs.next()) {
                existe = rs.getInt(1) > 0;
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

            return existe;

        } catch (SQLException e) {
            System.out.println("Error verificar código producto: " + e.getMessage());
            return false;
        }
    }

    private void cargarDatosProducto(PreparedStatement ps, Producto pro) throws SQLException {
        ps.setInt(1, pro.getCategoria().getIdCategoria());
        ps.setString(2, pro.getCodigo());
        ps.setString(3, pro.getNombre());
        ps.setString(4, pro.getMarca());
        ps.setDouble(5, pro.getPrecioCompra());
        ps.setDouble(6, pro.getPrecioVenta());
        ps.setInt(7, pro.getStock());
        ps.setInt(8, pro.getStockMinimo());
        ps.setBoolean(9, pro.isEstado());
    }

    private Producto convertirProducto(ResultSet rs) throws SQLException {
        Categoria cat = new Categoria();

        cat.setIdCategoria(rs.getInt("idCategoria"));
        cat.setNombre(rs.getString("nombreCategoria"));
        cat.setDescripcion(rs.getString("descripcion"));
        cat.setEstado(rs.getBoolean("estadoCategoria"));

        Producto pro = new Producto();

        pro.setIdProducto(rs.getInt("idProducto"));
        pro.setCodigo(rs.getString("codigo"));
        pro.setNombre(rs.getString("nombre"));
        pro.setMarca(rs.getString("marca"));
        pro.setPrecioCompra(rs.getDouble("precioCompra"));
        pro.setPrecioVenta(rs.getDouble("precioVenta"));
        pro.setStock(rs.getInt("stock"));
        pro.setStockMinimo(rs.getInt("stockMinimo"));
        pro.setEstado(rs.getBoolean("estado"));
        pro.setCategoria(cat);

        return pro;
    }

    private String consultaProducto() {
        return "SELECT "
             + "p.idProducto, p.codigo, p.nombre, p.marca, "
             + "p.precioCompra, p.precioVenta, p.stock, p.stockMinimo, p.estado, "
             + "c.idCategoria, c.nombre AS nombreCategoria, "
             + "c.descripcion, c.estado AS estadoCategoria "
             + "FROM Producto p "
             + "INNER JOIN Categoria c ON p.idCategoria = c.idCategoria ";
    }
}