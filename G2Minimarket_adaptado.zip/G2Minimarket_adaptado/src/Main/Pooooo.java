/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Main;

import java.sql.Connection;
import conexion.ConexionBD;
import vista.Login;
import javax.swing.SwingUtilities;
//import conexion.ConexionBD;
//import java.sql.Connection;
/**
 *
 * @author UCF20429
 */
public class Pooooo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        SwingUtilities.invokeLater(() -> {
            Login login = new Login();
            login.setVisible(true);
        });
        
         
        ConexionBD conexion = new ConexionBD();
        Connection cn = conexion.conectar();
    }
}
