/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import dao.EmpleadoDAO;
import modelo.Empleado;

import java.util.List;
/**
 *
 * @author USUARIO
 */
public class ControladorEmpleado {
    private EmpleadoDAO empleadoDAO;

    public ControladorEmpleado() {
        empleadoDAO = new EmpleadoDAO();
    }

    public boolean registrarEmpleado(Empleado emp) {

        if (empleadoDAO.existeDocumento(emp.getNroDocumento())) {
            System.out.println("El documento ya está registrado");
            return false;
        }

        if (empleadoDAO.existeCodigo(emp.getCodigoEmpleado())) {
            System.out.println("El código de empleado ya existe");
            return false;
        }

        return empleadoDAO.registrar(emp);
    }

    public boolean actualizarEmpleado(Empleado emp) {
        return empleadoDAO.actualizar(emp);
    }

    public boolean inactivarEmpleado(int idPersona) {
        return empleadoDAO.desactivar(idPersona);
    }

    public Empleado buscarPorDocumento(String nroDocumento) {
        return empleadoDAO.buscarPorDocumento(nroDocumento);
    }

    public boolean existeDocumento(String nroDocumento) {
        return empleadoDAO.existeDocumento(nroDocumento);
    }

    public boolean existeCodigo(String codigoEmpleado) {
        return empleadoDAO.existeCodigo(codigoEmpleado);
    }
    
    public List<Empleado> listarEmpleadosActivos(){
        return empleadoDAO.listarActivos();
    }

    
    public List<Empleado> listarEmpleados() {
        return empleadoDAO.listarActivos();
    }
}
