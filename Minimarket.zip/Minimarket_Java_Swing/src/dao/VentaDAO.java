package dao;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import modelo.DetalleVenta;
import modelo.Inventario;
import modelo.Producto;
import modelo.Venta;

public class VentaDAO {

    private static final Almacen<Venta> ALMACEN = new Almacen<>(0);

    /** Registra la venta solo si hay stock suficiente; luego descuenta el stock. */
    public boolean registrar(Venta venta) {
        ProductoDAO productoDAO = new ProductoDAO();
        java.util.Map<Integer,Integer> cantidades = new java.util.HashMap<>();
        for (DetalleVenta d : venta.getDetallesVenta()) {
            if (d == null || d.getProducto() == null || d.getCantidad() <= 0) return false;
            int id = d.getProducto().getIdProducto();
            cantidades.put(id, cantidades.getOrDefault(id, 0) + d.getCantidad());
        }
        for (java.util.Map.Entry<Integer,Integer> e : cantidades.entrySet()) {
            Producto pro = productoDAO.buscarPorId(e.getKey());
            if (pro == null || pro.getStock() < e.getValue()) return false;
        }
        venta.calcularTotales();
        venta.setIdVenta(ALMACEN.siguienteId());
        venta.setEstado("ACTIVA");
        if (venta.getFecha() == null) {
            venta.setFecha(new Date());
        }
        if (venta.getHora() == null || venta.getHora().trim().isEmpty()) {
            venta.setHora(new SimpleDateFormat("HH:mm:ss").format(new Date()));
        }
        int idDetalle = 0;
        for (DetalleVenta d : venta.getDetallesVenta()) {
            d.calcularSubtotal();
            d.setIdDetalleVenta(++idDetalle);
            descontarStock(productoDAO.buscarPorId(d.getProducto().getIdProducto()), d.getCantidad());
        }
        ALMACEN.agregar(venta);
        return true;
    }

    private void descontarStock(Producto pro, int cantidad) {
        pro.setStock(pro.getStock() - cantidad);
        Inventario inv = new InventarioDAO().buscarPorProducto(pro.getIdProducto());
        if (inv != null) {
            inv.setStockActual(pro.getStock());
            inv.setFechaActualizacion(new Date());
        }
    }

    public boolean eliminar(int idVenta) {
        return anular(idVenta);
    }

    public boolean anular(int idVenta) {
        Venta venta = buscarPorId(idVenta);
        if (venta == null || "ANULADA".equalsIgnoreCase(venta.getEstado())) {
            return false;
        }
        for (DetalleVenta d : venta.getDetallesVenta()) {
            Producto pro = new ProductoDAO().buscarPorId(d.getProducto().getIdProducto());
            if (pro != null) {
                pro.setStock(pro.getStock() + d.getCantidad());
                Inventario inv = new InventarioDAO().buscarPorProducto(pro.getIdProducto());
                if (inv != null) {
                    inv.setStockActual(pro.getStock());
                    inv.setFechaActualizacion(new Date());
                }
            }
        }
        venta.setEstado("ANULADA");
        return true;
    }

    public Venta buscarPorId(int idVenta) {
        return ALMACEN.buscar(v -> v.getIdVenta() == idVenta).orElse(null);
    }

    public List<Venta> listar() {
        return ALMACEN.todos();
    }
}
