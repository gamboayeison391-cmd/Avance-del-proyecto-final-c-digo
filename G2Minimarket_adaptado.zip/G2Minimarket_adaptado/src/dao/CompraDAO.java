/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexion.ConexionBD;
import modelo.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author USUARIO
 */
public class CompraDAO {

    public boolean registrar(Compra compra) {
        Connection cn = null;

        try {
            cn = ConexionBD.conectar();
            cn.setAutoCommit(false);

            int idProveedor = obtenerIdProveedor(cn, compra.getProveedor().getIdPersona());
            int idEmpleado = obtenerIdEmpleado(cn, compra.getEmpleado().getIdPersona());

            PreparedStatement psCompra = cn.prepareStatement(
                "INSERT INTO Compra (idProveedor, idEmpleado, fecha, total, estado) "
              + "VALUES (?, ?, ?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS
            );

            psCompra.setInt(1, idProveedor);
            psCompra.setInt(2, idEmpleado);

            if (compra.getFecha() != null) {
                psCompra.setDate(3, new java.sql.Date(compra.getFecha().getTime()));
            } else {
                psCompra.setDate(3, new java.sql.Date(System.currentTimeMillis()));
            }

            compra.calcularTotal();
            psCompra.setDouble(4, compra.getTotal());
            psCompra.setString(5, "ACTIVA");

            int resCompra = psCompra.executeUpdate();

            if (resCompra == 0) {
                cn.rollback();
                return false;
            }

            ResultSet rs = psCompra.getGeneratedKeys();

            int idCompra = 0;

            if (rs.next()) {
                idCompra = rs.getInt(1);
            } else {
                cn.rollback();
                return false;
            }

            PreparedStatement psDetalle = cn.prepareStatement(
                "INSERT INTO DetalleCompra "
              + "(idCompra, idProducto, cantidad, precioCompra, subtotal) "
              + "VALUES (?, ?, ?, ?, ?)"
            );

            PreparedStatement psStock = cn.prepareStatement(
                "UPDATE Producto SET stock = stock + ? WHERE idProducto = ?"
            );

            for (DetalleCompra detalle : compra.getDetallesCompra()) {
                detalle.calcularSubtotal();

                psDetalle.setInt(1, idCompra);
                psDetalle.setInt(2, detalle.getProducto().getIdProducto());
                psDetalle.setInt(3, detalle.getCantidad());
                psDetalle.setDouble(4, detalle.getPrecioCompra());
                psDetalle.setDouble(5, detalle.getSubtotal());
                psDetalle.executeUpdate();

                psStock.setInt(1, detalle.getCantidad());
                psStock.setInt(2, detalle.getProducto().getIdProducto());
                psStock.executeUpdate();
            }

            rs.close();
            psCompra.close();
            psDetalle.close();
            psStock.close();

            cn.commit();
            return true;

        } catch (SQLException e) {
            hacerRollback(cn);
            System.out.println("Error registrar compra: " + e.getMessage());
            return false;

        } finally {
            ConexionBD.cerrar(cn);
        }
    }

    public Compra buscarPorId(int idCompra) {
        Compra compra = null;

        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement psCompra = cn.prepareStatement(
                consultaCompra()
              + "WHERE c.idCompra = ?"
            );

            psCompra.setInt(1, idCompra);

            ResultSet rsCompra = psCompra.executeQuery();

            if (rsCompra.next()) {
                compra = convertirCompra(rsCompra);
                cargarDetallesCompra(cn, compra);
            }

            rsCompra.close();
            psCompra.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error buscar compra: " + e.getMessage());
        }

        return compra;
    }

    public List<Compra> listar() {
        List<Compra> lista = new ArrayList<>();

        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                consultaCompra()
              + "ORDER BY c.idCompra DESC"
            );

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(convertirCompra(rs));
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error listar compras: " + e.getMessage());
        }

        return lista;
    }

    private void cargarDetallesCompra(Connection cn, Compra compra) throws SQLException {
        PreparedStatement ps = cn.prepareStatement(
            "SELECT "
          + "dc.idDetalleCompra, dc.cantidad, dc.precioCompra, dc.subtotal, "
          + "p.idProducto, p.codigo, p.nombre, p.marca, "
          + "p.precioCompra AS precioCompraProducto, "
          + "p.precioVenta, p.stock, p.stockMinimo, p.estado, "
          + "cat.idCategoria, cat.nombre AS nombreCategoria "
          + "FROM DetalleCompra dc "
          + "INNER JOIN Producto p ON dc.idProducto = p.idProducto "
          + "INNER JOIN Categoria cat ON p.idCategoria = cat.idCategoria "
          + "WHERE dc.idCompra = ?"
        );

        ps.setInt(1, compra.getIdCompra());

        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Categoria categoria = new Categoria();
            categoria.setIdCategoria(rs.getInt("idCategoria"));
            categoria.setNombre(rs.getString("nombreCategoria"));

            Producto producto = new Producto();
            producto.setIdProducto(rs.getInt("idProducto"));
            producto.setCodigo(rs.getString("codigo"));
            producto.setNombre(rs.getString("nombre"));
            producto.setMarca(rs.getString("marca"));
            producto.setPrecioCompra(rs.getDouble("precioCompraProducto"));
            producto.setPrecioVenta(rs.getDouble("precioVenta"));
            producto.setStock(rs.getInt("stock"));
            producto.setStockMinimo(rs.getInt("stockMinimo"));
            producto.setEstado(rs.getBoolean("estado"));
            producto.setCategoria(categoria);

            DetalleCompra detalle = new DetalleCompra();
            detalle.setIdDetalleCompra(rs.getInt("idDetalleCompra"));
            detalle.setCantidad(rs.getInt("cantidad"));
            detalle.setPrecioCompra(rs.getDouble("precioCompra"));
            detalle.setProducto(producto);

            compra.getDetallesCompra().add(detalle);
        }

        rs.close();
        ps.close();
    }

    private void restaurarStockAntesEliminar(Connection cn, int idCompra) throws SQLException {
        PreparedStatement ps = cn.prepareStatement(
            "SELECT idProducto, cantidad FROM DetalleCompra WHERE idCompra = ?"
        );

        ps.setInt(1, idCompra);

        ResultSet rs = ps.executeQuery();

        PreparedStatement psStock = cn.prepareStatement(
            "UPDATE Producto SET stock = stock - ? WHERE idProducto = ?"
        );

        while (rs.next()) {
            psStock.setInt(1, rs.getInt("cantidad"));
            psStock.setInt(2, rs.getInt("idProducto"));
            psStock.executeUpdate();
        }

        rs.close();
        ps.close();
        psStock.close();
    }

    private Compra convertirCompra(ResultSet rs) throws SQLException {
        Proveedor proveedor = new Proveedor();
        proveedor.setIdPersona(rs.getInt("idPersonaProveedor"));
        proveedor.setNombre(rs.getString("nombreProveedor"));
        proveedor.setRuc(rs.getString("ruc"));
        proveedor.setRazonSocial(rs.getString("razonSocial"));

        Empleado empleado = new Empleado();
        empleado.setIdPersona(rs.getInt("idPersonaEmpleado"));
        empleado.setNombre(rs.getString("nombreEmpleado"));
        empleado.setCodigoEmpleado(rs.getString("codigoEmpleado"));

        Compra compra = new Compra();
        compra.setIdCompra(rs.getInt("idCompra"));
        compra.setFecha(rs.getDate("fecha"));
        compra.setTotal(rs.getDouble("total"));
        compra.setProveedor(proveedor);
        compra.setEmpleado(empleado);
        compra.setEstado(rs.getString("estado"));

        return compra;
    }

    private String consultaCompra() {
        return "SELECT "
             + "c.idCompra, c.fecha, c.total, c.estado, "
             + "pProv.idPersona AS idPersonaProveedor, "
             + "pProv.nombre AS nombreProveedor, "
             + "pr.ruc, pr.razonSocial, "
             + "pEmp.idPersona AS idPersonaEmpleado, "
             + "pEmp.nombre AS nombreEmpleado, "
             + "e.codigoEmpleado "
             + "FROM Compra c "
             + "INNER JOIN Proveedor pr ON c.idProveedor = pr.idProveedor "
             + "INNER JOIN Persona pProv ON pr.idPersona = pProv.idPersona "
             + "INNER JOIN Empleado e ON c.idEmpleado = e.idEmpleado "
             + "INNER JOIN Persona pEmp ON e.idPersona = pEmp.idPersona ";
    }

    private int obtenerIdProveedor(Connection cn, int idPersona) throws SQLException {
        PreparedStatement ps = cn.prepareStatement(
            "SELECT idProveedor FROM Proveedor WHERE idPersona = ?"
        );

        ps.setInt(1, idPersona);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            int idProveedor = rs.getInt("idProveedor");
            rs.close();
            ps.close();
            return idProveedor;
        }

        rs.close();
        ps.close();

        throw new SQLException("No se encontró el proveedor.");
    }

    private int obtenerIdEmpleado(Connection cn, int idPersona) throws SQLException {
        PreparedStatement ps = cn.prepareStatement(
            "SELECT idEmpleado FROM Empleado WHERE idPersona = ?"
        );

        ps.setInt(1, idPersona);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            int idEmpleado = rs.getInt("idEmpleado");
            rs.close();
            ps.close();
            return idEmpleado;
        }

        rs.close();
        ps.close();

        throw new SQLException("No se encontró el empleado.");
    }

    private void hacerRollback(Connection cn) {
        try {
            if (cn != null) {
                cn.rollback();
            }
        } catch (SQLException e) {
            System.out.println("Error rollback compra: " + e.getMessage());
        }
    }
}
