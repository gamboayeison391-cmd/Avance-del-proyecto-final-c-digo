/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import dao.UsuarioDAO;
import java.util.List;
import modelo.Usuario;

/**
 *
 * @author USUARIO
 */
public class ControladorUsuario {
    private UsuarioDAO usuarioDAO;
    public ControladorUsuario() {
        usuarioDAO = new UsuarioDAO();
    }

    public boolean registrarUsuario(Usuario usuario) {
        if (usuario == null || usuario.getEmpleado() == null) {
            return false;
        }

        if (usuarioDAO.existeUsuario(usuario.getNombreUsuario())) {
            return false;
        }

        if (usuarioDAO.existeEmpleadoUsuario(usuario.getEmpleado().getIdPersona())) {
            return false;
        }

        return usuarioDAO.registrar(usuario);
    }

    public boolean actualizarUsuario(Usuario usuario) {
        if (usuario == null || usuario.getIdUsuario() <= 0 || usuario.getEmpleado() == null) {
            return false;
        }

        return usuarioDAO.actualizar(usuario);
    }

    public boolean inactivarUsuario(int idUsuario) {

        if (idUsuario <= 0) {
            return false;
        }

        return usuarioDAO.desactivar(idUsuario);
    }

    public Usuario buscarPorUsuario(String nombreUsuario) {

        if (nombreUsuario == null || nombreUsuario.trim().isEmpty()) {
            return null;
        }

        return usuarioDAO.buscarPorUsuario(nombreUsuario.trim());
    }

    public List<Usuario> listarUsuarios() {
        return usuarioDAO.listar();
    }

    public boolean validarLogin(String usuario, String contrasena) {

        if (usuario == null || usuario.trim().isEmpty()) {
            return false;
        }

        if (contrasena == null || contrasena.trim().isEmpty()) {
            return false;
        }

        return usuarioDAO.validarLogin(usuario.trim(), contrasena.trim());
    }

    public boolean existeUsuario(String nombreUsuario) {

        if (nombreUsuario == null || nombreUsuario.trim().isEmpty()) {
            return false;
        }

        return usuarioDAO.existeUsuario(nombreUsuario.trim());
    }

    public boolean existeEmpleadoUsuario(int idPersona) {

        if (idPersona <= 0) {
            return false;
        }
        return usuarioDAO.existeEmpleadoUsuario(idPersona);
    }
    
    public List<Usuario> listarUsuariosActivos(){
        return usuarioDAO.listarActivos();
    }

}