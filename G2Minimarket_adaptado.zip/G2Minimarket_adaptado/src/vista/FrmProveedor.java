/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import util.Validaciones;

import controlador.ControladorProveedor;
import java.awt.Color;
import java.awt.Font;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import modelo.Proveedor;
import util.FormularioUtil;
import util.Iconos;
import util.Mensajes;

/**
 *
 * @author UCF20429
 */
public class FrmProveedor extends JInternalFrame {

    private ControladorProveedor controlador = new ControladorProveedor();
    private SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");

    private JLabel lblTitulo, lblId, lblTipoDoc, lblDocumento;
    private JLabel lblNombre, lblApPaterno, lblApMaterno;
    private JLabel lblFecha, lblSexo, lblTelefono, lblCorreo, lblDireccion;
    private JLabel lblRuc, lblRazonSocial, lblLista;

    private JTextField txtId, txtDocumento, txtNombre, txtApPaterno, txtApMaterno;
    private JTextField txtFechaNacimiento, txtTelefono, txtCorreo, txtDireccion;
    private JTextField txtRuc, txtRazonSocial;

    private JComboBox<String> cboTipoDocumento, cboSexo;

    private JButton btnRegistrar, btnActualizar, btnEliminar, btnBuscar, btnListar, btnLimpiar;

    
    private JTable tablaProveedor;
    private DefaultTableModel modeloTabla;
    private JScrollPane scroll;

    public FrmProveedor() {
        iniciarComponentes();
        listar();
    }

    private void iniciarComponentes() {

        setTitle("Gestión de Proveedores");
        setSize(1200, 700);
        setClosable(true);
        setIconifiable(false);
        setMaximizable(false);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        lblTitulo = new JLabel("GESTIÓN DE PROVEEDORES");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBounds(350, 20, 500, 35);

        lblId = new JLabel("ID:");
        lblId.setBounds(70, 80, 120, 25);
        txtId = new JTextField();
        txtId.setBounds(180, 80, 120, 28);
        txtId.setEditable(false);
        txtId.setBackground(Color.WHITE);

        lblTipoDoc = new JLabel("Tipo Doc:");
        lblTipoDoc.setBounds(340, 80, 100, 25);
        cboTipoDocumento = new JComboBox<>();
        cboTipoDocumento.addItem("DNI");
        cboTipoDocumento.addItem("Carnet");
        cboTipoDocumento.addItem("Pasaporte");
        cboTipoDocumento.setBounds(430, 80, 150, 28);

        lblDocumento = new JLabel("Documento:");
        lblDocumento.setBounds(640, 80, 120, 25);
        txtDocumento = new JTextField();
        txtDocumento.setBounds(760, 80, 200, 28);

        lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(70, 125, 120, 25);
        txtNombre = new JTextField();
        txtNombre.setBounds(180, 125, 200, 28);

        lblApPaterno = new JLabel("Ap. Paterno:");
        lblApPaterno.setBounds(420, 125, 120, 25);
        txtApPaterno = new JTextField();
        txtApPaterno.setBounds(540, 125, 200, 28);

        lblApMaterno = new JLabel("Ap. Materno:");
        lblApMaterno.setBounds(780, 125, 120, 25);
        txtApMaterno = new JTextField();
        txtApMaterno.setBounds(900, 125, 200, 28);

        lblFecha = new JLabel("Fecha Nac:");
        lblFecha.setBounds(70, 170, 120, 25);
        txtFechaNacimiento = new JTextField();
        txtFechaNacimiento.setBounds(180, 170, 200, 28);
        txtFechaNacimiento.setToolTipText("Formato: dd/MM/yyyy");

        lblSexo = new JLabel("Sexo:");
        lblSexo.setBounds(420, 170, 120, 25);
        cboSexo = new JComboBox<>();
        cboSexo.addItem("Masculino");
        cboSexo.addItem("Femenino");
        cboSexo.setBounds(540, 170, 200, 28);

        lblTelefono = new JLabel("Teléfono:");
        lblTelefono.setBounds(780, 170, 120, 25);
        txtTelefono = new JTextField();
        txtTelefono.setBounds(900, 170, 200, 28);

        lblCorreo = new JLabel("Correo:");
        lblCorreo.setBounds(70, 215, 120, 25);
        txtCorreo = new JTextField();
        txtCorreo.setBounds(180, 215, 300, 28);

        lblDireccion = new JLabel("Dirección:");
        lblDireccion.setBounds(520, 215, 120, 25);
        txtDireccion = new JTextField();
        txtDireccion.setBounds(640, 215, 460, 28);

        lblRuc = new JLabel("RUC:");
        lblRuc.setBounds(70, 260, 120, 25);
        txtRuc = new JTextField();
        txtRuc.setBounds(180, 260, 200, 28);

        lblRazonSocial = new JLabel("Razón Social:");
        lblRazonSocial.setBounds(420, 260, 120, 25);
        txtRazonSocial = new JTextField();
        txtRazonSocial.setBounds(540, 260, 300, 28);

        btnRegistrar = new JButton("Registrar");
        btnRegistrar.setBounds(170, 320, 125, 35);

        btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(310, 320, 125, 35);

        btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(450, 320, 125, 35);

        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(590, 320, 125, 35);

        //btnListar = new JButton("Listar");
        //btnListar.setBounds(730, 320, 125, 35);

        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(730, 320, 125, 35);
        
        
        //check

        btnRegistrar.setIcon(Iconos.cargar("/imagenes/registrar.png", 20, 20));
        btnActualizar.setIcon(Iconos.cargar("/imagenes/actualizar.png", 20, 20));
        btnEliminar.setIcon(Iconos.cargar("/imagenes/eliminar.png", 20, 20));
        btnBuscar.setIcon(Iconos.cargar("/imagenes/buscar.png", 20, 20));
        //btnListar.setIcon(Iconos.cargar("/imagenes/listar.png", 20, 20));
        btnLimpiar.setIcon(Iconos.cargar("/imagenes/limpiar.png", 20, 20));

        lblLista = new JLabel("LISTADO DE PROVEEDORES");
        lblLista.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblLista.setBounds(90, 390, 300, 25);

        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("ID");
        modeloTabla.addColumn("Documento");
        modeloTabla.addColumn("Nombre Completo");
        modeloTabla.addColumn("RUC");
        modeloTabla.addColumn("Razón Social");
        modeloTabla.addColumn("Teléfono");
        modeloTabla.addColumn("Estado");

        tablaProveedor = new JTable(modeloTabla);
        tablaProveedor.setRowHeight(25);
        tablaProveedor.getTableHeader().setReorderingAllowed(false);
        tablaProveedor.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaProveedor.setAutoCreateRowSorter(true);
        tablaProveedor.setFillsViewportHeight(true);
        tablaProveedor.setGridColor(new Color(220, 220, 220));
        tablaProveedor.setShowGrid(true);
        tablaProveedor.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));

        scroll = new JScrollPane(tablaProveedor);
        scroll.setBounds(90, 420, 980, 180);

        btnRegistrar.addActionListener(e -> registrar());
        btnActualizar.addActionListener(e -> actualizar());
        btnEliminar.addActionListener(e -> inactivar());
        btnBuscar.addActionListener(e -> buscar());
        //btnListar.addActionListener(e -> listar());
        btnLimpiar.addActionListener(e -> limpiar());

        panel.add(lblTitulo);
        panel.add(lblId);
        panel.add(txtId);
        panel.add(lblTipoDoc);
        panel.add(cboTipoDocumento);
        panel.add(lblDocumento);
        panel.add(txtDocumento);
        panel.add(lblNombre);
        panel.add(txtNombre);
        panel.add(lblApPaterno);
        panel.add(txtApPaterno);
        panel.add(lblApMaterno);
        panel.add(txtApMaterno);
        panel.add(lblFecha);
        panel.add(txtFechaNacimiento);
        panel.add(lblSexo);
        panel.add(cboSexo);
        panel.add(lblTelefono);
        panel.add(txtTelefono);
        panel.add(lblCorreo);
        panel.add(txtCorreo);
        panel.add(lblDireccion);
        panel.add(txtDireccion);
        panel.add(lblRuc);
        panel.add(txtRuc);
        panel.add(lblRazonSocial);
        panel.add(txtRazonSocial);

        panel.add(btnRegistrar);
        panel.add(btnActualizar);
        panel.add(btnEliminar);
        panel.add(btnBuscar);
        //panel.add(btnListar);
        panel.add(btnLimpiar);

        panel.add(lblLista);
        panel.add(scroll);

        add(panel);
    }

    private Proveedor leerDatos() throws Exception {
        Proveedor pro = new Proveedor();

        pro.setTipoDocumento(cboTipoDocumento.getSelectedItem().toString());
        pro.setNroDocumento(txtDocumento.getText().trim());
        pro.setNombre(txtNombre.getText().trim());
        pro.setApPaterno(txtApPaterno.getText().trim());
        pro.setApMaterno(txtApMaterno.getText().trim());

        if (!txtFechaNacimiento.getText().trim().isEmpty()) {
            pro.setFechaNacimiento(formato.parse(txtFechaNacimiento.getText().trim()));
        }

        pro.setSexo(cboSexo.getSelectedItem().toString());
        pro.setTelefono(txtTelefono.getText().trim());
        pro.setCorreo(txtCorreo.getText().trim());
        pro.setDireccion(txtDireccion.getText().trim());
        pro.setEstado(true);

        pro.setRuc(txtRuc.getText().trim());
        pro.setRazonSocial(txtRazonSocial.getText().trim());

        return pro;
    }

    private void registrar() {
        try {
            if (!validarCampos()) {
                return;
            }

            Proveedor pro = leerDatos();

            if (controlador.existeDocumento(pro.getNroDocumento())) {
                Mensajes.advertencia(this, "Ya existe un proveedor con ese documento.");
                txtDocumento.requestFocus();
                return;
            }

            if (controlador.existeRuc(pro.getRuc())) {
                Mensajes.advertencia(this, "Ya existe un proveedor registrado con ese RUC.");
                txtRuc.requestFocus();
                return;
            }

            if (controlador.registrarProveedor(pro)) {
                Mensajes.exito(this, "Proveedor registrado correctamente.");
                listar();
                limpiar();
            } else {
                Mensajes.error(this, "No se pudo registrar el proveedor.");
            }

        } catch (Exception e) {
            Mensajes.error(this, "Ocurrió un error al registrar el proveedor.");
        }
    }

    private void actualizar() {
        try {
            if (txtId.getText().trim().isEmpty()) {
                Mensajes.advertencia(this, "Primero busque un proveedor para actualizar.");
                txtDocumento.requestFocus();
                return;
            }
            
            if (!validarCampos()) {
                return;
            }

            Proveedor pro = leerDatos();
            pro.setIdPersona(Integer.parseInt(txtId.getText().trim()));

            if (controlador.actualizarProveedor(pro)) {
                Mensajes.exito(this, "Proveedor actualizado correctamente.");
                listar();
                limpiar();
            } else {
                Mensajes.error(this, "No se pudo actualizar el proveedor.");
            }

        } catch (Exception e) {
            Mensajes.error(this, "Ocurrió un error al actualizar el proveedor.");
        }
    }

    private boolean validarCampos() {
        if (Validaciones.estaVacio(txtDocumento.getText())) {
            Mensajes.advertencia(this, "Ingrese el número de documento.");
            txtDocumento.requestFocus();
            return false;
        }

        if (cboTipoDocumento.getSelectedItem().toString().equals("DNI")
                && !Validaciones.dniValido(txtDocumento.getText().trim())) {
            Mensajes.advertencia(this, "El DNI debe tener exactamente 8 dígitos.");
            txtDocumento.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtNombre.getText())) {
            Mensajes.advertencia(this, "Ingrese el nombre del proveedor.");
            txtNombre.requestFocus();
            return false;
        }

        if (!Validaciones.soloLetras(txtNombre.getText().trim())) {
            Mensajes.advertencia(this, "El nombre solo debe contener letras.");
            txtNombre.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtApPaterno.getText())) {
            Mensajes.advertencia(this, "Ingrese el apellido paterno.");
            txtApPaterno.requestFocus();
            return false;
        }

        if (!Validaciones.soloLetras(txtApPaterno.getText().trim())) {
            Mensajes.advertencia(this, "El apellido paterno solo debe contener letras.");
            txtApPaterno.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtApMaterno.getText())) {
            Mensajes.advertencia(this, "Ingrese el apellido materno.");
            txtApMaterno.requestFocus();
            return false;
        }

        if (!Validaciones.soloLetras(txtApMaterno.getText().trim())) {
            Mensajes.advertencia(this, "El apellido materno solo debe contener letras.");
            txtApMaterno.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtFechaNacimiento.getText())) {
            Mensajes.advertencia(this, "Ingrese la fecha de nacimiento.");
            txtFechaNacimiento.requestFocus();
            return false;
        }

        if (!Validaciones.fechaValida(txtFechaNacimiento.getText().trim())) {
            Mensajes.advertencia(this, "La fecha de nacimiento debe tener formato dd/MM/yyyy.");
            txtFechaNacimiento.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtTelefono.getText())) {
            Mensajes.advertencia(this, "Ingrese el teléfono.");
            txtTelefono.requestFocus();
            return false;
        }

        if (!Validaciones.telefonoValido(txtTelefono.getText().trim())) {
            Mensajes.advertencia(this, "El teléfono debe tener exactamente 9 dígitos.");
            txtTelefono.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtCorreo.getText())) {
            Mensajes.advertencia(this, "Ingrese el correo.");
            txtCorreo.requestFocus();
            return false;
        }

        if (!Validaciones.correoValido(txtCorreo.getText().trim())) {
            Mensajes.advertencia(this, "Ingrese un correo válido. Ejemplo: proveedor@empresa.com");
            txtCorreo.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtDireccion.getText())) {
            Mensajes.advertencia(this, "Ingrese la dirección.");
            txtDireccion.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtRuc.getText())) {
            Mensajes.advertencia(this, "Ingrese el RUC.");
            txtRuc.requestFocus();
            return false;
        }

        if (!Validaciones.rucValido(txtRuc.getText().trim())) {
            Mensajes.advertencia(this, "El RUC debe tener exactamente 11 dígitos.");
            txtRuc.requestFocus();
            return false;
        }

        if (Validaciones.estaVacio(txtRazonSocial.getText())) {
            Mensajes.advertencia(this, "Ingrese la razón social.");
            txtRazonSocial.requestFocus();
            return false;
        }

        return true;
    }

    private void inactivar() {
        if (txtId.getText().trim().isEmpty()) {
            Mensajes.advertencia(this, "Primero busque el proveedor que desea inactivar.");
            return;
        }

        if (!Mensajes.confirmar(this, "¿Está seguro de inactivar este proveedor?")) {
            return;
        }

        int idPersona = Integer.parseInt(txtId.getText().trim());

        if (controlador.inactivarProveedor(idPersona)) {
            Mensajes.exito(this, "Proveedor inactivado correctamente.");
            listar();
            limpiar();
        } else {
            Mensajes.error(this,
                    "No se pudo inactivar el proveedor.");
        }
    }
    
    private void buscar() {
        String documento = txtDocumento.getText().trim();

        if (documento.isEmpty()) {
            Mensajes.advertencia(this, "Ingrese el DNI del proveedor para buscar.");
            txtDocumento.requestFocus();
            return;
        }

        Proveedor pro = controlador.buscarPorDocumento(documento);

        if (pro != null) {
            txtId.setText(String.valueOf(pro.getIdPersona()));
            cboTipoDocumento.setSelectedItem(pro.getTipoDocumento());
            txtDocumento.setText(pro.getNroDocumento());
            txtNombre.setText(pro.getNombre());
            txtApPaterno.setText(pro.getApPaterno());
            txtApMaterno.setText(pro.getApMaterno());

            if (pro.getFechaNacimiento() != null) {
                txtFechaNacimiento.setText(formato.format(pro.getFechaNacimiento()));
            }

            cboSexo.setSelectedItem(pro.getSexo());
            txtTelefono.setText(pro.getTelefono());
            txtCorreo.setText(pro.getCorreo());
            txtDireccion.setText(pro.getDireccion());
            txtRuc.setText(pro.getRuc());
            txtRazonSocial.setText(pro.getRazonSocial());

            txtDocumento.setEditable(false);
            txtRuc.setEditable(false);

            btnRegistrar.setEnabled(false);
            btnActualizar.setEnabled(true);
            btnEliminar.setEnabled(true);


            Mensajes.exito(this, "Proveedor encontrado correctamente.");

        } else {
            Mensajes.error(this, "No existe un proveedor con el DNI ingresado.");
        }
    }

    private void listar() {
        modeloTabla.setRowCount(0);

        List<Proveedor> lista = controlador.listarProveedoresActivos();
        
        for (Proveedor pro : lista) {
            modeloTabla.addRow(new Object[]{
                pro.getIdPersona(),
                pro.getNroDocumento(),
                pro.getNombre() + " " + pro.getApPaterno() + " " + pro.getApMaterno(),
                pro.getRuc(),
                pro.getRazonSocial(),
                pro.getTelefono(),
                pro.isEstado() ? "Activo" : "Inactivo"
            });
        }
    }
    
    private void limpiar() {
        txtId.setText("");
        txtDocumento.setText("");
        txtNombre.setText("");
        txtApPaterno.setText("");
        txtApMaterno.setText("");
        txtFechaNacimiento.setText("");
        txtTelefono.setText("");
        txtCorreo.setText("");
        txtDireccion.setText("");
        txtRuc.setText("");
        txtRazonSocial.setText("");

        cboTipoDocumento.setSelectedIndex(0);
        cboSexo.setSelectedIndex(0);

        txtDocumento.setEditable(true);
        txtRuc.setEditable(true);

        btnRegistrar.setEnabled(true);
        btnActualizar.setEnabled(false);
        btnEliminar.setEnabled(false);

        txtDocumento.requestFocus();
    }
}
