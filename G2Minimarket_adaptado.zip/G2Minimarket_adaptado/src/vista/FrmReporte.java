/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import controlador.ControladorReporte;
import java.awt.Color;
import java.awt.Font;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import modelo.Compra;
import modelo.Producto;
import modelo.Venta;
import util.FormularioUtil;
import util.Mensajes;
import util.Validaciones;

/**
 *
 * @author UCF20429
 */
public class FrmReporte extends JInternalFrame {

    private ControladorReporte controlador = new ControladorReporte();

    private JLabel lblTitulo, lblTipoReporte, lblFechaInicio, lblFechaFin;
    private JLabel lblTotal, lblCantidad, lblTabla ,lblGanancia;

    private JTextField txtFechaInicio, txtFechaFin, txtTotal, txtCantidad, txtGanancia;
    private JComboBox<String> cboTipoReporte;

    private JButton btnGenerar, btnExportar, btnLimpiar;

    private JTable tablaReporte;
    private DefaultTableModel modeloTabla;
    private JScrollPane scrollTabla;

    private SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");

    public FrmReporte() {
        iniciarComponentes();
        actualizarFormulario();
    }

    private void iniciarComponentes() {

        setTitle("Gestión de Reportes");
        setSize(1200, 700);
        setClosable(true);
        setIconifiable(false);
        setMaximizable(false);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        lblTitulo = new JLabel("GESTIÓN DE REPORTES");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBounds(350, 20, 500, 35);

        lblTipoReporte = new JLabel("Tipo Reporte:");
        lblTipoReporte.setBounds(120, 90, 120, 25);

        cboTipoReporte = new JComboBox<>();
        cboTipoReporte.addItem("Seleccione");
        cboTipoReporte.addItem("Ventas");
        cboTipoReporte.addItem("Compras");
        cboTipoReporte.addItem("Inventario");
        cboTipoReporte.setBounds(240, 90, 200, 25);

        lblFechaInicio = new JLabel("Fecha Inicio:");
        lblFechaInicio.setBounds(480, 90, 120, 25);
        txtFechaInicio = new JTextField();
        txtFechaInicio.setBounds(600, 90, 170, 25);
        txtFechaInicio.setToolTipText("Formato: dd/MM/yyyy");

        lblFechaFin = new JLabel("Fecha Fin:");
        lblFechaFin.setBounds(800, 90, 100, 25);
        txtFechaFin = new JTextField();
        txtFechaFin.setBounds(900, 90, 170, 25);
        txtFechaFin.setToolTipText("Formato: dd/MM/yyyy");
        
        lblGanancia = new JLabel("Ganancia:");
        lblGanancia.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblGanancia.setBounds(280, 210, 80, 25);
        txtGanancia = new JTextField();
        txtGanancia.setBounds(360, 210, 120, 25);
        FormularioUtil.soloLectura(txtGanancia);

        btnGenerar = new JButton("Generar");
        btnGenerar.setBounds(360, 150, 120, 32);

        btnExportar = new JButton("Exportar PDF");
        btnExportar.setBounds(500, 150, 140, 32);

        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(660, 150, 120, 32);

        FormularioUtil.configurarBoton(btnGenerar);
        FormularioUtil.configurarBoton(btnExportar);
        FormularioUtil.configurarBoton(btnLimpiar);

        lblTabla = new JLabel("RESULTADO DEL REPORTE");
        lblTabla.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTabla.setBounds(120, 245, 250, 25);

        modeloTabla = new DefaultTableModel();
        tablaReporte = new JTable(modeloTabla);
        FormularioUtil.configurarTabla(tablaReporte);

        scrollTabla = new JScrollPane(tablaReporte);
        scrollTabla.setBounds(120, 275, 950, 320);

        lblTotal = new JLabel("Total:");
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblTotal.setBounds(520, 210, 50, 25);
        txtTotal = new JTextField();
        txtTotal.setBounds(570, 210, 120, 25);
        FormularioUtil.soloLectura(txtTotal);

        lblCantidad = new JLabel("Registros:");
        lblCantidad.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblCantidad.setBounds(730, 210, 80, 25);
        txtCantidad = new JTextField();
        txtCantidad.setBounds(810, 210, 80, 25);
        FormularioUtil.soloLectura(txtCantidad);

        btnGenerar.addActionListener(e -> generar());
        btnExportar.addActionListener(e -> exportar());
        btnLimpiar.addActionListener(e -> limpiar());
        cboTipoReporte.addActionListener(e -> actualizarFormulario());

        panel.add(lblTitulo);
        panel.add(lblTipoReporte);
        panel.add(cboTipoReporte);
        panel.add(lblFechaInicio);
        panel.add(txtFechaInicio);
        panel.add(lblFechaFin);
        panel.add(txtFechaFin);

        panel.add(btnGenerar);
        panel.add(btnExportar);
        panel.add(btnLimpiar);

        panel.add(lblTabla);
        panel.add(scrollTabla);
        
        panel.add(lblGanancia);
        panel.add(txtGanancia);

        panel.add(lblTotal);
        panel.add(txtTotal);
        panel.add(lblCantidad);
        panel.add(txtCantidad);

        add(panel);
    }

    private void generar() {

        if (!validarCampos()) {
            return;
        }

        String tipo = cboTipoReporte.getSelectedItem().toString();

        switch (tipo) {
            case "Ventas":
                generarReporteVentas();
                break;

            case "Compras":
                generarReporteCompras();
                break;

            case "Inventario":
                generarReporteInventario();
                break;

            default:
                Mensajes.advertencia(this, "Seleccione un tipo de reporte.");
        }
    }

    private Date obtenerFechaSQL(String texto) throws Exception {
        java.util.Date fechaUtil = formato.parse(texto);
        return new Date(fechaUtil.getTime());
    }

    private void generarReporteVentas() {
        try {
            Date inicio = obtenerFechaSQL(txtFechaInicio.getText().trim());
            Date fin = obtenerFechaSQL(txtFechaFin.getText().trim());

            List<Venta> lista = controlador.reporteVentas(inicio, fin);

            modeloTabla.setColumnCount(0);
            modeloTabla.setRowCount(0);

            modeloTabla.addColumn("ID Venta");
            modeloTabla.addColumn("Fecha");
            modeloTabla.addColumn("Hora");
            modeloTabla.addColumn("Cliente");
            modeloTabla.addColumn("Empleado");
            modeloTabla.addColumn("Subtotal");
            modeloTabla.addColumn("IGV");
            modeloTabla.addColumn("Total");

            for (Venta v : lista) {
                modeloTabla.addRow(new Object[]{
                    v.getIdVenta(),
                    formato.format(v.getFecha()),
                    v.getHora(),
                    v.getCliente().getNombre() + " " + v.getCliente().getApPaterno(),
                    v.getEmpleado().getNombre() + " " + v.getEmpleado().getApPaterno(),
                    String.format("%.2f", v.getSubtotal()),
                    String.format("%.2f", v.getIgv()),
                    String.format("%.2f", v.getTotal())
                });
            }

            txtGanancia.setText("S/ " + String.format("%.2f",controlador.gananciaVentas(inicio, fin)));
            txtTotal.setText("S/ " + String.format("%.2f", controlador.totalVentas(inicio, fin)));
            txtCantidad.setText(String.valueOf(lista.size()));

            Mensajes.exito(this, "Reporte de ventas generado correctamente.");

        } catch (Exception e) {
            Mensajes.error(this, "No se pudo generar el reporte de ventas.");
        }
    }

    private void generarReporteCompras() {
        try {
            Date inicio = obtenerFechaSQL(txtFechaInicio.getText().trim());
            Date fin = obtenerFechaSQL(txtFechaFin.getText().trim());

            List<Compra> lista = controlador.reporteCompras(inicio, fin);

            modeloTabla.setColumnCount(0);
            modeloTabla.setRowCount(0);

            modeloTabla.addColumn("ID Compra");
            modeloTabla.addColumn("Fecha");
            modeloTabla.addColumn("Proveedor");
            modeloTabla.addColumn("Empleado");
            modeloTabla.addColumn("Total");

            for (Compra c : lista) {
                modeloTabla.addRow(new Object[]{
                    c.getIdCompra(),
                    formato.format(c.getFecha()),
                    c.getProveedor().getRazonSocial(),
                    c.getEmpleado().getNombre() + " " + c.getEmpleado().getApPaterno(),
                    String.format("%.2f", c.getTotal())
                });
            }

            txtGanancia.setText("-");
            txtTotal.setText("S/ " + String.format("%.2f", controlador.totalCompras(inicio, fin)));
            txtCantidad.setText(String.valueOf(lista.size()));

            Mensajes.exito(this, "Reporte de compras generado correctamente.");

        } catch (Exception e) {
            Mensajes.error(this, "No se pudo generar el reporte de compras.");
        }
    }

    private void generarReporteInventario() {
        try {
            List<Producto> lista = controlador.reporteInventario();

            modeloTabla.setColumnCount(0);
            modeloTabla.setRowCount(0);

            modeloTabla.addColumn("Código");
            modeloTabla.addColumn("Producto");
            modeloTabla.addColumn("Categoría");
            modeloTabla.addColumn("Marca");
            modeloTabla.addColumn("Stock");
            modeloTabla.addColumn("Stock Mínimo");
            modeloTabla.addColumn("Estado");

            for (Producto p : lista) {
                String estadoStock;

                if (p.getStock() == 0) {
                    estadoStock = "Sin stock";
                } else if (p.getStock() <= p.getStockMinimo()) {
                    estadoStock = "Stock bajo";
                } else {
                estadoStock = "Normal";
                }

                modeloTabla.addRow(new Object[]{
                    p.getCodigo(),
                    p.getNombre(),
                    p.getCategoria() != null ? p.getCategoria().getNombre() : "",
                    p.getMarca(),
                    p.getStock(),
                    p.getStockMinimo(),
                    estadoStock
                });
            }

            txtGanancia.setText("-");
            txtTotal.setText("-");
            txtCantidad.setText(String.valueOf(lista.size()));

            Mensajes.exito(this, "Reporte de inventario generado correctamente.");

        } catch (Exception e) {
            Mensajes.error(this, "No se pudo generar el reporte de inventario.");
        }
    }

    private boolean validarCampos() {

        if (cboTipoReporte.getSelectedIndex() == 0) {
            Mensajes.advertencia(this, "Seleccione el tipo de reporte.");
            cboTipoReporte.requestFocus();
            return false;
        }

        String tipo = cboTipoReporte.getSelectedItem().toString();

        if (!tipo.equals("Inventario")) {

            if (Validaciones.estaVacio(txtFechaInicio.getText())) {
                Mensajes.advertencia(this, "Ingrese la fecha de inicio.");
                txtFechaInicio.requestFocus();
                return false;
            }

            if (!Validaciones.fechaValida(txtFechaInicio.getText().trim())) {
                Mensajes.advertencia(this, "La fecha de inicio debe tener formato dd/MM/yyyy.");
                txtFechaInicio.requestFocus();
                return false;
            }

            if (Validaciones.estaVacio(txtFechaFin.getText())) {
                Mensajes.advertencia(this, "Ingrese la fecha fin.");
                txtFechaFin.requestFocus();
                return false;
            }

            if (!Validaciones.fechaValida(txtFechaFin.getText().trim())) {
                Mensajes.advertencia(this, "La fecha fin debe tener formato dd/MM/yyyy.");
                txtFechaFin.requestFocus();
                return false;
            }
        }

        return true;
    }

    private void exportar() {
        Mensajes.advertencia(this, "La exportación a PDF se implementará como mejora final.");
    }

    private void limpiar() {
        txtFechaInicio.setText("");
        txtFechaFin.setText("");
        txtTotal.setText("");
        txtCantidad.setText("");
        txtGanancia.setText("");

        cboTipoReporte.setSelectedIndex(0);

        modeloTabla.setColumnCount(0);
        modeloTabla.setRowCount(0);

        cboTipoReporte.requestFocus();
    }
    
    private void actualizarFormulario() {

        String tipo = cboTipoReporte.getSelectedItem().toString();
    
        boolean usaFechas = !tipo.equals("Inventario");

        lblFechaInicio.setVisible(usaFechas);
        txtFechaInicio.setVisible(usaFechas);

        lblFechaFin.setVisible(usaFechas);
        txtFechaFin.setVisible(usaFechas);

        if (tipo.equals("Inventario")) {
            lblTotal.setText("Productos:");
        } else {
            lblTotal.setText("Total:");
        }
    }
}
