/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import dao.AsistenciaDAO;
import java.util.List;
import modelo.Asistencia;

/**
 *
 * @author USUARIO
 */
public class ControladorAsistencia {
    private AsistenciaDAO asistenciaDAO;
    public ControladorAsistencia() {
        asistenciaDAO = new AsistenciaDAO();
    }

    public boolean existeAsistenciaHoy(int idPersona, java.util.Date fecha) {
        return asistenciaDAO.existeAsistenciaHoy(idPersona, fecha);
    }
    
    public boolean registrarAsistencia(Asistencia asistencia) {
        if (asistencia == null || asistencia.getEmpleado() == null) {
            return false;
        }
        return asistenciaDAO.registrar(asistencia);
    }

    public boolean actualizarAsistencia(Asistencia asistencia) {
        if (asistencia == null || asistencia.getIdAsistencia() <= 0
                || asistencia.getEmpleado() == null) {
            return false;
        }

        return asistenciaDAO.actualizar(asistencia);
    }

    public Asistencia buscarAsistencia(int idAsistencia) {
        if (idAsistencia <= 0) {
            return null;
        }

        return asistenciaDAO.buscarPorId(idAsistencia);
    }

    public List<Asistencia> listarAsistencias() {
        return asistenciaDAO.listar();
    }
}