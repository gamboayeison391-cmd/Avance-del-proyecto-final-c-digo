/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import controlador.ControladorDashboard;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.util.Map;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import util.Iconos;
/**
 *
 * @author USUARIO
 */
public class FrmDashboard extends JInternalFrame {

    private ControladorDashboard controlador = new ControladorDashboard();

    private JLabel lblVentasHoy, lblGananciaHoy, lblStockBajo, lblProductos, lblClientes, lblEmpleados;
    private JPanel panelGrafica;
    
    private JLabel icoVentas, icoGanancia, icoStock, icoProducto, icoCliente, icoEmpleado;
    

    public FrmDashboard() {
        iniciarComponentes();
        cargarDatos();
        cargarGrafica();
    }

    private void iniciarComponentes() {

        setTitle("Dashboard");
        setSize(1200, 700);
        setClosable(true);
        setIconifiable(false);
        setMaximizable(false);
        setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.WHITE);

        JLabel lblTitulo = new JLabel("DASHBOARD DEL MINIMARKET");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBounds(300, 30, 600, 40);

        JLabel lblSubtitulo = new JLabel("Resumen general del sistema");
        lblSubtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        lblSubtitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblSubtitulo.setBounds(300, 70, 600, 25);

        lblVentasHoy = crearTarjeta(
                panel,
                "Ventas Hoy",
                "S/ 0.00",
                "/imagenes/ventas.png",
                new Color(46, 204, 113),
                120,
                120);

        lblGananciaHoy = crearTarjeta(
                panel,
                "Ganacias Hoy",
                "S/ 0.00",
                "/imagenes/ganancias.png",
                new Color(52, 152, 219),
                510,
                120);

        lblStockBajo = crearTarjeta(
                panel,
                "Stock Bajo",
                "0",
                "/imagenes/stockBajo.png",
                new Color(231, 76, 60),
                900,
                120);

        lblProductos = crearTarjeta(
                panel,
                "Productos",
                "0",
                "/imagenes/productos.png",
                new Color(241, 196, 15),
                120,
                230);

        lblClientes = crearTarjeta(
                panel,
                "Clientes",
                "0",
                "/imagenes/clientes.png",
                new Color(155, 89, 182),
                510,
                230);

        lblEmpleados = crearTarjeta(
                panel,
                "Empleados",
                "0",
                "/imagenes/empleados.png",
                new Color(26, 188, 156),
                900,
                230);

        panelGrafica = new JPanel();
        panelGrafica.setLayout(new java.awt.BorderLayout());
        panelGrafica.setBounds(70, 350, 1060, 280);
        panel.add(panelGrafica);

      
        panel.add(lblTitulo);
        panel.add(lblSubtitulo);
        

        add(panel);
    }

   private JLabel crearTarjeta(JPanel panel,
                            String titulo,
                            String valor,
                            String rutaIcono,
                            Color color,
                            int x,
                            int y) {

    JPanel card = new JPanel();
        card.setLayout(null);
        card.setBackground(color);
        card.setBounds(x, y, 175, 85);

        JLabel lblIcono = new JLabel();
        lblIcono.setBounds(10, 8, 32, 32);
        lblIcono.setIcon(Iconos.cargar(rutaIcono, 32, 32));

        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setBounds(48, 10, 120, 20);

        JLabel lblValor = new JLabel(valor);
        lblValor.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblValor.setForeground(Color.WHITE);
        lblValor.setHorizontalAlignment(SwingConstants.CENTER);
        lblValor.setBounds(5, 42, 165, 25);

        card.add(lblIcono);
        card.add(lblTitulo);
        card.add(lblValor);

        panel.add(card);

        return lblValor;
    }

    private void cargarDatos() {

        lblVentasHoy.setText("S/ " + String.format("%.2f", controlador.ventasDelDia()));
        lblGananciaHoy.setText("S/ " +String.format("%.2f",controlador.gananciaDelDia()));
        lblStockBajo.setText(String.valueOf(controlador.productosStockBajo()));
        lblProductos.setText(String.valueOf(controlador.totalProductos()));
        lblClientes.setText(String.valueOf(controlador.totalClientes()));
        lblEmpleados.setText(String.valueOf(controlador.totalEmpleados()));
    }
    
    private void cargarGrafica() {

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
    
        Map<String, Double> datos = controlador.ventasUltimos7Dias();

        for (Map.Entry<String, Double> item : datos.entrySet()) {
            dataset.addValue(item.getValue(), "Ventas", item.getKey());
        }

        JFreeChart grafica = ChartFactory.createBarChart(
                "Ventas últimos 7 días",
                "Fecha",
                "Soles",
                dataset,
                PlotOrientation.VERTICAL,
                false,
                true,
                false
        );

        grafica.setBackgroundPaint(Color.WHITE);
        grafica.getTitle().setFont(new Font("Segoe UI", Font.BOLD, 16));

        CategoryPlot plot = grafica.getCategoryPlot();
        plot.setBackgroundPaint(Color.WHITE);
        plot.setRangeGridlinePaint(new Color(220, 220, 220));
        plot.setRangeGridlineStroke(new BasicStroke(1f));
        plot.setOutlineVisible(false);

        plot.getDomainAxis().setLabelFont(new Font("Segoe UI", Font.PLAIN, 12));
        plot.getDomainAxis().setTickLabelFont(new Font("Segoe UI", Font.PLAIN, 11));

        plot.getRangeAxis().setLabelFont(new Font("Segoe UI", Font.PLAIN, 12));
        plot.getRangeAxis().setTickLabelFont(new Font("Segoe UI", Font.PLAIN, 11));

        BarRenderer renderer = (BarRenderer) plot.getRenderer();
        renderer.setDrawBarOutline(false);
        renderer.setMaximumBarWidth(0.08);

        renderer.setSeriesPaint(0,
                new GradientPaint(
                    0f, 0f, new Color(52, 152, 219),
                    0f, 300f, new Color(41, 128, 185)
                )
        );

        ChartPanel chartPanel = new ChartPanel(grafica);
        chartPanel.setBackground(Color.WHITE);
        chartPanel.setBorder(null);

        panelGrafica.removeAll();
        panelGrafica.add(chartPanel);

        panelGrafica.revalidate();
        panelGrafica.repaint();
    }
}
