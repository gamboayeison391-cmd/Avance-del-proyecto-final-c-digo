/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexion.ConexionBD;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import modelo.Empleado;
/**
 *
 * @author USUARIO
 */
public class EmpleadoDAO {
    public boolean registrar(Empleado emp) {

        Connection con = null;
        try {
            con = ConexionBD.conectar();
            con.setAutoCommit(false);

            PreparedStatement sqlPersona = con.prepareStatement(
                "INSERT INTO Persona "
              + "(tipoDocumento, nroDocumento, nombre, apPaterno, apMaterno, "
              + "fechaNacimiento, sexo, telefono, correo, direccion, estado) "
              + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS
            );

            sqlPersona.setString(1, emp.getTipoDocumento());
            sqlPersona.setString(2, emp.getNroDocumento());
            sqlPersona.setString(3, emp.getNombre());
            sqlPersona.setString(4, emp.getApPaterno());
            sqlPersona.setString(5, emp.getApMaterno());

            if (emp.getFechaNacimiento() != null) {
                sqlPersona.setDate(6, new java.sql.Date(emp.getFechaNacimiento().getTime()));
            } else {
                sqlPersona.setNull(6, Types.DATE);
            }

            sqlPersona.setString(7, emp.getSexo());
            sqlPersona.setString(8, emp.getTelefono());
            sqlPersona.setString(9, emp.getCorreo());
            sqlPersona.setString(10, emp.getDireccion());
            sqlPersona.setBoolean(11, emp.isEstado());

            int resPersona = sqlPersona.executeUpdate();

            if (resPersona == 0) {
                con.rollback();
                return false;
            }

            ResultSet rs = sqlPersona.getGeneratedKeys();

            int idPersona = 0;

            if (rs.next()) {
                idPersona = rs.getInt(1);
            } else {
                con.rollback();
                return false;
            }

            PreparedStatement sqlEmpleado = con.prepareStatement(
                "INSERT INTO Empleado "
              + "(idPersona, codigoEmpleado, fechaIngreso, cargo, sueldo, idJefe) "
              + "VALUES (?, ?, ?, ?, ?, ?)"
            );

            sqlEmpleado.setInt(1, idPersona);
            sqlEmpleado.setString(2, emp.getCodigoEmpleado());

            if (emp.getFechaIngreso() != null) {
                sqlEmpleado.setDate(3, new java.sql.Date(emp.getFechaIngreso().getTime()));
            } else {
                sqlEmpleado.setNull(3, Types.DATE);
            }

            sqlEmpleado.setString(4, emp.getCargo());
            sqlEmpleado.setDouble(5, emp.getSueldo());

            if (emp.getJefe() != null) {
                sqlEmpleado.setInt(6, emp.getJefe().getIdPersona());
            } else {
                sqlEmpleado.setNull(6, Types.INTEGER);
            }

            int resEmpleado = sqlEmpleado.executeUpdate();

            rs.close();
            sqlPersona.close();
            sqlEmpleado.close();

            if (resEmpleado > 0) {
                con.commit();
                return true;
            } else {
                con.rollback();
                return false;
            }

        } catch (SQLException e) {

            try {
                if (con != null) {
                    con.rollback();
                }
            } catch (SQLException ex) {
                System.out.println("Error rollback empleado: " + ex.getMessage());
            }

            System.out.println("Error registrar empleado: " + e.getMessage());
            return false;

        } finally {
            ConexionBD.cerrar(con);
        }
    }

    public boolean actualizar(Empleado emp) {

        Connection con = null;

        try {
            con = ConexionBD.conectar();
            con.setAutoCommit(false);

            PreparedStatement sqlPersona = con.prepareStatement(
                "UPDATE Persona SET "
              + "tipoDocumento = ?, "
              + "nroDocumento = ?, "
              + "nombre = ?, "
              + "apPaterno = ?, "
              + "apMaterno = ?, "
              + "fechaNacimiento = ?, "
              + "sexo = ?, "
              + "telefono = ?, "
              + "correo = ?, "
              + "direccion = ?, "
              + "estado = ? "
              + "WHERE idPersona = ?"
            );

            sqlPersona.setString(1, emp.getTipoDocumento());
            sqlPersona.setString(2, emp.getNroDocumento());
            sqlPersona.setString(3, emp.getNombre());
            sqlPersona.setString(4, emp.getApPaterno());
            sqlPersona.setString(5, emp.getApMaterno());

            if (emp.getFechaNacimiento() != null) {
                sqlPersona.setDate(6, new java.sql.Date(emp.getFechaNacimiento().getTime()));
            } else {
                sqlPersona.setNull(6, Types.DATE);
            }

            sqlPersona.setString(7, emp.getSexo());
            sqlPersona.setString(8, emp.getTelefono());
            sqlPersona.setString(9, emp.getCorreo());
            sqlPersona.setString(10, emp.getDireccion());
            sqlPersona.setBoolean(11, emp.isEstado());
            sqlPersona.setInt(12, emp.getIdPersona());

            int resPersona = sqlPersona.executeUpdate();

            PreparedStatement sqlEmpleado = con.prepareStatement(
                "UPDATE Empleado SET "
              + "codigoEmpleado = ?, "
              + "fechaIngreso = ?, "
              + "cargo = ?, "
              + "sueldo = ?, "
              + "idJefe = ? "
              + "WHERE idPersona = ?"
            );

            sqlEmpleado.setString(1, emp.getCodigoEmpleado());

            if (emp.getFechaIngreso() != null) {
                sqlEmpleado.setDate(2, new java.sql.Date(emp.getFechaIngreso().getTime()));
            } else {
                sqlEmpleado.setNull(2, Types.DATE);
            }

            sqlEmpleado.setString(3, emp.getCargo());
            sqlEmpleado.setDouble(4, emp.getSueldo());

            if (emp.getJefe() != null) {
                sqlEmpleado.setInt(5, emp.getJefe().getIdPersona());
            } else {
                sqlEmpleado.setNull(5, Types.INTEGER);
            }

            sqlEmpleado.setInt(6, emp.getIdPersona());

            int resEmpleado = sqlEmpleado.executeUpdate();

            sqlPersona.close();
            sqlEmpleado.close();

            if (resPersona > 0 && resEmpleado > 0) {
                con.commit();
                return true;
            } else {
                con.rollback();
                return false;
            }

        } catch (SQLException e) {

            try {
                if (con != null) {
                    con.rollback();
                }
            } catch (SQLException ex) {
                System.out.println("Error rollback empleado: " + ex.getMessage());
            }

            System.out.println("Error actualizar empleado: " + e.getMessage());
            return false;

        } finally {
            ConexionBD.cerrar(con);
        }
    }

    
    public Empleado buscarPorDocumento(String nroDocumento) {

        Empleado emp = null;

        try {
            Connection con = ConexionBD.conectar();

            PreparedStatement sql = con.prepareStatement(
                "SELECT "
              + "p.idPersona, p.tipoDocumento, p.nroDocumento, p.nombre, "
              + "p.apPaterno, p.apMaterno, p.fechaNacimiento, p.sexo, "
              + "p.telefono, p.correo, p.direccion, p.estado, "
              + "e.codigoEmpleado, e.fechaIngreso, e.cargo, e.sueldo "
              + "FROM Persona p "
              + "INNER JOIN Empleado e ON p.idPersona = e.idPersona "
              + "WHERE p.nroDocumento = ?"
            );

            sql.setString(1, nroDocumento);

            ResultSet res = sql.executeQuery();

            if (res.next()) {
                emp = new Empleado();

                emp.setIdPersona(res.getInt("idPersona"));
                emp.setTipoDocumento(res.getString("tipoDocumento"));
                emp.setNroDocumento(res.getString("nroDocumento"));
                emp.setNombre(res.getString("nombre"));
                emp.setApPaterno(res.getString("apPaterno"));
                emp.setApMaterno(res.getString("apMaterno"));
                emp.setFechaNacimiento(res.getDate("fechaNacimiento"));
                emp.setSexo(res.getString("sexo"));
                emp.setTelefono(res.getString("telefono"));
                emp.setCorreo(res.getString("correo"));
                emp.setDireccion(res.getString("direccion"));
                emp.setEstado(res.getBoolean("estado"));
                emp.setCodigoEmpleado(res.getString("codigoEmpleado"));
                emp.setFechaIngreso(res.getDate("fechaIngreso"));
                emp.setCargo(res.getString("cargo"));
                emp.setSueldo(res.getDouble("sueldo"));
            }

            res.close();
            sql.close();
            ConexionBD.cerrar(con);

        } catch (SQLException e) {
            System.out.println("Error buscar empleado: " + e.getMessage());
        }

        return emp;
    }
    
    
    public boolean desactivar(int idPersona) {
        try {
            Connection cn = ConexionBD.conectar();
            PreparedStatement ps = cn.prepareStatement(
                "UPDATE Persona SET estado = 0 WHERE idPersona = ?"
            );

            ps.setInt(1, idPersona);

            int res = ps.executeUpdate();

            ps.close();
            ConexionBD.cerrar(cn);

            return res > 0;

        } catch (SQLException e) {

            System.out.println("Error desactivar empleado: " + e.getMessage());
            return false;

        }
    }

    public List<Empleado> listar() {

        List<Empleado> lista = new ArrayList<>();

        try {
            Connection con = ConexionBD.conectar();

            PreparedStatement sql = con.prepareStatement(
                "SELECT "
              + "p.idPersona, p.tipoDocumento, p.nroDocumento, p.nombre, "
              + "p.apPaterno, p.apMaterno, p.fechaNacimiento, p.sexo, "
              + "p.telefono, p.correo, p.direccion, p.estado, "
              + "e.codigoEmpleado, e.fechaIngreso, e.cargo, e.sueldo "
              + "FROM Persona p "
              + "INNER JOIN Empleado e ON p.idPersona = e.idPersona "
              + "ORDER BY p.idPersona DESC"
            );

            ResultSet res = sql.executeQuery();

            while (res.next()) {
                Empleado emp = new Empleado();

                emp.setIdPersona(res.getInt("idPersona"));
                emp.setTipoDocumento(res.getString("tipoDocumento"));
                emp.setNroDocumento(res.getString("nroDocumento"));
                emp.setNombre(res.getString("nombre"));
                emp.setApPaterno(res.getString("apPaterno"));
                emp.setApMaterno(res.getString("apMaterno"));
                emp.setFechaNacimiento(res.getDate("fechaNacimiento"));
                emp.setSexo(res.getString("sexo"));
                emp.setTelefono(res.getString("telefono"));
                emp.setCorreo(res.getString("correo"));
                emp.setDireccion(res.getString("direccion"));
                emp.setEstado(res.getBoolean("estado"));
                emp.setCodigoEmpleado(res.getString("codigoEmpleado"));
                emp.setFechaIngreso(res.getDate("fechaIngreso"));
                emp.setCargo(res.getString("cargo"));
                emp.setSueldo(res.getDouble("sueldo"));

                lista.add(emp);
            }

            res.close();
            sql.close();
            ConexionBD.cerrar(con);

        } catch (SQLException e) {
            System.out.println("Error listar empleados: " + e.getMessage());
        }

        return lista;
    }
    
    public List<Empleado> listarActivos() {
        List<Empleado> lista = new ArrayList<>();

        try {
            Connection con = ConexionBD.conectar();

            PreparedStatement sql = con.prepareStatement(
                "SELECT "
              + "p.idPersona, p.tipoDocumento, p.nroDocumento, p.nombre, "
              + "p.apPaterno, p.apMaterno, p.fechaNacimiento, p.sexo, "
              + "p.telefono, p.correo, p.direccion, p.estado, "
              + "e.codigoEmpleado, e.fechaIngreso, e.cargo, e.sueldo "
              + "FROM Persona p "
              + "INNER JOIN Empleado e ON p.idPersona = e.idPersona "
              + "WHERE p.estado = 1 "
              + "ORDER BY p.idPersona DESC"
            );

            ResultSet res = sql.executeQuery();

            while (res.next()) {
                Empleado emp = new Empleado();
    
                emp.setIdPersona(res.getInt("idPersona"));
                emp.setTipoDocumento(res.getString("tipoDocumento"));
                emp.setNroDocumento(res.getString("nroDocumento"));
                emp.setNombre(res.getString("nombre"));
                emp.setApPaterno(res.getString("apPaterno"));
                emp.setApMaterno(res.getString("apMaterno"));
                emp.setFechaNacimiento(res.getDate("fechaNacimiento"));
                emp.setSexo(res.getString("sexo"));
                emp.setTelefono(res.getString("telefono"));
                emp.setCorreo(res.getString("correo"));
                emp.setDireccion(res.getString("direccion"));
                emp.setEstado(res.getBoolean("estado"));
                emp.setCodigoEmpleado(res.getString("codigoEmpleado"));
                emp.setFechaIngreso(res.getDate("fechaIngreso"));
                emp.setCargo(res.getString("cargo"));
                emp.setSueldo(res.getDouble("sueldo"));

                lista.add(emp);
            }

            res.close();
            sql.close();
            ConexionBD.cerrar(con);

        } catch (SQLException e) {
            System.out.println("Error listar empleados activos: " + e.getMessage());
        }

        return lista;
    }

    public boolean existeDocumento(String nroDocumento) {

        try {
            Connection con = ConexionBD.conectar();

            PreparedStatement sql = con.prepareStatement(
                "SELECT COUNT(*) FROM Persona WHERE nroDocumento = ?"
            );

            sql.setString(1, nroDocumento);

            ResultSet res = sql.executeQuery();

            if (res.next()) {
                boolean existe = res.getInt(1) > 0;

                res.close();
                sql.close();
                ConexionBD.cerrar(con);

                return existe;
            }

            res.close();
            sql.close();
            ConexionBD.cerrar(con);

        } catch (SQLException e) {
            System.out.println("Error verificar documento: " + e.getMessage());
        }

        return false;
    }

    public boolean existeCodigo(String codigoEmpleado) {

        try {
            Connection con = ConexionBD.conectar();

            PreparedStatement sql = con.prepareStatement(
                "SELECT COUNT(*) FROM Empleado WHERE codigoEmpleado = ?"
            );

            sql.setString(1, codigoEmpleado);

            ResultSet res = sql.executeQuery();

            if (res.next()) {
                boolean existe = res.getInt(1) > 0;

                res.close();
                sql.close();
                ConexionBD.cerrar(con);

                return existe;
            }

            res.close();
            sql.close();
            ConexionBD.cerrar(con);

        } catch (SQLException e) {
            System.out.println("Error verificar código empleado: " + e.getMessage());
        }

        return false;
    }
    
        private void hacerRollback(Connection cn) {
        try {
            if (cn != null) {
                cn.rollback();
            }
        } catch (SQLException e) {
            System.out.println("Error rollback empleado: " + e.getMessage());
        }
    }
}