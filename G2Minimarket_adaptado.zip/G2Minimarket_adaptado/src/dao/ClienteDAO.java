/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import conexion.ConexionBD;
import modelo.Cliente;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author USUARIO
 */
public class ClienteDAO {
    public boolean registrar(Cliente cli) {
        Connection cn = null;

        try {
            cn = ConexionBD.conectar();
            cn.setAutoCommit(false);

            PreparedStatement psPersona = cn.prepareStatement(
                "INSERT INTO Persona "
              + "(tipoDocumento, nroDocumento, nombre, apPaterno, apMaterno, "
              + "fechaNacimiento, sexo, telefono, correo, direccion, estado) "
              + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS
            );

            cargarDatosPersona(psPersona, cli);
            psPersona.setBoolean(11, cli.isEstado());

            int resPersona = psPersona.executeUpdate();

            if (resPersona == 0) {
                cn.rollback();
                return false;
            }

            ResultSet rs = psPersona.getGeneratedKeys();

            int idPersona = 0;

            if (rs.next()) {
                idPersona = rs.getInt(1);
            } else {
                cn.rollback();
                return false;
            }

            PreparedStatement psCliente = cn.prepareStatement(
                "INSERT INTO Cliente (idPersona, puntosAcumulados) "
              + "VALUES (?, ?)"
            );

            psCliente.setInt(1, idPersona);
            psCliente.setInt(2, cli.getPuntosAcumulados());

            int resCliente = psCliente.executeUpdate();

            rs.close();
            psPersona.close();
            psCliente.close();

            if (resCliente > 0) {
                cn.commit();
                return true;
            } else {
                cn.rollback();
                return false;
            }

        } catch (SQLException e) {
            hacerRollback(cn);
            System.out.println("Error registrar cliente: " + e.getMessage());
            return false;

        } finally {
            ConexionBD.cerrar(cn);
        }
    }

    public boolean actualizar(Cliente cli) {
        Connection cn = null;

        try {
            cn = ConexionBD.conectar();
            cn.setAutoCommit(false);

            PreparedStatement psPersona = cn.prepareStatement(
                "UPDATE Persona SET "
              + "tipoDocumento = ?, "
              + "nroDocumento = ?, "
              + "nombre = ?, "
              + "apPaterno = ?, "
              + "apMaterno = ?, "
              + "fechaNacimiento = ?, "
              + "sexo = ?, "
              + "telefono = ?, "
              + "correo = ?, "
              + "direccion = ?, "
              + "estado = ? "
              + "WHERE idPersona = ?"
            );

            cargarDatosPersona(psPersona, cli);
            psPersona.setBoolean(11, cli.isEstado());
            psPersona.setInt(12, cli.getIdPersona());

            int resPersona = psPersona.executeUpdate();

            PreparedStatement psCliente = cn.prepareStatement(
                "UPDATE Cliente SET puntosAcumulados = ? "
              + "WHERE idPersona = ?"
            );

            psCliente.setInt(1, cli.getPuntosAcumulados());
            psCliente.setInt(2, cli.getIdPersona());

            int resCliente = psCliente.executeUpdate();

            psPersona.close();
            psCliente.close();

            if (resPersona > 0 && resCliente > 0) {
                cn.commit();
                return true;
            } else {
                cn.rollback();
                return false;
            }

        } catch (SQLException e) {
            hacerRollback(cn);
            System.out.println("Error actualizar cliente: " + e.getMessage());
            return false;

        } finally {
            ConexionBD.cerrar(cn);
        }
    }

    
    
    
    public Cliente buscarPorDocumento(String nroDocumento) {
        Cliente cli = null;

        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "SELECT "
              + "p.idPersona, p.tipoDocumento, p.nroDocumento, p.nombre, "
              + "p.apPaterno, p.apMaterno, p.fechaNacimiento, p.sexo, "
              + "p.telefono, p.correo, p.direccion, p.estado, "
              + "c.puntosAcumulados "
              + "FROM Persona p "
              + "INNER JOIN Cliente c ON p.idPersona = c.idPersona "
              + "WHERE p.nroDocumento = ?"
            );

            ps.setString(1, nroDocumento);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                cli = convertirCliente(rs);
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error buscar cliente: " + e.getMessage());
        }

        return cli;
    }

    public List<Cliente> listar() {
        List<Cliente> lista = new ArrayList<>();

        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "SELECT "
              + "p.idPersona, p.tipoDocumento, p.nroDocumento, p.nombre, "
              + "p.apPaterno, p.apMaterno, p.fechaNacimiento, p.sexo, "
              + "p.telefono, p.correo, p.direccion, p.estado, "
              + "c.puntosAcumulados "
              + "FROM Persona p "
              + "INNER JOIN Cliente c ON p.idPersona = c.idPersona "
              + "ORDER BY p.idPersona DESC"
            );

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(convertirCliente(rs));
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error listar clientes: " + e.getMessage());
        }

        return lista;
    }
    
    public List<Cliente> listarActivos() {
        List<Cliente> lista = new ArrayList<>();

        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "SELECT "
              + "p.idPersona, p.tipoDocumento, p.nroDocumento, p.nombre, "
              + "p.apPaterno, p.apMaterno, p.fechaNacimiento, p.sexo, "
              + "p.telefono, p.correo, p.direccion, p.estado, "
              + "c.puntosAcumulados "
              + "FROM Persona p "
              + "INNER JOIN Cliente c ON p.idPersona = c.idPersona "
              + "WHERE p.estado = 1 "
              + "ORDER BY p.idPersona DESC"
            );

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(convertirCliente(rs));
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

        } catch (SQLException e) {
            System.out.println("Error listar clientes activos: " + e.getMessage());
        }

        return lista;
    }

    public boolean existeDocumento(String nroDocumento) {
        try {
            Connection cn = ConexionBD.conectar();

            PreparedStatement ps = cn.prepareStatement(
                "SELECT COUNT(*) FROM Persona WHERE nroDocumento = ?"
            );

            ps.setString(1, nroDocumento);

            ResultSet rs = ps.executeQuery();

            boolean existe = false;

            if (rs.next()) {
                existe = rs.getInt(1) > 0;
            }

            rs.close();
            ps.close();
            ConexionBD.cerrar(cn);

            return existe;

        } catch (SQLException e) {
            System.out.println("Error verificar documento cliente: " + e.getMessage());
            return false;
        }
    }

    private void cargarDatosPersona(PreparedStatement ps, Cliente cli) throws SQLException {
        ps.setString(1, cli.getTipoDocumento());
        ps.setString(2, cli.getNroDocumento());
        ps.setString(3, cli.getNombre());
        ps.setString(4, cli.getApPaterno());
        ps.setString(5, cli.getApMaterno());

        if (cli.getFechaNacimiento() != null) {
            ps.setDate(6, new java.sql.Date(cli.getFechaNacimiento().getTime()));
        } else {
            ps.setNull(6, Types.DATE);
        }

        ps.setString(7, cli.getSexo());
        ps.setString(8, cli.getTelefono());
        ps.setString(9, cli.getCorreo());
        ps.setString(10, cli.getDireccion());
    }

    private Cliente convertirCliente(ResultSet rs) throws SQLException {
        Cliente cli = new Cliente();

        cli.setIdPersona(rs.getInt("idPersona"));
        cli.setTipoDocumento(rs.getString("tipoDocumento"));
        cli.setNroDocumento(rs.getString("nroDocumento"));
        cli.setNombre(rs.getString("nombre"));
        cli.setApPaterno(rs.getString("apPaterno"));
        cli.setApMaterno(rs.getString("apMaterno"));
        cli.setFechaNacimiento(rs.getDate("fechaNacimiento"));
        cli.setSexo(rs.getString("sexo"));
        cli.setTelefono(rs.getString("telefono"));
        cli.setCorreo(rs.getString("correo"));
        cli.setDireccion(rs.getString("direccion"));
        cli.setEstado(rs.getBoolean("estado"));
        cli.setPuntosAcumulados(rs.getInt("puntosAcumulados"));

        return cli;
    }

    private void hacerRollback(Connection cn) {
        try {
            if (cn != null) {
                cn.rollback();
            }
        } catch (SQLException e) {
            System.out.println("Error rollback cliente: " + e.getMessage());
        }
    }
}
