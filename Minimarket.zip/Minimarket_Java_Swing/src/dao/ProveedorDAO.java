package dao;

import java.util.List;
import modelo.Proveedor;

/** Gestión de proveedores mediante registros temporales en memoria. */
public class ProveedorDAO {
    private static final Almacen<Proveedor> ALMACEN = new Almacen<>(0);

    public boolean registrar(Proveedor pro) {
        if (pro == null) return false;
        pro.setIdPersona(ALMACEN.siguienteId());
        ALMACEN.agregar(pro);
        return true;
    }
    public boolean actualizar(Proveedor pro) {
        return pro != null && ALMACEN.reemplazar(p -> p.getIdPersona() == pro.getIdPersona(), pro);
    }
    public boolean eliminar(int idPersona) {
        if (tieneComprasAsociadas(idPersona)) return desactivar(idPersona);
        return ALMACEN.quitar(p -> p.getIdPersona() == idPersona);
    }
    public boolean activar(int idPersona) { return cambiarEstado(idPersona, true); }
    public boolean desactivar(int idPersona) { return cambiarEstado(idPersona, false); }
    private boolean cambiarEstado(int id, boolean estado) {
        Proveedor p = ALMACEN.buscar(x -> x.getIdPersona() == id).orElse(null);
        if (p == null) return false;
        p.setEstado(estado);
        return true;
    }
    public Proveedor buscarPorDocumento(String nro) {
        return ALMACEN.buscar(p -> nro != null && nro.equals(p.getNroDocumento())).orElse(null);
    }
    public Proveedor buscarPorRuc(String ruc) {
        return ALMACEN.buscar(p -> ruc != null && ruc.equals(p.getRuc())).orElse(null);
    }
    public List<Proveedor> listar() { return ALMACEN.todos(); }
    public List<Proveedor> listarActivos() { return ALMACEN.filtrar(Proveedor::isEstado); }
    public boolean existeDocumento(String nro) { return buscarPorDocumento(nro) != null; }
    public boolean existeRuc(String ruc) { return buscarPorRuc(ruc) != null; }
    public boolean tieneComprasAsociadas(int idPersona) {
        return new CompraDAO().listar().stream().anyMatch(c -> c.getProveedor() != null && c.getProveedor().getIdPersona() == idPersona);
    }
}
