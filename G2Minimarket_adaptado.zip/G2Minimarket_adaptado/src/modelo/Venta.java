/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author UCF20429
 */
public class Venta {

    private int idVenta;
    private Date fecha;
    private String hora;
    private double subtotal;
    private double igv;
    private double total;
    private String estado = "ACTIVA";

    // Relaciones
    private Cliente cliente;
    private Empleado empleado;
    private ArrayList<DetalleVenta> detallesVenta;

    public Venta() {
        detallesVenta = new ArrayList<>();
    }

    public Venta(int idVenta,
                 Date fecha,
                 String hora,
                 double subtotal,
                 double igv,
                 double total,
                 Cliente cliente,
                 Empleado empleado,
                 ArrayList<DetalleVenta> detallesVenta) {

        this.idVenta = idVenta;
        this.fecha = fecha;
        this.hora = hora;
        this.subtotal = subtotal;
        this.igv = igv;
        this.total = total;
        this.cliente = cliente;
        this.empleado = empleado;
        this.detallesVenta = detallesVenta;
    }

    public int getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public double getIgv() {
        return igv;
    }

    public void setIgv(double igv) {
        this.igv = igv;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

    public ArrayList<DetalleVenta> getDetallesVenta() {
        return detallesVenta;
    }

    public void setDetallesVenta(ArrayList<DetalleVenta> detallesVenta) {
        this.detallesVenta = detallesVenta;
    }
    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    //metodos
    public void agregarDetalle(DetalleVenta detalle) {
        detallesVenta.add(detalle);
        calcularTotales();
    }

    public void eliminarDetalle(DetalleVenta detalle) {
        detallesVenta.remove(detalle);
        calcularTotales();
    }

    public void calcularTotales() {

        subtotal = 0;

        for (DetalleVenta detalle : detallesVenta) {
            subtotal += detalle.getSubtotal();
        }

        igv = subtotal * 0.18;
        total = subtotal + igv;
    }

    public int cantidadProductos() {
        return detallesVenta.size();
    }

    @Override
    public String toString() {
        return "Venta N° " + idVenta;
    }
}
